#ifndef __INC_CLOCKLESS_STUB_H
#define __INC_CLOCKLESS_STUB_H
// Web FastLED: clockless controller hands final pixels (after brightness, colour correction,
// dithering and colour order) to emulator, back in logical R, G, B order.

#include "namespace.h"

extern "C" uint8_t *wfl_led_buffer(int pin, int count);
extern "C" void wfl_led_show(int pin, int count, int bit_ns);

FASTLED_NAMESPACE_BEGIN

#if defined(FASTLED_STUB_IMPL)

#define FASTLED_HAS_CLOCKLESS 1

template <int DATA_PIN, int T1, int T2, int T3, EOrder RGB_ORDER = RGB, int XTRA0 = 0, bool FLIP = false, int WAIT_TIME = 0>
class ClocklessController : public CPixelLEDController<RGB_ORDER> {
public:
	virtual void init() { }

protected:
	virtual void showPixels(PixelController<RGB_ORDER> & pixels) {
		const int n = pixels.size();
		uint8_t *out = wfl_led_buffer(DATA_PIN, n);
		pixels.preStepFirstByteDithering();
		for (int i = 0; i < n && pixels.has(1); i++) {
			out[i * 3 + RGB_BYTE0(RGB_ORDER)] = pixels.loadAndScale0();
			out[i * 3 + RGB_BYTE1(RGB_ORDER)] = pixels.loadAndScale1();
			out[i * 3 + RGB_BYTE2(RGB_ORDER)] = pixels.loadAndScale2();
			pixels.advanceData();
			pixels.stepDithering();
		}
		// time of one bit on wire, ns: (T1 + T2 + T3) clocks; WS2812 at 16 MHz = 1250 ns, 30 us per LED
		wfl_led_show(DATA_PIN, n, (int)(((int64_t)(T1 + T2 + T3) * 1000000000LL / F_CPU)));
	}
};

#endif // defined(FASTLED_STUB_IMPL)

FASTLED_NAMESPACE_END

#endif // __INC_CLOCKLESS_STUB_H
