#ifndef __INC_LED_SYSDEFS_STUB_H
#define __INC_LED_SYSDEFS_STUB_H
// Web FastLED: stub platform runs on Arduino API of emulator (core/Arduino.h)

#ifndef FASTLED_STUB_IMPL
#define FASTLED_STUB_IMPL
#endif

#include <stdint.h>
#include <Arduino.h>

#ifndef F_CPU
#define F_CPU 16000000L
#endif

#define FASTLED_HAS_MILLIS

#define digitalPinToBitMask(P) ( 0 )
#define digitalPinToPort(P) ( 0 )
#define portOutputRegister(P) ( 0 )
#define portInputRegister(P) ( 0 )

typedef volatile uint32_t RoReg;
typedef volatile uint32_t RwReg;

#endif // __INC_LED_SYSDEFS_STUB_H
