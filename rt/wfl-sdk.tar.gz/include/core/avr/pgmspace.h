// Web FastLED: program memory is ordinary memory here
#ifndef __PGMSPACE_H_
#define __PGMSPACE_H_ 1
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#define PROGMEM
// far pointers: on AVR 32-bit integer address; here any pointer converts to it (g++ -fpermissive allowed that on AVR)
#ifdef __cplusplus
struct uint_farptr_t {
  uint32_t v;
  uint_farptr_t() : v(0) {}
  uint_farptr_t(uint32_t x) : v(x) {}
  uint_farptr_t(int x) : v((uint32_t)x) {}
  uint_farptr_t(unsigned long x) : v((uint32_t)x) {}
  uint_farptr_t(long x) : v((uint32_t)x) {}
  template <class T> uint_farptr_t(const T *p) : v((uint32_t)(uintptr_t)p) {}
  operator uint32_t() const { return v; }
};
#else
typedef uint32_t uint_farptr_t;
#endif
#define PGM_P const char *
#define PGM_VOID_P const void *
#define PSTR(s) (s)
#define _SFR_BYTE(sfr) (sfr)
typedef void prog_void;
typedef char prog_char;
typedef unsigned char prog_uchar;
typedef int8_t prog_int8_t;
typedef uint8_t prog_uint8_t;
typedef int16_t prog_int16_t;
typedef uint16_t prog_uint16_t;
typedef int32_t prog_int32_t;
typedef uint32_t prog_uint32_t;
#define pgm_read_byte(addr) (*(const uint8_t *)(uintptr_t)(addr))
#define pgm_read_word(addr) (*(const uint16_t *)(uintptr_t)(addr))
#define pgm_read_dword(addr) (*(const uint32_t *)(uintptr_t)(addr))
#define pgm_read_float(addr) (*(const float *)(uintptr_t)(addr))
#define pgm_read_ptr(addr) (*(void * const *)(uintptr_t)(addr))
#define pgm_read_byte_near(addr) pgm_read_byte(addr)
#define pgm_read_word_near(addr) pgm_read_word(addr)
#define pgm_read_dword_near(addr) pgm_read_dword(addr)
#define pgm_read_float_near(addr) pgm_read_float(addr)
#define pgm_read_ptr_near(addr) pgm_read_ptr(addr)
#define pgm_read_byte_far(addr) pgm_read_byte(addr)
#define pgm_read_word_far(addr) pgm_read_word(addr)
#define pgm_read_dword_far(addr) pgm_read_dword(addr)
#define pgm_read_float_far(addr) pgm_read_float(addr)
#define pgm_get_far_address(var) ((uint32_t)(uintptr_t)&(var))
#define memchr_P memchr
#define memcmp_P memcmp
#define memccpy_P memccpy
#define memcpy_P memcpy
#define memmem_P memmem
#define strcat_P strcat
#define strchr_P strchr
#define strcmp_P strcmp
#define strcpy_P strcpy
#define strcasecmp_P strcasecmp
#define strlen_P strlen
#define strnlen_P strnlen
#define strncmp_P strncmp
#define strncasecmp_P strncasecmp
#define strncat_P strncat
#define strncpy_P strncpy
#define strstr_P strstr
#define strrchr_P strrchr
#define sprintf_P sprintf
#define snprintf_P snprintf
#define vsnprintf_P vsnprintf
#define printf_P printf
#endif
