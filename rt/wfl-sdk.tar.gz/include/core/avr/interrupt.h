#ifndef _AVR_INTERRUPT_H_
#define _AVR_INTERRUPT_H_
#define sei() do {} while (0)
#define cli() do {} while (0)
#define ISR(vector, ...) extern "C" void vector(void)
#endif
