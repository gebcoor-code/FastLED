// Web FastLED: AVR builtins of avr-gcc for emulator (no interrupts, no sleep: they do nothing)
#pragma once
#define __builtin_avr_cli() ((void)0)
#define __builtin_avr_sei() ((void)0)
#define __builtin_avr_wdr() ((void)0)
#define __builtin_avr_sleep() ((void)0)
#define __builtin_avr_nop() ((void)0)
#include <util/delay.h>
#define __builtin_avr_delay_cycles(n) wfl_delay_us((unsigned long)((n) / 16)) // 16 MHz
#define __builtin_avr_swap(x) ((unsigned char)((((x) & 0x0F) << 4) | (((x) >> 4) & 0x0F)))
