// Web FastLED: no AVR registers; few names so that sketches compile
#ifndef _AVR_IO_H_
#define _AVR_IO_H_
#include <stdint.h>
#ifndef _BV
#define _BV(bit) (1 << (bit))
#endif
#define bit_is_set(sfr, bit) ((sfr) & _BV(bit))
#define bit_is_clear(sfr, bit) (!((sfr) & _BV(bit)))
#if defined(ARDUINO_AVR_MEGA2560)
#define RAMEND 0x21FF
#define E2END 0xFFF
#else
#define RAMEND 0x8FF
#define E2END 0x3FF
#endif
#endif
