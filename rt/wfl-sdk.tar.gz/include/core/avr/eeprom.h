#ifndef _AVR_EEPROM_H_
#define _AVR_EEPROM_H_
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
uint8_t eeprom_read_byte(const uint8_t *p);
void eeprom_write_byte(uint8_t *p, uint8_t v);
void eeprom_update_byte(uint8_t *p, uint8_t v);
uint16_t eeprom_read_word(const uint16_t *p);
void eeprom_write_word(uint16_t *p, uint16_t v);
void eeprom_update_word(uint16_t *p, uint16_t v);
uint32_t eeprom_read_dword(const uint32_t *p);
void eeprom_write_dword(uint32_t *p, uint32_t v);
void eeprom_update_dword(uint32_t *p, uint32_t v);
void eeprom_read_block(void *dst, const void *src, size_t n);
void eeprom_write_block(const void *src, void *dst, size_t n);
void eeprom_update_block(const void *src, void *dst, size_t n);
#ifdef __cplusplus
}
#endif
#define EEMEM
#endif
