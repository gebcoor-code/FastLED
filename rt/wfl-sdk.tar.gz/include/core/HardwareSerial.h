// Web FastLED: Serial goes to Serial monitor of page
#ifndef HardwareSerial_h
#define HardwareSerial_h
#include <inttypes.h>
#include "Stream.h"

#define SERIAL_8N1 0x06
#define SERIAL_8N2 0x0E
#define SERIAL_7E1 0x24
#define SERIAL_8E1 0x26

class HardwareSerial : public Stream {
  uint8_t _port;
  bool _begun;
public:
  HardwareSerial(uint8_t port) : _port(port), _begun(false) {}
  void begin(unsigned long baud) { begin(baud, SERIAL_8N1); }
  void begin(unsigned long baud, uint8_t config);
  void end() { _begun = false; }
  virtual int available(void);
  virtual int peek(void);
  virtual int read(void);
  virtual int availableForWrite(void) { return 63; }
  virtual void flush(void) {}
  virtual size_t write(uint8_t);
  virtual size_t write(const uint8_t *buffer, size_t size);
  using Print::write;
  operator bool() { return true; }
};

extern HardwareSerial Serial;
#if defined(ARDUINO_AVR_MEGA2560)
extern HardwareSerial Serial1;
extern HardwareSerial Serial2;
extern HardwareSerial Serial3;
#endif
extern void serialEventRun(void) __attribute__((weak));
#endif
