// Web FastLED: SPI (master) for emulator — bytes go to devices of page (OLED SSD1306 over SPI: DC / CS pins tell command,
// data and chip select) through "wfl" import; what comes back is 0. Bytes take bus time (clock of SPISettings, 4 MHz by default).
#ifndef _SPI_H_INCLUDED
#define _SPI_H_INCLUDED
#include <Arduino.h>
#define SPI_HAS_TRANSACTION 1
#define SPI_MODE0 0x00
#define SPI_MODE1 0x04
#define SPI_MODE2 0x08
#define SPI_MODE3 0x0C
#define SPI_CLOCK_DIV4 0x00
#define SPI_CLOCK_DIV16 0x01
#define SPI_CLOCK_DIV64 0x02
#define SPI_CLOCK_DIV128 0x03
#define SPI_CLOCK_DIV2 0x04
#define SPI_CLOCK_DIV8 0x05
#define SPI_CLOCK_DIV32 0x06
class SPISettings {
public:
  SPISettings() {}
  SPISettings(uint32_t clock, uint8_t bitOrder, uint8_t dataMode) : clock(clock) { (void)bitOrder; (void)dataMode; }
  uint32_t clock = 4000000;
};
extern "C" uint8_t wfl_spi_transfer(uint8_t b);
extern "C" void wfl_spi_clock(uint32_t hz);
class SPIClass {
public:
  static void begin() {}
  static void end() {}
  static void beginTransaction(SPISettings s) { wfl_spi_clock(s.clock); }
  static void endTransaction() {}
  static void usingInterrupt(uint8_t n) { (void)n; }
  static void notUsingInterrupt(uint8_t n) { (void)n; }
  static uint8_t transfer(uint8_t b) { return wfl_spi_transfer(b); }
  static uint16_t transfer16(uint16_t d) { uint16_t hi = transfer(d >> 8); return (hi << 8) | transfer(d & 0xFF); }
  static void transfer(void *buf, size_t n) { uint8_t *p = (uint8_t *)buf; for (size_t i = 0; i < n; i++) p[i] = transfer(p[i]); }
  static void setBitOrder(uint8_t o) { (void)o; }
  static void setDataMode(uint8_t m) { (void)m; }
  static void setClockDivider(uint8_t d) { static const uint8_t div[8] = { 4, 16, 64, 128, 2, 8, 32, 128 }; wfl_spi_clock(16000000UL / div[d & 7]); }
};
extern SPIClass SPI;
#endif
