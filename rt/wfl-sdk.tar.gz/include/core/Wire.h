// Web FastLED: Wire (I2C master) for emulator — bytes go to devices of page (OLED SSD1306 …) through "wfl" imports.
// Transfers take bus time (setClock(), 100 kHz by default), so loop() with display update runs as slow as on board.
// endTransmission() gives 2 (address NACK) when page has no device at that address, as I2C scanner sketches expect.
#ifndef TwoWire_h
#define TwoWire_h
#include <inttypes.h>
#include "Stream.h"
#define BUFFER_LENGTH 32
#define WIRE_HAS_END 1
class TwoWire : public Stream {
  uint8_t txAddr = 0, txBuf[BUFFER_LENGTH], rxBuf[BUFFER_LENGTH];
  uint8_t txLen = 0, rxLen = 0, rxPos = 0;
  bool tx = false;
public:
  void begin() {}
  void begin(uint8_t addr) { (void)addr; }
  void begin(int addr) { (void)addr; }
  void begin(int sda, int scl) { (void)sda; (void)scl; } // ESP8266 / ESP32 form
  void end() {}
  void setClock(uint32_t hz) { if (hz >= 1000) clock = hz; }
  uint32_t clock = 100000; // bus time of transfers (as on board: 9 clocks per byte with ACK)
  void setWireTimeout(uint32_t t = 25000, bool reset = false) { (void)t; (void)reset; }
  void beginTransmission(uint8_t addr) { txAddr = addr; txLen = 0; tx = true; }
  void beginTransmission(int addr) { beginTransmission((uint8_t)addr); }
  uint8_t endTransmission(bool stop);
  uint8_t endTransmission() { return endTransmission(true); }
  uint8_t requestFrom(uint8_t addr, uint8_t qty, uint8_t stop);
  uint8_t requestFrom(uint8_t addr, uint8_t qty) { return requestFrom(addr, qty, (uint8_t)1); }
  uint8_t requestFrom(int addr, int qty) { return requestFrom((uint8_t)addr, (uint8_t)qty, (uint8_t)1); }
  uint8_t requestFrom(int addr, int qty, int stop) { return requestFrom((uint8_t)addr, (uint8_t)qty, (uint8_t)stop); }
  size_t write(uint8_t b) override { if (!tx || txLen >= BUFFER_LENGTH) return 0; txBuf[txLen++] = b; return 1; }
  size_t write(const uint8_t *p, size_t n) override { size_t k = 0; while (k < n && write(p[k])) k++; return k; }
  int available() override { return rxLen - rxPos; }
  int read() override { return rxPos < rxLen ? rxBuf[rxPos++] : -1; }
  int peek() override { return rxPos < rxLen ? rxBuf[rxPos] : -1; }
  void flush() override {}
  void onReceive(void (*f)(int)) { (void)f; }
  void onRequest(void (*f)(void)) { (void)f; }
  using Print::write;
  inline size_t write(unsigned long n) { return write((uint8_t)n); }
  inline size_t write(long n) { return write((uint8_t)n); }
  inline size_t write(unsigned int n) { return write((uint8_t)n); }
  inline size_t write(int n) { return write((uint8_t)n); }
};
extern TwoWire Wire;
extern TwoWire Wire1;
#endif
