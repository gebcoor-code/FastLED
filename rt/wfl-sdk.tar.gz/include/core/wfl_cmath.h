// Web FastLED: put before sketch when C++ library headers are on (newer FastLED). libc++ <math.h> adds C++ overloads
// (float sqrt(float) …) to global namespace, so sketch's own float sqrt(float) clashes with it (not so on AVR, where
// <math.h> is C header). C <math.h> only: its include guard of libc++ is taken first.
#pragma once
#if defined(__cplusplus) && !defined(_LIBCPP_MATH_H)
#define _LIBCPP_MATH_H
#include <wasm32-wasip1/math.h>
#endif
