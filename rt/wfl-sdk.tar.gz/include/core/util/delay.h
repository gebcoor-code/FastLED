#ifndef _UTIL_DELAY_H_
#define _UTIL_DELAY_H_
#ifdef __cplusplus
extern "C" {
#endif
void wfl_delay_us(unsigned long us);
#ifdef __cplusplus
}
#endif
#define _delay_ms(ms) wfl_delay_us((unsigned long)((ms) * 1000.0))
#define _delay_us(us) wfl_delay_us((unsigned long)(us))
#endif
