#ifndef Stream_h
#define Stream_h
#include <inttypes.h>
#include "Print.h"
class Stream : public Print {
protected:
  unsigned long _timeout;
  unsigned long _startMillis;
  int timedRead();
  int timedPeek();
  int peekNextDigit(bool detectDecimal);
public:
  virtual int available() = 0;
  virtual int read() = 0;
  virtual int peek() = 0;
  Stream() { _timeout = 1000; }
  void setTimeout(unsigned long timeout) { _timeout = timeout; }
  unsigned long getTimeout(void) { return _timeout; }
  bool find(const char *target) { return findUntil(target, NULL); }
  bool find(char target) { char t[2] = { target, 0 }; return find(t); }
  bool findUntil(const char *target, const char *terminator);
  long parseInt();
  float parseFloat();
  size_t readBytes(char *buffer, size_t length);
  size_t readBytes(uint8_t *buffer, size_t length) { return readBytes((char *)buffer, length); }
  size_t readBytesUntil(char terminator, char *buffer, size_t length);
  size_t readBytesUntil(char terminator, uint8_t *buffer, size_t length) { return readBytesUntil(terminator, (char *)buffer, length); }
  String readString();
  String readStringUntil(char terminator);
};
#endif
