// ok no namespace fl
#pragma once

// IWYU pragma: private

#ifdef __EMSCRIPTEN__
#include "platforms/wasm/led_sysdefs_wasm.h"
#else
#include "platforms/stub/led_sysdefs_stub_generic.h"
#endif
