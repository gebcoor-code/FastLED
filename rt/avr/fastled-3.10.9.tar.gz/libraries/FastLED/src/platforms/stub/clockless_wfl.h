#pragma once
// IWYU pragma: private
// Web FastLED: clockless controllers hand final pixels (after brightness, color correction, dithering and color order)
// to emulator (wfl_led_buffer / wfl_led_show of runtime core), back in logical R, G, B order — as own stub of 3.7.8 does

#define FASTLED_CLOCKLESS_STUB_DEFINED
#define FASTLED_HAS_CLOCKLESS 1

#include "eorder.h"
#include "fl/chipsets/timing_traits.h"
#include "pixel_controller.h"
#include "fl/stl/noexcept.h"

extern "C" uint8_t *wfl_led_buffer(int pin, int count);
extern "C" void wfl_led_show(int pin, int count, int bit_ns);

namespace fl {
#define FL_CLOCKLESS_CONTROLLER_DEFINED 1

template <int DATA_PIN, EOrder RGB_ORDER>
inline void wflShow(PixelController<RGB_ORDER> &pixels, int bit_ns) {
	const int n = pixels.size();
	uint8_t *out = wfl_led_buffer(DATA_PIN, n);
	pixels.preStepFirstByteDithering();
	for (int i = 0; i < n && pixels.has(1); i++) {
		out[i * 3 + RGB_BYTE0(RGB_ORDER)] = pixels.loadAndScale0();
		out[i * 3 + RGB_BYTE1(RGB_ORDER)] = pixels.loadAndScale1();
		out[i * 3 + RGB_BYTE2(RGB_ORDER)] = pixels.loadAndScale2();
		pixels.advanceData();
		pixels.stepDithering();
	}
	wfl_led_show(DATA_PIN, n, bit_ns);
}

template <int DATA_PIN, typename TIMING, EOrder RGB_ORDER = RGB, int XTRA0 = 0, bool FLIP = false, int WAIT_TIME = 0>
class ClocklessController : public CPixelLEDController<RGB_ORDER> {
public:
	virtual void init() { }
protected:
	virtual void showPixels(PixelController<RGB_ORDER> &pixels) FL_NO_EXCEPT { wflShow<DATA_PIN, RGB_ORDER>(pixels, (int)TimingTraits<TIMING>::BIT_PERIOD); }
};
template <int DATA_PIN, typename TIMING_LIKE, EOrder RGB_ORDER = RGB, int XTRA0 = 0, bool FLIP = false, int WAIT_TIME = 0>
struct ClocklessControllerAdapter : public CPixelLEDController<RGB_ORDER> {
	virtual void init() { }
protected:
	virtual void showPixels(PixelController<RGB_ORDER> &pixels) FL_NO_EXCEPT { wflShow<DATA_PIN, RGB_ORDER>(pixels, 1250); }
};
template <int DATA_PIN, typename TIMING, EOrder RGB_ORDER = RGB, int XTRA0 = 0, bool FLIP = false, int WAIT_TIME = 0>
class ClocklessBlockController : public CPixelLEDController<RGB_ORDER> {
public:
	virtual void init() { }
protected:
	virtual void showPixels(PixelController<RGB_ORDER> &pixels) FL_NO_EXCEPT { wflShow<DATA_PIN, RGB_ORDER>(pixels, (int)TimingTraits<TIMING>::BIT_PERIOD); }
};
}  // namespace fl
