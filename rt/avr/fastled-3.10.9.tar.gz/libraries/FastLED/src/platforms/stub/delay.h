#pragma once

// IWYU pragma: private

#ifndef __INC_FASTLED_PLATFORMS_STUB_DELAY_H
#define __INC_FASTLED_PLATFORMS_STUB_DELAY_H

#include "platforms/cycle_type.h"
#include "fl/stl/compiler_control.h"
#include "fl/stl/noexcept.h"

#if !defined(ARDUINO) || defined(FASTLED_USE_STUB_ARDUINO)
// Defined in platforms/stub/time_stub.cpp.hpp.
bool isDelayOverrideActive(void) FL_NO_EXCEPT;
#define FL_STUB_SKIP_TIMING() isDelayOverrideActive()
#else
#define FL_STUB_SKIP_TIMING() false
#endif

/// @file platforms/stub/delay.h
/// Stub platform-specific nanosecond-precision delay utilities
/// Uses generic delay_cycles for cycle-accurate delays

/// Convert nanoseconds to CPU cycles for stub platform
/// @param ns Number of nanoseconds
/// @param cpu_hz CPU frequency in Hz
/// @return Number of cycles (rounded up)
constexpr fl::u32 cycles_from_ns_stub(fl::u32 ns, fl::u32 cpu_hz) FL_NO_EXCEPT {
  // Round up: cycles = ceil(ns * cpu_hz / 1e9)
  // = (ns * cpu_hz + 999'999'999) / 1'000'000'000
  return fl::cycles_from_ns(ns, cpu_hz);
}

namespace fl {

/// Platform-specific implementation of nanosecond delay with runtime frequency (stub)
/// @param ns Number of nanoseconds
/// @param hz CPU frequency in Hz
FASTLED_FORCE_INLINE void delayNanoseconds_impl(u32 ns, u32 hz) FL_NO_EXCEPT {
  // Fast-exit host example runs install a delay override; wire-timing spins
  // (bit-bang drivers on the stub) are skipped too, or every show() costs
  // milliseconds of real time (#4709).
  if (FL_STUB_SKIP_TIMING()) return;
  u32 cycles = cycles_from_ns_stub(ns, hz);
  if (cycles == 0) return;
  delay_cycles_generic(cycles);
}

/// Platform-specific implementation of nanosecond delay with auto-detected frequency (stub)
/// @param ns Number of nanoseconds
FASTLED_FORCE_INLINE void delayNanoseconds_impl(u32 ns) FL_NO_EXCEPT {
  #if defined(F_CPU)
  u32 hz = F_CPU;
  #else
  u32 hz = 16000000UL;  // Common Arduino default
  #endif
  delayNanoseconds_impl(ns, hz);
}

}  // namespace fl

#endif // __INC_FASTLED_PLATFORMS_STUB_DELAY_H
