// IWYU pragma: private

// ok no namespace fl
#if defined(FASTLED_STUB_IMPL) && !defined(WEB_FASTLED)  // Only use this if explicitly defined. Web FastLED: pinMode of emulator

#include "platforms/stub/led_sysdefs_stub.h"
#include "fl/stl/compiler_control.h"
#include "fl/stl/noexcept.h"


// No timing-related includes needed here anymore

void pinMode(fl::u8 pin, fl::u8 mode) FL_NO_EXCEPT {
    // Empty stub as we don't actually ever write anything
    FASTLED_UNUSED(pin);
    FASTLED_UNUSED(mode);
}

// Timing functions are now provided by time_stub.cpp
// This keeps only pinMode here for simplicity

#endif  // FASTLED_STUB_IMPL
