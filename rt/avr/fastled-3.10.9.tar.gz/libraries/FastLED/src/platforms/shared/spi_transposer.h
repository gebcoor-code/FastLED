#pragma once

// IWYU pragma: private

/// @file spi_transposer.h
/// @brief Unified bit-interleaving transpose logic for multi-lane SPI parallel LED control
///
/// @deprecated This header is maintained for backwards compatibility.
/// New code should use fl/transposition.h directly.

// ok no namespace fl

#include "fl/math/transposition.h"
