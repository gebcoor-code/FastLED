// IWYU pragma: private

#include "platforms/shared/ui/json/title.h"
#include "fl/stl/json.h"
#include "platforms/shared/ui/json/ui.h"
#include "fl/stl/noexcept.h"
namespace fl {

class JsonUiTitleInternal : public JsonUiInternal {
  private:
    fl::string mText;

  public:
    // Constructor: Initializes the base JsonUiInternal with name, and sets the
    // title text.
    JsonUiTitleInternal(const fl::string &name, const fl::string &text)
 FL_NO_EXCEPT : JsonUiInternal(name), mText(text) {}

    // Override toJson to serialize the title's data directly.
    // This function will be called by JsonUiManager to get the component's
    // state.
    void toJson(fl::json &json) const FL_NO_EXCEPT override {
        json.set("name", name());
        json.set("type", "title");
        json.set("group",
                 groupName()); // Assuming groupName() is accessible from base
        json.set("id", id());  // Assuming id() is accessible from base
        json.set("text", mText);
    }

    // Override updateInternal. Titles typically don't have update functionality
    // from the UI, so this can be a no-op.
    void updateInternal(const fl::json &json) FL_NO_EXCEPT override {
        // No update needed for title components
        FL_UNUSED(json);
    }

    // Accessors for the title text.
    const fl::string &text() const FL_NO_EXCEPT { return mText; }
    void setText(const fl::string &text) FL_NO_EXCEPT { mText = text; }
};

// Constructor implementation
JsonTitleImpl::JsonTitleImpl(const fl::string &name, const fl::string &text) FL_NO_EXCEPT {
    // Create an instance of the new internal class
    mInternal = fl::make_shared<JsonUiTitleInternal>(name, text);

    // Register the component with the JsonUiManager
    addJsonUiComponent(mInternal);
}

// Destructor implementation
JsonTitleImpl::~JsonTitleImpl() {
    // Ensure the component is removed from the global registry
    removeJsonUiComponent(fl::weak_ptr<JsonUiInternal>(mInternal));

    // No need to clear functions anymore as there are no lambdas capturing
    // 'this' if (mInternal) {
    //     mInternal->clearFunctions();
    // }
}

JsonTitleImpl &JsonTitleImpl::Group(const fl::string &name) FL_NO_EXCEPT {
    mInternal->setGroup(name);
    return *this;
}

const string &JsonTitleImpl::name() const FL_NO_EXCEPT { return mInternal->name(); }

fl::string JsonTitleImpl::groupName() const FL_NO_EXCEPT {
    return mInternal->groupName();
}

// Delegate text accessors to the internal object
const fl::string &JsonTitleImpl::text() const FL_NO_EXCEPT { return mInternal->text(); }

void JsonTitleImpl::setText(const fl::string &text) FL_NO_EXCEPT {
    mInternal->setText(text);
}

void JsonTitleImpl::setGroup(const fl::string &groupName) FL_NO_EXCEPT {
    mInternal->setGroup(groupName);
}

int JsonTitleImpl::id() const FL_NO_EXCEPT { return mInternal->id(); }

} // namespace fl
