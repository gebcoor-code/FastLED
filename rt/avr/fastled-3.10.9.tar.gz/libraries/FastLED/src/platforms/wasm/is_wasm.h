#pragma once

// IWYU pragma: private

// ok no namespace fl

/// @file is_wasm.h
/// WebAssembly platform detection header
///
/// This header detects WebAssembly/Emscripten platforms by checking
/// compiler-defined macros and defines standardized FL_IS_WASM macro.
///
/// Defines:
/// - FL_IS_WASM: WebAssembly platform (Emscripten)

// ============================================================================
// FL_IS_WASM - WebAssembly platform detection
// ============================================================================
// Web FastLED: wasm32-wasip1 build of sketch is not emscripten platform (stub platform with own LED output)
#if (defined(__EMSCRIPTEN__) || defined(__wasm__) || defined(EMSCRIPTEN)) && !defined(WEB_FASTLED)
#define FL_IS_WASM
#endif
