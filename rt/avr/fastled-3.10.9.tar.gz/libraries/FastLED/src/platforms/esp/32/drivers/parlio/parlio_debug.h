/// @file parlio_debug.h
/// @brief Debug metrics and utilities for PARLIO driver

#pragma once

// IWYU pragma: private

#include "fl/stl/compiler_control.h"
#include "fl/stl/stdint.h"

namespace fl {
namespace detail {

//=============================================================================
// Debug Metrics Structure
//=============================================================================

struct ParlioDebugMetrics {
    u64 mStartTimeUs;
    u64 mEndTimeUs;
    u32 mIsrCount;
    u32 mChunksQueued;
    u32 mChunksCompleted;
    u32 mBytesTotal;
    u32 mBytesTransmitted;
    u32 mTxDoneCount;
    u32 mWorkerIsrCount;
    u32 mUnderrunCount;
    u32 mRingCount;
    u32 mErrorCode;
    bool mRingError;
    bool mHardwareIdle;
    bool mTransmissionActive;
};

} // namespace detail
} // namespace fl
