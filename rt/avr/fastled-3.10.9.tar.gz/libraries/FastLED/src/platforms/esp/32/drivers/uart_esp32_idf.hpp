// IWYU pragma: private

// ESP32 UART Driver Implementation - Full Feature Support

#include "platforms/is_platform.h"
#ifdef FL_IS_ESP32

#include "platforms/esp/32/drivers/uart_esp32.h"
#include "fl/stl/assert.h"
#include "fl/stl/compiler_control.h"
#include "fl/stl/singleton.h"
#include "fl/stl/noexcept.h"
#include "fl/stl/has_include.h"
#include "platforms/esp/esp_version.h"

// Arduino's C UART HAL owns an additional mutex used by Serial.begin().
// Older cores assume that mutex already exists when replacing an SDK driver.
#if FL_HAS_INCLUDE("esp32-hal-uart.h") && FL_HAS_INCLUDE("esp_arduino_version.h")
#include "esp_arduino_version.h"
#if ESP_ARDUINO_VERSION_MAJOR == 2 && ESP_ARDUINO_VERSION < ESP_ARDUINO_VERSION_VAL(2, 0, 17)
#include <esp32-hal-uart.h> // IWYU pragma: keep
#define FL_CONSOLE_NEEDS_ARDUINO_UART_BOOTSTRAP 1
// Address-only weak references do not extract HardwareSerial from an archive.
// These are the SDK's actual global object types, never a guessed class ABI.
class HardwareSerial;
#if defined(ARDUINO_USB_CDC_ON_BOOT) && ARDUINO_USB_CDC_ON_BOOT
extern HardwareSerial Serial0 FL_LINK_WEAK;
#define FL_CONSOLE_ARDUINO_UART0_OBJECT Serial0
#else
extern HardwareSerial Serial FL_LINK_WEAK;
#define FL_CONSOLE_ARDUINO_UART0_OBJECT Serial
#endif
#else
#define FL_CONSOLE_NEEDS_ARDUINO_UART_BOOTSTRAP 0
#endif
#else
#define FL_CONSOLE_NEEDS_ARDUINO_UART_BOOTSTRAP 0
#endif

// ESP-IDF headers (only in .cpp.hpp, not in .h)
FL_EXTERN_C_BEGIN
// IWYU pragma: begin_keep
#include "driver/uart.h"
// IWYU pragma: end_keep
#if ESP_IDF_VERSION_4_OR_HIGHER
#include "esp_rom_uart.h"
#else
// IWYU pragma: begin_keep
#include "rom/uart.h"
// IWYU pragma: end_keep
#endif
// IWYU pragma: begin_keep
#include "freertos/FreeRTOS.h"  // For vTaskDelay
// IWYU pragma: end_keep
// IWYU pragma: begin_keep
#include "freertos/task.h"       // For portTICK_PERIOD_MS
// IWYU pragma: end_keep
FL_EXTERN_C_END

// Compatibility: esp_rom_output_tx_one_char was added in ESP-IDF 5.3.
// Older IDF versions only have esp_rom_uart_tx_one_char.
#if !ESP_IDF_VERSION_4_OR_HIGHER
#define esp_rom_output_tx_one_char(c) uart_tx_one_char(c)
#define esp_rom_output_tx_wait_idle(n) uart_tx_wait_idle(n)
#define UART_SIGNAL_TXD_INV UART_INVERSE_TXD
#define UART_SIGNAL_RXD_INV UART_INVERSE_RXD
#define UART_SIGNAL_RTS_INV UART_INVERSE_RTS
#define UART_SIGNAL_CTS_INV UART_INVERSE_CTS
#elif ESP_IDF_VERSION < ESP_IDF_VERSION_VAL(5, 3, 0)
#define esp_rom_output_tx_one_char(c) esp_rom_uart_tx_one_char(c)
#define esp_rom_output_tx_wait_idle(n) esp_rom_uart_tx_wait_idle(n)
#endif

namespace fl {

// ============================================================================
// Helper: Convert fl enum classes to ESP-IDF types
// ============================================================================

static FASTLED_FORCE_INLINE uart_port_t convertPort(UartPort port) FL_NO_EXCEPT {
    return static_cast<uart_port_t>(static_cast<u8>(port));
}

static FASTLED_FORCE_INLINE uart_word_length_t convertDataBits(UartDataBits bits) FL_NO_EXCEPT {
    switch (bits) {
        case UartDataBits::BITS_5: return UART_DATA_5_BITS;
        case UartDataBits::BITS_6: return UART_DATA_6_BITS;
        case UartDataBits::BITS_7: return UART_DATA_7_BITS;
        case UartDataBits::BITS_8: return UART_DATA_8_BITS;
        default: return UART_DATA_8_BITS;
    }
}

static FASTLED_FORCE_INLINE uart_parity_t convertParity(UartParity parity) FL_NO_EXCEPT {
    switch (parity) {
        case UartParity::NONE: return UART_PARITY_DISABLE;
        case UartParity::ODD:  return UART_PARITY_ODD;
        case UartParity::EVEN: return UART_PARITY_EVEN;
        default: return UART_PARITY_DISABLE;
    }
}

static FASTLED_FORCE_INLINE uart_stop_bits_t convertStopBits(UartStopBits bits) FL_NO_EXCEPT {
    switch (bits) {
        case UartStopBits::BITS_1:   return UART_STOP_BITS_1;
        case UartStopBits::BITS_1_5: return UART_STOP_BITS_1_5;
        case UartStopBits::BITS_2:   return UART_STOP_BITS_2;
        default: return UART_STOP_BITS_1;
    }
}

static FASTLED_FORCE_INLINE uart_hw_flowcontrol_t convertFlowControl(UartFlowControl ctrl) FL_NO_EXCEPT {
    switch (ctrl) {
        case UartFlowControl::NONE:    return UART_HW_FLOWCTRL_DISABLE;
        case UartFlowControl::RTS:     return UART_HW_FLOWCTRL_RTS;
        case UartFlowControl::CTS:     return UART_HW_FLOWCTRL_CTS;
        case UartFlowControl::RTS_CTS: return UART_HW_FLOWCTRL_CTS_RTS;
        default: return UART_HW_FLOWCTRL_DISABLE;
    }
}

static FASTLED_FORCE_INLINE int convertIntrFlags(UartIntrPriority priority, UartIntrFlags flags) FL_NO_EXCEPT {
    int esp_flags = 0;

    // Add priority level (LEVEL1-5)
    // ESP-IDF uses ESP_INTR_FLAG_LEVEL1/2/3/4/5
    // Encoded as (1 << level) in lower bits
    int level = static_cast<int>(priority);
    esp_flags |= (1 << level);

    // Add IRAM flag if requested (ESP_INTR_FLAG_IRAM = 0x400)
    bool use_iram = (static_cast<u8>(flags) & static_cast<u8>(UartIntrFlags::IRAM)) != 0;
    if (use_iram) {
        esp_flags |= ESP_INTR_FLAG_IRAM;
    }

    // Add SHARED flag if requested (ESP_INTR_FLAG_SHARED = 0x800)
    bool use_shared = (static_cast<u8>(flags) & static_cast<u8>(UartIntrFlags::SHARED)) != 0;
    if (use_shared) {
        esp_flags |= ESP_INTR_FLAG_SHARED;
    }

    return esp_flags;
}

// ESP-IDF version compatibility for UART clock source:
// - UART_SCLK_DEFAULT, UART_SCLK_APB, etc. are C enum constants (not #define macros)
//   so #if defined() cannot detect them. Use version-based checks instead.
// - IDF 5.0+: UART_SCLK_DEFAULT exists on all variants (maps to chip's preferred clock)
// - IDF 4.x: UART_SCLK_APB is the universal clock source
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0)
static FASTLED_FORCE_INLINE uart_sclk_t convertClockSource(UartClockSource) FL_NO_EXCEPT {
    // UART_SCLK_DEFAULT is the portable choice on IDF 5.x — it resolves to
    // the chip's preferred clock (APB on ESP32/S3/C3, PLL_F80M on C6, etc.)
    return UART_SCLK_DEFAULT;
}
#elif ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 0, 0)
static FASTLED_FORCE_INLINE uart_sclk_t convertClockSource(UartClockSource) FL_NO_EXCEPT {
    return UART_SCLK_APB;
}
#endif

// ============================================================================
// UartManager Implementation (Internal)
// ============================================================================

namespace {

/**
 * @brief UART allocation manager (singleton) - INTERNAL IMPLEMENTATION DETAIL
 *
 * Tracks which UART ports are currently allocated to prevent double allocation.
 * FL_ASSERT fires if attempting to allocate an already-allocated UART.
 *
 * THREAD SAFETY: Not thread-safe - allocate UARTs during setup(), not from multiple tasks.
 */
class UartManager {
public:
    static UartManager& instance() FL_NO_EXCEPT {
        return fl::Singleton<UartManager>::instance();
    }

    bool allocateUart(UartPort port) FL_NO_EXCEPT {
        int index = static_cast<int>(port);
        FL_ASSERT(index >= 0 && index < 3, "Invalid UART port");
        FL_ASSERT(!mAllocated[index], "UART port already allocated");

        mAllocated[index] = true;
        return true;
    }

    void deallocateUart(UartPort port) FL_NO_EXCEPT {
        int index = static_cast<int>(port);
        if (index >= 0 && index < 3) {
            mAllocated[index] = false;
        }
    }

    bool isAllocated(UartPort port) const FL_NO_EXCEPT {
        int index = static_cast<int>(port);
        if (index < 0 || index >= 3) {
            return false;
        }
        return mAllocated[index];
    }

private:
    bool mAllocated[3] = {false, false, false};  // UART0, UART1, UART2

    UartManager() = default;
    friend class fl::Singleton<UartManager>;
};

} // anonymous namespace

// ============================================================================
// UartEsp32 Implementation
// ============================================================================

FASTLED_FORCE_INLINE bool UartEsp32::initDriver(const UartConfig& config) FL_NO_EXCEPT {
    uart_port_t port = static_cast<uart_port_t>(mPortInt);

    // ROBUST DRIVER DETECTION:
    // Use uart_get_buffered_data_len() as the definitive test for driver installation.
    // This is more reliable than uart_write_bytes(port, "", 0) which can succeed even
    // without a driver installed (0-byte write is a no-op).
    size_t buffered_len = 0;
    esp_err_t check_err = uart_get_buffered_data_len(port, &buffered_len);

    if (check_err == ESP_OK) {
        // Driver is installed and working - use it
        mBuffered = true;
        return true;  // Success: driver is installed and functional
    }

    // Driver not installed - install it ourselves

    // Configure UART parameters from UartConfig
    uart_config_t uart_config = {};
    uart_config.baud_rate = static_cast<int>(config.baudRate);
    uart_config.data_bits = convertDataBits(config.dataBits);
    uart_config.parity = convertParity(config.parity);
    uart_config.stop_bits = convertStopBits(config.stopBits);
    uart_config.flow_ctrl = convertFlowControl(config.flowControl);
    uart_config.rx_flow_ctrl_thresh = static_cast<u8>(config.rxFlowControlThresh);

    // Set clock source (version-dependent field)
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(4, 0, 0)
    uart_config.source_clk = convertClockSource(config.clockSource);
#endif
    // IDF 3.x: source_clk field doesn't exist - skip it

    esp_err_t err = uart_param_config(port, &uart_config);
    if (err != ESP_OK) {
        return false;  // Failed - mBuffered remains false, will use ROM UART
    }

    // Configure pins if specified
    if (config.pins.txPin >= 0 || config.pins.rxPin >= 0 ||
        config.pins.rtsPin >= 0 || config.pins.ctsPin >= 0) {
        err = uart_set_pin(
            port,
            config.pins.txPin,   // TX pin
            config.pins.rxPin,   // RX pin
            config.pins.rtsPin,  // RTS pin
            config.pins.ctsPin   // CTS pin
        );
        if (err != ESP_OK) {
            return false;  // Pin configuration failed
        }
    }

    // Configure signal inversion if requested
    if (config.signalInvert.txInvert || config.signalInvert.rxInvert ||
        config.signalInvert.rtsInvert || config.signalInvert.ctsInvert) {
        u32 inv_mask = 0;
        if (config.signalInvert.txInvert)  inv_mask |= UART_SIGNAL_TXD_INV;
        if (config.signalInvert.rxInvert)  inv_mask |= UART_SIGNAL_RXD_INV;
        if (config.signalInvert.rtsInvert) inv_mask |= UART_SIGNAL_RTS_INV;
        if (config.signalInvert.ctsInvert) inv_mask |= UART_SIGNAL_CTS_INV;

        err = uart_set_line_inverse(port, inv_mask);
        if (err != ESP_OK) {
            return false;  // Signal inversion failed
        }
    }

    // Convert interrupt priority + flags to ESP-IDF format
    int intr_alloc_flags = convertIntrFlags(config.intrPriority, config.intrFlags);

    // Install driver with TX and RX buffers from config
    // Event queue: 0 = polling mode (we use uart_read_bytes directly)
    //             >0 = event-driven mode (ISR posts uart_event_t to queue)
    // Interrupt flags: Controls ISR priority and IRAM placement
    //   ESP_INTR_FLAG_IRAM (0x400) = ISR runs from IRAM (survives flash cache disable)
    //   ESP_INTR_FLAG_LEVEL1-5 = ISR priority level
    void** queue_handle_ptr = config.eventQueueSize > 0 ? &mEventQueue : nullptr;

    err = uart_driver_install(
        port,
        static_cast<int>(config.rxBufferSize),      // RX buffer size
        static_cast<int>(config.txBufferSize),      // TX buffer size
        static_cast<int>(config.eventQueueSize),    // Event queue size (0 = no queue)
        (QueueHandle_t*)queue_handle_ptr,            // Event queue handle
        intr_alloc_flags                             // ISR priority + flags
    );

    if (err == ESP_OK || err == ESP_ERR_INVALID_STATE) {
        // ESP_ERR_INVALID_STATE means already installed - OK
        mBuffered = true;

        // CRITICAL FIX: Add delay after driver installation
        // ESP-IDF UART driver requires a delay after installation before transmitting
        // Without this, uart_write_bytes() will succeed but data won't transmit
        // Reference: https://esp32.com/viewtopic.php?t=2319
        vTaskDelay(100 / portTICK_PERIOD_MS);  // 100ms delay

        // Configure RS485 mode if enabled
        if (config.rs485Config.enabled) {
            // Note: RS485 mode configuration varies by ESP-IDF version
            // For now, we assume RTS pin is already configured above
            // and ESP-IDF will handle RS485 mode automatically if RTS is set
            // Future: Add explicit uart_set_mode(UART_MODE_RS485_HALF_DUPLEX) if available
        }

        return true;
    }

    // Installation failed - will fall back to ROM UART
    return false;
}

FASTLED_FORCE_INLINE void UartEsp32::initialize(const UartConfig& config) FL_NO_EXCEPT {
    // Check allocation status
    UartManager& manager = UartManager::instance();
    FL_ASSERT(!manager.isAllocated(config.port),
              "UART port already allocated - cannot allocate twice");

    // Allocate the UART
    manager.allocateUart(config.port);

    // Initialize driver
    initDriver(config);
}

UartEsp32::UartEsp32() FL_NO_EXCEPT
    : mConfig(UartConfig::minimal(UartPort::UART0))
    , mPortInt(static_cast<fl::i32>(convertPort(UartPort::UART0)))
    , mBuffered(false)
    , mEventQueue(nullptr) {
    // Console traffic must not consume the level-3 interrupt reserved for
    // timing-sensitive peripherals such as RMT. Match the SDK UART default.
    const UartConfig config = UartConfig::minimal(UartPort::UART0);
#if FL_CONSOLE_NEEDS_ARDUINO_UART_BOOTSTRAP
    if (&::FL_CONSOLE_ARDUINO_UART0_OBJECT && !uart_is_driver_installed(UART_NUM_0)) {
        // Bootstrap through the C HAL so a later Arduino Serial.begin() can
        // replace this driver safely. Adopt existing owners without changing
        // their pins, baud or buffer configuration. No HardwareSerial ABI.
        // HAL packs parity in bits 0-1, data width in 2-3 and stop bits in 4-5.
        constexpr u32 format8N1 = static_cast<u32>(UART_PARITY_DISABLE) |
            (static_cast<u32>(UART_DATA_8_BITS) << 2) |
            (static_cast<u32>(UART_STOP_BITS_1) << 4);
        (void)uartBegin(0, config.baudRate, format8N1, -1, -1,
            config.rxBufferSize, config.txBufferSize, false, 120);
    }
#endif
    initialize(config);
}

UartEsp32::UartEsp32(const UartConfig& config) FL_NO_EXCEPT
    : mConfig(config)
    , mPortInt(static_cast<int>(convertPort(config.port)))
    , mBuffered(false)
    , mEventQueue(nullptr) {

    initialize(mConfig);
}

UartEsp32::~UartEsp32() {
    // Deallocate UART
    if (mPortInt >= 0) {
        UartManager& manager = UartManager::instance();
        manager.deallocateUart(mConfig.port);
    }
}

UartEsp32::UartEsp32(UartEsp32&& other) FL_NO_EXCEPT
    : mConfig(other.mConfig)
    , mPortInt(other.mPortInt)
    , mBuffered(other.mBuffered)
    , mEventQueue(other.mEventQueue) {
    // Mark other as invalid (prevent deallocation)
    other.mPortInt = -1;
    other.mEventQueue = nullptr;
}

UartEsp32& UartEsp32::operator=(UartEsp32&& other) FL_NO_EXCEPT {
    if (this != &other) {
        // Deallocate our current UART
        if (mPortInt >= 0) {
            UartManager& manager = UartManager::instance();
            manager.deallocateUart(mConfig.port);
        }

        // Take ownership of other's UART
        mConfig = other.mConfig;
        mPortInt = other.mPortInt;
        mBuffered = other.mBuffered;
        mEventQueue = other.mEventQueue;

        // Mark other as invalid
        other.mPortInt = -1;
        other.mEventQueue = nullptr;
    }
    return *this;
}


bool UartEsp32::setBaudRate(u32 baudRate) FL_NO_EXCEPT {
    if (!mBuffered || baudRate == 0 || baudRate > 0x7fffffffu) {
        return false;
    }
    const auto port = static_cast<uart_port_t>(mPortInt);
    if (uart_set_baudrate(port, baudRate) != ESP_OK) {
        return false;
    }
    mConfig.baudRate = baudRate;
    return true;
}

void UartEsp32::write(const char* str) FL_NO_EXCEPT {
    if (!str)
        return;

    uart_port_t port = static_cast<uart_port_t>(mPortInt);

    if (mBuffered) {
        // Use uart_write_bytes() - copies to TX ring buffer, non-blocking
        size_t len = 0;
        const char* p = str;
        while (*p++) len++;

        int written = uart_write_bytes(port, str, len);
        (void)written;  // Suppress unused variable warning in release builds
    } else {
        // Fallback to ROM UART (direct FIFO writes, blocks if full)
        while (*str) {
            esp_rom_output_tx_one_char(*str++);
        }
    }
}

size_t UartEsp32::write(const u8* buffer, size_t size) FL_NO_EXCEPT {
    if (!buffer || size == 0)
        return 0;

    uart_port_t port = static_cast<uart_port_t>(mPortInt);

    if (mBuffered) {
        // Use uart_write_bytes() - handles raw binary data
        // ESP-IDF UART driver handles the buffer internally
        int written = uart_write_bytes(port, static_cast<const char*>(static_cast<const void*>(buffer)), size);
        return (written < 0) ? 0 : static_cast<size_t>(written);
    } else {
        return writeRom(buffer, size);
    }
}

#if ESP_IDF_VERSION_4_OR_HIGHER
// Weak references: they resolve only when another component (Arduino
// Serial, a UartEsp32 instance, ...) already links the SDK UART driver, so
// writeRom() never pulls the driver into a sketch on its own (#4982).
#pragma weak uart_is_driver_installed
#pragma weak uart_write_bytes
#endif

size_t UartEsp32::writeRom(const u8* buffer, size_t size) FL_NO_EXCEPT {
    if (!buffer)
        return 0;
#if ESP_IDF_VERSION_4_OR_HIGHER
    // An installed console driver owns the TX FIFO; queue behind its ring
    // buffer so output stays ordered with Serial.write() and friends.
    if (&uart_is_driver_installed && &uart_write_bytes &&
        uart_is_driver_installed(UART_NUM_0)) {
        const int written = uart_write_bytes(
            UART_NUM_0, static_cast<const char*>(static_cast<const void*>(buffer)), size);
        if (written >= 0) {
            return static_cast<size_t>(written);
        }
        // Driver removed between the check and the write: use the ROM path.
    }
#endif
    // ROM UART (byte-by-byte, blocks while the FIFO is full)
    for (size_t i = 0; i < size; i++) {
        esp_rom_output_tx_one_char(static_cast<char>(buffer[i]));
    }
    return size;
}

void UartEsp32::waitRomIdle() FL_NO_EXCEPT {
    // ROM routine: no SDK driver. Lets ROM-written bytes leave the FIFO
    // before a driver install reconfigures UART0 and resets it. An installed
    // driver (which may use flow control) owns the FIFO: no unbounded wait.
#if ESP_IDF_VERSION_4_OR_HIGHER
    if (&uart_is_driver_installed && uart_is_driver_installed(UART_NUM_0)) {
        return;
    }
#endif
    esp_rom_output_tx_wait_idle(0);
}

void UartEsp32::writeln(const char* str) FL_NO_EXCEPT {
    if (!str)
        return;

    uart_port_t port = static_cast<uart_port_t>(mPortInt);

    if (mBuffered) {
        // Write string and newline
        size_t len = 0;
        const char* p = str;
        while (*p++) len++;

        uart_write_bytes(port, str, len);
        uart_write_bytes(port, "\n", 1);
    } else {
        // Fallback to ROM UART
        while (*str) {
            esp_rom_output_tx_one_char(*str++);
        }
        esp_rom_output_tx_one_char('\n');
    }
}

int UartEsp32::available() FL_NO_EXCEPT {
    if (!mBuffered) {
        return 0;  // Driver not installed, no data available
    }

    uart_port_t port = static_cast<uart_port_t>(mPortInt);
    size_t available = 0;
    esp_err_t err = uart_get_buffered_data_len(port, &available);
    if (err != ESP_OK) {
        return 0;  // Error querying buffer, report no data
    }

    return static_cast<int>(available);
}

int UartEsp32::read() FL_NO_EXCEPT {
    if (!mBuffered) {
        return -1;  // Driver not installed, cannot read
    }

    uart_port_t port = static_cast<uart_port_t>(mPortInt);
    u8 c = 0;
    int len = uart_read_bytes(port, &c, 1, 0);  // timeout=0 (non-blocking)

    if (len == 1) {
        return static_cast<int>(c);  // Success: return byte as unsigned
    } else {
        return -1;  // No data available or error
    }
}

bool UartEsp32::flush(u32 timeoutMs) FL_NO_EXCEPT {
    if (!mBuffered) {
        return false;  // Driver not installed, cannot flush
    }

    uart_port_t port = static_cast<uart_port_t>(mPortInt);

    // Wait for TX FIFO to empty (all data transmitted)
    // Convert milliseconds to FreeRTOS ticks
    TickType_t timeout_ticks = timeoutMs / portTICK_PERIOD_MS;
    esp_err_t err = uart_wait_tx_done(port, timeout_ticks);

    return (err == ESP_OK);
}

} // namespace fl

#endif // FL_IS_ESP32
