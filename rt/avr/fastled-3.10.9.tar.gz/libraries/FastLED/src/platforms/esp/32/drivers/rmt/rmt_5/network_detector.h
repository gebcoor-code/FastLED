#pragma once

// IWYU pragma: private

// Network Detection API for RMT Network-Aware Dynamic Configuration
// Provides runtime network activity detection (WiFi, Ethernet, Bluetooth)
// with graceful fallback for builds without network components linked.

#include "platforms/esp/32/feature_flags/enabled.h"

#if FASTLED_RMT5

#include "fl/stl/stdint.h"
#include "fl/stl/noexcept.h"

namespace fl {

/// @brief Network activity detector for adaptive RMT channel management
///
/// This class provides runtime detection of network activity to enable
/// adaptive RMT channel configuration. It uses weak symbol fallback
/// to gracefully handle builds where network components are not linked.
///
/// **Supported Network Types:**
/// - **WiFi**: ESP32, ESP32-S2, ESP32-S3, ESP32-C3, ESP32-C6, ESP32-H2
/// - **Ethernet**: ESP32 (with external PHY), ESP32-C6
/// - **Bluetooth**: ESP32, ESP32-S3, ESP32-C3, ESP32-C6, ESP32-H2
///
/// **Usage:**
/// @code
/// // Check specific network type
/// if (NetworkDetector::isWiFiActive()) {
///     // WiFi is enabled - use robust configuration
/// }
///
/// // Check if any network is active
/// if (NetworkDetector::isAnyNetworkActive()) {
///     // Some network is active - adjust RMT configuration
/// }
/// @endcode
///
/// **Graceful Fallback:**
/// If network components are not linked, all methods return false (no crashes).
///
/// **Performance:** ~1-10µs per call (ESP-IDF API overhead)
class NetworkDetector {
  public:
    //=========================================================================
    // WiFi Detection
    //=========================================================================

    /// @brief Check if WiFi has been brought up
    ///
    /// Detected through esp_netif (weak-linked), never esp_wifi_*, so sketches
    /// without networking link no Wi-Fi code (#4791). Returns true when the
    /// default Wi-Fi STA or AP netif exists (Arduino WiFi, fl::wifi and IDF
    /// default handlers all create one) or any non-Ethernet netif exists
    /// (custom Wi-Fi netifs; PPP/Thread also count, which is harmless).
    ///
    /// @return false if esp_netif is not linked or no such interface exists
    /// @note Limitation: raw esp_wifi_start() with no netif at all (bare-IDF
    ///       ESP-NOW) is not detected.
    ///
    /// **Platform Support:** ESP32, S2, S3, C3, C6, H2 (not C2)
    static bool isWiFiActive() FL_NO_EXCEPT;

    /// @brief Check if WiFi is connected to an access point
    ///
    /// True when the default STA netif is up and has a non-zero IPv4 address.
    ///
    /// @return false if esp_netif is not linked, no STA netif exists, or it
    ///         has no address yet
    ///
    /// **Use Case:** More precise detection than isWiFiActive() - only
    /// triggers adaptive behavior when WiFi is actively transmitting.
    static bool isWiFiConnected() FL_NO_EXCEPT;

    //=========================================================================
    // Ethernet Detection
    //=========================================================================

    /// @brief Check if Ethernet interface is active (link up)
    ///
    /// Detects if an Ethernet network interface exists and is operational.
    /// Uses ESP-IDF's esp_netif API to enumerate interfaces.
    ///
    /// @return true if Ethernet interface is up, false otherwise
    /// @return false if esp_netif component not linked
    /// @return false if no Ethernet interface found
    ///
    /// **Platform Support:** ESP32 (with external PHY like LAN8720), ESP32-C6
    static bool isEthernetActive() FL_NO_EXCEPT;

    /// @brief Check if Ethernet has a valid IP address
    ///
    /// Detects if Ethernet interface is connected and has obtained an IP address.
    ///
    /// @return true if Ethernet has valid IP, false otherwise
    /// @return false if esp_netif component not linked
    /// @return false if no IP address assigned
    ///
    /// **Use Case:** More precise than isEthernetActive() - confirms actual
    /// network connectivity, not just link status.
    static bool isEthernetConnected() FL_NO_EXCEPT;

    //=========================================================================
    // Bluetooth Detection
    //=========================================================================

    /// @brief Check if Bluetooth controller is active (enabled)
    ///
    /// Detects if Bluetooth Classic or BLE controller is enabled.
    /// Both Classic BT and BLE use the same controller on ESP32.
    ///
    /// @return true if Bluetooth controller is enabled, false otherwise
    /// @return false if Bluetooth component not linked
    /// @return false if controller is idle or only initialized
    ///
    /// **Platform Support:** ESP32, S3, C3, C6, H2 (not S2)
    ///
    /// **Note:** This detects both Classic Bluetooth and BLE (they share
    /// the same controller). If you need to distinguish between them, use
    /// additional ESP-IDF APIs.
    static bool isBluetoothActive() FL_NO_EXCEPT;

    //=========================================================================
    // Convenience Methods (Shorthand)
    //=========================================================================

    /// @brief Check if any network type is active
    ///
    /// Convenience method that returns true if any of WiFi, Ethernet, or
    /// Bluetooth is currently active.
    ///
    /// @return true if any network is active, false if all are inactive
    ///
    /// **Equivalent to:**
    /// @code
    /// isWiFiActive() || isEthernetActive() || isBluetoothActive()
    /// @endcode
    static bool isAnyNetworkActive() FL_NO_EXCEPT;

    /// @brief Check if any network type is connected
    ///
    /// Convenience method that returns true if any of WiFi or Ethernet
    /// has an active connection (has IP address).
    ///
    /// @return true if any network is connected, false otherwise
    ///
    /// **Equivalent to:**
    /// @code
    /// isWiFiConnected() || isEthernetConnected()
    /// @endcode
    ///
    /// **Note:** Bluetooth is not included because it doesn't have a
    /// "connected" state in the same sense (no IP address).
    static bool isAnyNetworkConnected() FL_NO_EXCEPT;

  private:
    // No instances - static API only
    NetworkDetector() = delete;
    ~NetworkDetector() = delete;
    NetworkDetector(const NetworkDetector &) = delete;
    NetworkDetector &operator=(const NetworkDetector &) = delete;
};

} // namespace fl

#endif // FASTLED_RMT5
