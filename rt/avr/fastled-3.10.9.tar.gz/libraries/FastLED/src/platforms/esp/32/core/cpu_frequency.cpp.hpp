/// @file platforms/esp/32/core/cpu_frequency.cpp.hpp
/// ESP32 CPU frequency runtime query implementation

#pragma once

// IWYU pragma: private

#include "fl/stl/int.h"
#include "platforms/esp/is_esp.h"

#if defined(FL_IS_ESP32)

// ESP-IDF provides esp_clk_cpu_freq() as a C function
extern "C" {
  fl::u32 esp_clk_cpu_freq();
}

namespace fl {

/// Get the current ESP32 CPU frequency at runtime
/// Wraps the ESP-IDF C function esp_clk_cpu_freq()
/// @return CPU frequency in Hz
fl::u32 esp_clk_cpu_freq_impl() FL_NO_EXCEPT {
  return ::esp_clk_cpu_freq();
}

}  // namespace fl

#endif  // defined(FL_IS_ESP32)
