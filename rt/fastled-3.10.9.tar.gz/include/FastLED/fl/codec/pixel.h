#pragma once

#include "fl/stl/int.h"
#include "fl/stl/noexcept.h"
namespace fl {

// Color formats for decoded output
enum class PixelFormat {
    RGB565,     // 16-bit RGB: RRRRR GGGGGG BBBBB
    RGB888,     // 24-bit RGB: RRRRRRRR GGGGGGGG BBBBBBBB
    RGBA8888,   // 32-bit RGBA: RRRRRRRR GGGGGGGG BBBBBBBB AAAAAAAA
    YUV420,     // YUV 4:2:0 format (mainly for internal use)
    // Generic storage formats. These do not encode transfer function,
    // primaries, component byte order, or any container wire identifier.
    Rgb8 = RGB888,
    Rgb16 = 4,
};

// Calculate bytes per pixel for given format
inline fl::u8 getBytesPerPixel(PixelFormat format) FL_NO_EXCEPT {
    switch (format) {
        case PixelFormat::RGB565: return 2;
        case PixelFormat::RGB888: return 3;
        case PixelFormat::RGBA8888: return 4;
        case PixelFormat::YUV420: return 1; // Simplified for luminance component
        case PixelFormat::Rgb16: return 6;
        default: return 0;
    }
}

// Convert RGB565 to RGB888 with proper scaling to full 8-bit range using lookup tables
void rgb565ToRgb888(fl::u16 rgb565, fl::u8& r, fl::u8& g, fl::u8& b) FL_NO_EXCEPT;

// Convert RGB888 to RGB565
inline fl::u16 rgb888ToRgb565(fl::u8 r, fl::u8 g, fl::u8 b) FL_NO_EXCEPT {
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

} // namespace fl
