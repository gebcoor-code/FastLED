/// @file _build.hpp
/// @brief Unity build header for fl/channels/ directory
/// Includes all implementation files in alphabetical order

// begin current directory includes
#include "fl/channels/bus_info_impl.cpp.hpp"
#include "fl/channels/can_match.cpp.hpp"
#include "fl/channels/capabilities.cpp.hpp"
#include "fl/channels/channel.cpp.hpp"
#include "fl/channels/channel_events.cpp.hpp"
#include "fl/channels/color_managed_source.cpp.hpp"
#include "fl/channels/color_profile.cpp.hpp"
#include "fl/channels/config.cpp.hpp"
#include "fl/channels/data.cpp.hpp"
#include "fl/channels/driver.cpp.hpp"
#include "fl/channels/five_bit_semantics.cpp.hpp"
#include "fl/channels/id_tracker.cpp.hpp"
#include "fl/channels/manager.cpp.hpp"
#include "fl/channels/options.cpp.hpp"
#include "fl/channels/pipeline_binding.cpp.hpp"
#include "fl/channels/rx.cpp.hpp"
#include "fl/channels/uart_wave_encoder.cpp.hpp"
#include "fl/channels/validation.cpp.hpp"
#include "fl/channels/wave3.cpp.hpp"
#include "fl/channels/wave8.cpp.hpp"

// begin sub directory includes
#include "fl/channels/adapters/_build.cpp.hpp"
#include "fl/channels/detail/_build.cpp.hpp"
#include "fl/channels/rx/_build.cpp.hpp"
#include "fl/channels/spi/_build.cpp.hpp"
