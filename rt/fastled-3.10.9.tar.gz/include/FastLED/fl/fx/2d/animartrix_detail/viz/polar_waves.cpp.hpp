#include "fl/stl/compiler_control.h"
#include "fl/fx/2d/animartrix_detail/viz/polar_waves.h"
#include "fl/fx/2d/animartrix_detail/render_value_fp.h"
#include "fl/fx/2d/animartrix_detail/perlin_float.h"
#include "fl/stl/noexcept.h"

FL_FAST_MATH_BEGIN
FL_OPTIMIZATION_LEVEL_O3_BEGIN

namespace fl {

void Polar_Waves::draw(Context &ctx) FL_NO_EXCEPT {
    auto *e = ctx.mEngine.get();
    e->get_ready();

    e->timings.master_speed = 0.5;
    e->timings.ratio[0] = 0.0025;
    e->timings.ratio[1] = 0.0027;
    e->timings.ratio[2] = 0.0031;

    e->calculate_oscillators(e->timings);

    for (int x = 0; x < e->num_x; x++) {
        for (int y = 0; y < e->num_y; y++) {
            e->animation.dist = (e->distance[x][y]);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[0];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[0];
            e->animation.scale_x = 0.15;
            e->animation.scale_y = 0.15;
            e->animation.offset_x = e->move.linear[0];

            float show1 = e->render_value(e->animation);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[1];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[1];
            e->animation.offset_x = e->move.linear[1];

            float show2 = e->render_value(e->animation);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[2];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[2];
            e->animation.offset_x = e->move.linear[2];

            float show3 = e->render_value(e->animation);

            float radius = e->radial_filter_radius;
            float radial = (radius - e->distance[x][y]) / e->distance[x][y];

            e->pixel.red = radial * show1;
            e->pixel.green = radial * show2;
            e->pixel.blue = radial * show3;

            e->pixel = e->rgb_sanity_check(e->pixel);
            e->setPixelColorInternal(x, y, e->pixel);
        }
    }
}


// ============================================================================
// Fixed-Point Implementation of Polar_Waves
// ============================================================================

void Polar_Waves_FP::draw(Context &ctx) FL_NO_EXCEPT {
    auto *e = ctx.mEngine.get();
    e->get_ready();
    mState.ensureCache(e);
    const fl::i32 *fade_lut = fl::assume_aligned<16>(mState.fade_lut);
    const fl::u8 *perm = PERLIN_NOISE;

    e->timings.master_speed = 0.5;
    e->timings.ratio[0] = 0.0025;
    e->timings.ratio[1] = 0.0027;
    e->timings.ratio[2] = 0.0031;

    e->calculate_oscillators(e->timings);

    for (int x = 0; x < e->num_x; x++) {
        for (int y = 0; y < e->num_y; y++) {
            e->animation.dist = (e->distance[x][y]);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[0];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[0];
            e->animation.scale_x = 0.15;
            e->animation.scale_y = 0.15;
            e->animation.offset_x = e->move.linear[0];

            float show1 = render_value_fp_from_float(e->animation, fade_lut, perm);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[1];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[1];
            e->animation.offset_x = e->move.linear[1];

            float show2 = render_value_fp_from_float(e->animation, fade_lut, perm);
            e->animation.angle =
                e->polar_theta[x][y] - e->animation.dist * 0.1 + e->move.radial[2];
            e->animation.z = (e->animation.dist * 1.5) - 10 * e->move.linear[2];
            e->animation.offset_x = e->move.linear[2];

            float show3 = render_value_fp_from_float(e->animation, fade_lut, perm);

            float radius = e->radial_filter_radius;
            float radial = (radius - e->distance[x][y]) / e->distance[x][y];

            e->pixel.red = radial * show1;
            e->pixel.green = radial * show2;
            e->pixel.blue = radial * show3;

            e->pixel = e->rgb_sanity_check(e->pixel);
            e->setPixelColorInternal(x, y, e->pixel);
        }
    }
}

}  // namespace fl

FL_OPTIMIZATION_LEVEL_O3_END
FL_FAST_MATH_END
