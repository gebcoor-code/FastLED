#pragma once

#include "fl/stl/int.h"
#include "fl/stl/noexcept.h"

namespace fl {

// Logic to control the progression of a transition over time.
class Transition {
  public:
    Transition() FL_NO_EXCEPT : mStart(0), mDuration(0), mNotStarted(true) {}
    ~Transition() FL_NO_EXCEPT {}

    u8 getProgress(fl::u32 now) FL_NO_EXCEPT {
        if (mNotStarted) {
            return 0;
        }
        if (now < mStart) {
            return 0;
        } else if (now >= mStart + mDuration) {
            return 255;
        } else {
            return ((now - mStart) * 255) / mDuration;
        }
    }

    void start(fl::u32 now, fl::u32 duration) FL_NO_EXCEPT {
        mNotStarted = false;
        mStart = now;
        mDuration = duration;
    }

    void end() FL_NO_EXCEPT { mNotStarted = true; }

    bool isTransitioning(fl::u32 now) FL_NO_EXCEPT {
        if (mNotStarted) {
            return false;
        }
        return now >= mStart && now < mStart + mDuration;
    }

  private:
    fl::u32 mStart;
    fl::u32 mDuration;
    bool mNotStarted;
};

} // namespace fl
