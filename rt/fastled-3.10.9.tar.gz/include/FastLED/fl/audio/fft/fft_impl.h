#pragma once

#include "fl/stl/span.h"
#include "fl/stl/string.h"
#include "fl/stl/unique_ptr.h"
#include "fl/stl/noexcept.h"
#include "fl/stl/int.h"

namespace fl {
namespace audio {

class Sample;  // Forward declare in fl::audio (correct namespace)

namespace fft {

class Context;
struct Args;

// Example:
//   Impl fft(512, 16);
//   auto sample = SINE WAVE OF 512 SAMPLES
//   fft.run(buffer, &out);
//   FL_WARN("Impl output: " << out);  // 16 bands of output.
class Impl {
  public:
    // Result indicating success or failure of the Impl run (in which case
    // there will be an error message).
    struct Result {
        Result(bool ok, const string &error) FL_NO_EXCEPT : ok(ok), error(error) {}
        bool ok = false;
        fl::string error;
    };
    // Default values for the Impl.
    Impl(const Args &args) FL_NO_EXCEPT;
    ~Impl() FL_NO_EXCEPT;

    fl::size sampleSize() const FL_NO_EXCEPT;
    // Note that the sample sizes MUST match the samples size passed into the
    // constructor.
    Result run(const Sample &sample, Bins *out) FL_NO_EXCEPT;
    Result run(span<const i16> sample, Bins *out) FL_NO_EXCEPT;
    // Info on what the frequency the bins represent
    fl::string info() const FL_NO_EXCEPT;

    // Disable copy and move constructors and assignment operators
    Impl(const Impl &) FL_NO_EXCEPT = delete;
    Impl &operator=(const Impl &) FL_NO_EXCEPT = delete;
    Impl(Impl &&) FL_NO_EXCEPT = delete;
    Impl &operator=(Impl &&) FL_NO_EXCEPT = delete;

  private:
    fl::unique_ptr<Context> mContext;
};

namespace detail {

/// CQ_OCTAVE coverage supplement decision (FastLED#4301/#4540), integer form
/// used in FIXED16: the full-rate FFT floor (`fftMag / 50`) replaces a CQ
/// band's magnitude `cqMag` only when no CQ band within one FFT main lobe
/// detected energy (`localCqMax < 20`) and the floor is strictly larger.
/// Widened to u64 so no u32 input can overflow.
inline bool coverageFloorApplies(u32 fftMag, u32 cqMag,
                                 u32 localCqMax) FL_NO_EXCEPT {
    return localCqMax < 20u &&
           static_cast<u64>(fftMag) > static_cast<u64>(cqMag) * 50u;
}

} // namespace detail

} // namespace fft
} // namespace audio
}; // namespace fl
