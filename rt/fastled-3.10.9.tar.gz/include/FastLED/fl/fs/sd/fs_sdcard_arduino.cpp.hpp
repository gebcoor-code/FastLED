// Arduino SD-card implementation. This file contains external Arduino library
// headers and definitions, so it must only be included by the SD implementation
// translation unit rather than exposed through FastLED's header graph.

#include "fl/stl/has_include.h"
#include "fl/fs/sd/fs_sdcard_arduino.h"
#include "platforms/is_platform.h"

// <SPI.h> is probed alongside the others because this block includes it
// unconditionally below. ESP8266 satisfied the SD.h/fs.h half of this guard --
// its core ships an unrelated <fs.h> for the flash filesystem -- while SPI was
// not on the include path, so the platform failed to build at all with
// "fatal error: SPI.h: No such file or directory". Every header this block
// needs has to be in the condition that admits it.
#if !defined(FL_IS_TEENSY) && FL_HAS_INCLUDE(<SD.h>) && FL_HAS_INCLUDE(<fs.h>) &&      \
    FL_HAS_INCLUDE(<SPI.h>)

// IWYU pragma: begin_keep
#include <SPI.h>
// IWYU pragma: end_keep
#ifdef USE_SDFAT
// IWYU pragma: begin_keep
#include <SdFat.h>
// IWYU pragma: end_keep
#else
// IWYU pragma: begin_keep
#include <SD.h>
// IWYU pragma: end_keep
#endif


#include "fl/stl/memory.h"
#include "fl/fs/fs.h"
#include "fl/stl/type_traits.h"
#include "fl/stl/noexcept.h"

namespace fl {

// Forward declare the smart pointer type for FsArduino
class FsArduino;
FASTLED_SHARED_PTR(FsArduino);

#ifdef USE_SDFAT
class SdFatFileHandle : public filebuf {
private:
    SdFile _file;
    string _path;

public:
    SdFatFileHandle(SdFile file, const char* path) FL_NO_EXCEPT : _file(fl::move(file)), _path(path) {}
    ~SdFatFileHandle() FL_NO_EXCEPT override {
        if (_file.isOpen()) {
            _file.close();
        }
    }

    bool is_open() const FL_NO_EXCEPT override {
        return _file.isOpen();
    }
    bool available() const FL_NO_EXCEPT override {
        auto f = const_cast<SdFatFileHandle*>(this);
        return f->_file.available() > 0;
    }
    fl::size_t size() const FL_NO_EXCEPT override {
        return _file.fileSize();
    }
    fl::size_t read(char *dst, fl::size_t bytesToRead) FL_NO_EXCEPT override {
        return _file.read(reinterpret_cast<u8*>(dst), bytesToRead); // ok reinterpret cast
    }
    using filebuf::read;
    fl::size_t write(const char *data, fl::size_t count) FL_NO_EXCEPT override {
        (void)data; (void)count;
        return 0;
    }
    fl::size_t tell() FL_NO_EXCEPT override {
        return _file.curPosition();
    }
    const char* path() const FL_NO_EXCEPT override {
        return _path.c_str();
    }
    bool seek(fl::size_t pos, fl::seek_dir dir) FL_NO_EXCEPT override {
        if (dir == fl::seek_dir::beg) return _file.seekSet(pos);
        if (dir == fl::seek_dir::cur) return _file.seekCur(pos);
        return _file.seekEnd(pos);
    }
    using filebuf::seek;
    void close() FL_NO_EXCEPT override {
        if (_file.isOpen()) {
            _file.close();
        }
    }
    bool is_eof() const FL_NO_EXCEPT override {
        auto f = const_cast<SdFatFileHandle*>(this);
        return f->_file.available() <= 0;
    }
    bool has_error() const FL_NO_EXCEPT override { return false; }
    void clear_error() FL_NO_EXCEPT override {}
    int error_code() const FL_NO_EXCEPT override { return 0; }
    const char* error_message() const FL_NO_EXCEPT override { return "No error"; }
};
#else
class SDFileHandle : public filebuf {
private:
    File _file;
    string _path;

public:
    SDFileHandle(File file, const char* path) FL_NO_EXCEPT : _file(file), _path(path) {}
    ~SDFileHandle() FL_NO_EXCEPT override {
        if (_file) {
            _file.close();
        }
    }

    bool is_open() const FL_NO_EXCEPT override {
        auto f = const_cast<File&>(_file);
        return f;
    }
    bool available() const FL_NO_EXCEPT override {
        auto f = const_cast<File&>(_file);
        return f.available() > 0;
    }
    fl::size_t size() const FL_NO_EXCEPT override {
        auto f = const_cast<File&>(_file);
        return f.size();
    }
    fl::size_t read(char *dst, fl::size_t bytesToRead) FL_NO_EXCEPT override {
        return _file.read(reinterpret_cast<u8*>(dst), bytesToRead); // ok reinterpret cast
    }
    using filebuf::read;
    fl::size_t write(const char *data, fl::size_t count) FL_NO_EXCEPT override {
        (void)data; (void)count;
        return 0;
    }
    fl::size_t tell() FL_NO_EXCEPT override {
        auto f = const_cast<File&>(_file);
        return f.position();
    }
    const char* path() const FL_NO_EXCEPT override {
        return _path.c_str();
    }
    bool seek(fl::size_t pos, fl::seek_dir dir) FL_NO_EXCEPT override {
        if (dir == fl::seek_dir::beg) return _file.seek(pos);
        // Arduino SD doesn't support cur/end natively
        if (dir == fl::seek_dir::cur) {
            auto f = const_cast<File&>(_file);
            return _file.seek(f.position() + pos);
        }
        auto f = const_cast<File&>(_file);
        return _file.seek(f.size() + pos);
    }
    using filebuf::seek;
    void close() FL_NO_EXCEPT override {
        if (_file) {
            _file.close();
        }
    }
    bool is_eof() const FL_NO_EXCEPT override {
        auto f = const_cast<File&>(_file);
        return f.available() <= 0;
    }
    bool has_error() const FL_NO_EXCEPT override { return false; }
    void clear_error() FL_NO_EXCEPT override {}
    int error_code() const FL_NO_EXCEPT override { return 0; }
    const char* error_message() const FL_NO_EXCEPT override { return "No error"; }
};
#endif

class FsArduino : public FsImpl {
private:
    int _cs_pin;
#ifdef USE_SDFAT
    SdFat _sd;
#endif

public:
    FsArduino(int cs_pin) FL_NO_EXCEPT : _cs_pin(cs_pin) {}

    bool begin() FL_NO_EXCEPT override {
#ifdef USE_SDFAT
        // Use the CS pin provided in constructor
        return _sd.begin(_cs_pin, SPI_HALF_SPEED);
#else
        return SD.begin(_cs_pin);
#endif
    }

    void end() FL_NO_EXCEPT override {
        // SD library doesn't have an end() method, but we can ensure files are closed
        // Note: This is a limitation of the Arduino SD library
    }

    filebuf_ptr openRead(const char *name) FL_NO_EXCEPT override {
#ifdef USE_SDFAT
        SdFile file;
        // Open file for reading
        if (!file.open(name, O_READ)) {
            return filebuf_ptr();
        }
        return fl::make_shared<SdFatFileHandle>(fl::move(file), name);
#else
        File file = SD.open(name, FILE_READ);
        if (!file) {
            return filebuf_ptr();
        }
        return fl::make_shared<SDFileHandle>(fl::move(file), name);
#endif
    }

};

// Implementation of the factory function to create SD card filesystem
inline FsImplPtr make_sdcard_filesystem(int cs_pin) FL_NO_EXCEPT {
    return fl::make_shared<FsArduino>(cs_pin);
}

} // namespace fl

#define FASTLED_HAS_SDCARD_ARDUINO_IMPL 1

#endif  // !defined(FL_IS_TEENSY) && FL_HAS_INCLUDE(<SD.h>) && FL_HAS_INCLUDE(<fs.h>)
