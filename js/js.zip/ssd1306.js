// Web FastLED: OLED controller SSD1306 (128×64 / 128×32) as display sees bytes of I2C or SPI: commands, display RAM
// (GDDRAM, 8 pages of 128 bytes, bit 0 = top row of page), addressing modes, column / page windows, remap, COM scan
// direction, start line, offset, invert, contrast, display on / off. Shared by emulator worker (runner.js) and page.
// I2C: control byte first — Co (bit 7) = one byte follows and then next control byte, D/C# (bit 6) = data / command.
// SPI: D/C# pin says data / command of each byte.
const ARGS = { 0x20: 1, 0x21: 2, 0x22: 2, 0x26: 6, 0x27: 6, 0x29: 5, 0x2A: 5, 0x81: 1, 0x8D: 1, 0xA3: 2, 0xA8: 1, 0xD3: 1, 0xD5: 1, 0xD8: 1, 0xD9: 1, 0xDA: 1, 0xDB: 1, 0xAD: 1 };

export class SSD1306 {
  constructor(w = 128, h = 64) {
    this.w = w; this.h = h;
    this.ram = new Uint8Array(128 * 8);
    this.reset();
  }
  reset() {
    this.ram.fill(0);
    Object.assign(this, {
      mode: 2, col: 0, page: 0, c0: 0, c1: 127, p0: 0, p1: 7, on: false, inv: false, all: false, contrast: 0x7F,
      remap: false, comRev: false, start: 0, offset: 0, mux: 63, cmd: null, need: 0, args: [], dirty: false, cmds: 0, bytes: 0, datas: 0, frames: 0, inData: false,
    });
  }
  // ---- bytes in
  i2c(bytes) { // one transaction (after address)
    let i = 0;
    while (i < bytes.length) {
      const c = bytes[i++];
      const data = !!(c & 0x40);
      if (c & 0x80) { if (i < bytes.length) this.byte(bytes[i++], data); } // Co = 1: one byte, then control byte again
      else { for (; i < bytes.length; i++) this.byte(bytes[i], data); }
    }
  }
  byte(b, data) {
    if (!this.bytes++) this.dirty = true; // first byte: page learns that display is talked to
    if (data) { this.inData = true; this.data(b); }
    else { if (this.inData) { this.inData = false; this.frames++; } this.command(b); } // picture sent, next one starts with commands
  }
  data(b) {
    if (!this.datas++) this.dirty = true;
    const a = this.page * 128 + this.col;
    if (this.ram[a] !== b) { this.ram[a] = b; this.dirty = true; }
    if (this.mode === 2) { this.col = (this.col + 1) & 127; return; } // page mode: column wraps, page stays
    if (this.mode === 0) { // horizontal: column window, then next page
      if (this.col >= this.c1) { this.col = this.c0; this.page = this.page >= this.p1 ? this.p0 : this.page + 1; } else this.col++;
    } else { // vertical: page window, then next column
      if (this.page >= this.p1) { this.page = this.p0; this.col = this.col >= this.c1 ? this.c0 : this.col + 1; } else this.page++;
    }
  }
  // GDDRAM read (I2C read of real SSD1306 gives nothing useful; GyverOLED without buffer reads, so give RAM as SH1106 does)
  read(n) {
    const out = new Uint8Array(n);
    for (let i = 0; i < n; i++) out[i] = i === 0 ? 0 : this.ram[this.page * 128 + ((this.col + i - 1) & 127)];
    return out;
  }
  command(b) {
    this.cmds++;
    if (this.cmd != null) { // argument of command
      this.args.push(b);
      if (this.args.length < this.need) return;
      const c = this.cmd, a = this.args; this.cmd = null; this.args = [];
      return this.exec(c, a);
    }
    if (ARGS[b]) { this.cmd = b; this.need = ARGS[b]; this.args = []; return; }
    this.exec(b, []);
  }
  exec(c, a) {
    const was = this.on + ',' + this.inv + ',' + this.all + ',' + this.contrast + ',' + this.remap + ',' + this.comRev + ',' + this.start + ',' + this.offset + ',' + this.mux;
    if (c <= 0x0F) this.col = (this.col & 0xF0) | c; // page mode: lower nibble of column
    else if (c <= 0x1F) this.col = ((c & 0x07) << 4) | (this.col & 0x0F); // higher nibble
    else if (c === 0x20) this.mode = a[0] & 3;
    else if (c === 0x21) { this.c0 = a[0] & 127; this.c1 = a[1] & 127; this.col = this.c0; }
    else if (c === 0x22) { this.p0 = a[0] & 7; this.p1 = a[1] & 7; this.page = this.p0; }
    else if (c >= 0x40 && c <= 0x7F) this.start = c & 63;
    else if (c === 0x81) this.contrast = a[0];
    else if (c === 0xA0 || c === 0xA1) this.remap = c === 0xA1;
    else if (c === 0xA4 || c === 0xA5) this.all = c === 0xA5;
    else if (c === 0xA6 || c === 0xA7) this.inv = c === 0xA7;
    else if (c === 0xA8) this.mux = Math.max(15, a[0] & 63);
    else if (c === 0xAE || c === 0xAF) this.on = c === 0xAF;
    else if (c >= 0xB0 && c <= 0xB7) this.page = c & 7;
    else if (c === 0xC0 || c === 0xC8) this.comRev = c === 0xC8;
    else if (c === 0xD3) this.offset = a[0] & 63;
    // others (clock, precharge, COM pins, VCOMH, charge pump, scrolling, NOP) change nothing that is drawn
    const now = this.on + ',' + this.inv + ',' + this.all + ',' + this.contrast + ',' + this.remap + ',' + this.comRev + ',' + this.start + ',' + this.offset + ',' + this.mux;
    if (now !== was) this.dirty = true;
  }
  // ---- picture: state for page (copy of RAM and settings)
  state() {
    return { ram: this.ram.slice(), cmds: this.cmds, datas: this.datas, on: this.on, inv: this.inv, all: this.all, contrast: this.contrast, remap: this.remap, comRev: this.comRev, start: this.start, offset: this.offset, mux: this.mux };
  }
}

// pixels of panel (w × h, 1 = lit) from state: modules are wired so that A1 (segment remap) + C8 (COM scan reversed),
// what libraries send on init, shows RAM column 0 / row 0 at top left
export function oledPixels(st, w, h, out) {
  out = out || new Uint8Array(w * h);
  if (!st || !st.on) { out.fill(0); return out; }
  const rows = Math.min(h, (st.mux | 0) + 1);
  for (let y = 0; y < h; y++) {
    if (y >= rows) { out.fill(0, y * w, y * w + w); continue; }
    const com = st.comRev ? y : rows - 1 - y; // COM line driving this panel row
    const r = (com + st.start + 64 - (st.offset | 0)) & 63; // RAM row shown on that COM
    const pg = r >> 3, bit = 1 << (r & 7);
    for (let x = 0; x < w; x++) {
      const c = st.remap ? x : 127 - x;
      let v = st.all ? 1 : (st.ram[pg * 128 + c] & bit ? 1 : 0);
      if (st.inv) v ^= 1;
      out[y * w + x] = v;
    }
  }
  return out;
}
