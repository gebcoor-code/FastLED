// Web FastLED: real AVR build worker (module worker): avr-gcc 7.3 in WebAssembly (rt/avr/), Arduino AVR core 1.8.6, FastLED.
// Tools are downloaded once (browser cache keeps them), SDK is unpacked into in-memory file system.
//   → { type: 'init' }                                         ← { type: 'progress', done, total } / { type: 'ready', ms } / { type: 'fail', error }
//   → { type: 'build', id, files, main, board, cpu, warnings, fastled }   ← { type: 'log', id, line } / { type: 'result', id, ok, … }
import { MemFS, Toolchain } from './avr-wasi.js?v=20261113102055';
import { AVR_TOOLS, AVR_ALIAS, buildAvr } from './avr-build.js?v=20261113102055';
import { parseDiagnostics } from './sketch.js?v=20261113102055';

const RT = new URL('../rt/avr/', import.meta.url);
let tc = null, initP = null, man = null;
const lazy = new Set(['cc1']); // C compiler: only for .c files of sketch / libraries

async function gunzip(r) {
  const body = r.body.getReader();
  const first = await body.read();
  const head = first.value || new Uint8Array(0);
  const src = new ReadableStream({
    start(c) { if (head.length) c.enqueue(head); if (first.done) c.close(); },
    async pull(c) { const x = await body.read(); if (x.done) c.close(); else c.enqueue(x.value); },
  });
  const gz = head[0] === 0x1f && head[1] === 0x8b; // server may already unpack .gz (Content-Encoding: gzip)
  return new Uint8Array(await new Response(gz ? src.pipeThrough(new DecompressionStream('gzip')) : src).arrayBuffer());
}
// download with progress over all files
function loader(total) {
  let done = 0;
  return async (file) => {
    const r = await fetch(new URL(file + '?v=' + encodeURIComponent(man.version), RT));
    if (!r.ok) throw new Error('Cannot load ' + file + ' (HTTP ' + r.status + ')');
    const reader = r.body.getReader(), chunks = [];
    for (;;) {
      const x = await reader.read(); if (x.done) break;
      chunks.push(x.value); done += x.value.length;
      postMessage({ type: 'progress', done, total });
    }
    return gunzip(new Response(new Blob(chunks)));
  };
}

async function init() {
  const t0 = performance.now();
  man = await fetch(new URL('avr.json?t=' + Date.now(), RT)).then((r) => { if (!r.ok) throw new Error('Real build runtime is not installed (rt/avr/avr.json: HTTP ' + r.status + ')'); return r.json(); });
  const need = AVR_TOOLS.filter((t) => !lazy.has(t));
  const total = man.sdkSize + need.reduce((s, t) => s + man.tools[t].size, 0);
  const load = loader(total);
  const fs = new MemFS();
  const sdkP = load(man.sdk).then((b) => fs.untar(b));
  const modules = {};
  await Promise.all(need.map(async (t) => { modules[t] = await WebAssembly.compile(await load(man.tools[t].file)); }));
  await sdkP;
  fs.mkdirp('/tmp');
  tc = new Toolchain(fs, modules, AVR_ALIAS);
  postMessage({ type: 'ready', ms: Math.round(performance.now() - t0), version: man.version });
}
// tool that build asked for but is not loaded yet (cc1 for .c files): load it, then build is run again
async function loadMissing() {
  const names = [...(tc.missing || [])].filter((t) => man.tools[t] && !tc.modules[t]);
  tc.missing = new Set();
  if (!names.length) return false;
  postMessage({ type: 'log', line: 'Loading ' + names.join(', ') + '…' });
  const load = loader(names.reduce((s, t) => s + man.tools[t].size, 0));
  for (const t of names) tc.modules[t] = await WebAssembly.compile(await load(man.tools[t].file));
  return true;
}

// FastLED of other version (avr.json fastledPacks: rt/avr/fastled-<ver>.tar.gz): unpacked into /fl/<ver>, then put in place
// of built-in one: /ard/libraries/FastLED and /ard/pre/<board>/FastLED(.deps); built-in one kept for switching back
const flHome = {}, flLoaded = {};
// library compiled for other FastLED version (/cache/<board>/FastLED@<ver>, …-more) kept in IndexedDB: compiled once per browser
const idb = () => new Promise((res, rej) => { const r = indexedDB.open('webfastled-avr', 1); r.onupgradeneeded = () => r.result.createObjectStore('lib'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const flTag = (v) => man.version + '|' + v + '|' + man.fastledPacks[v].size + '|';
const flSaved = new Set();
async function flRestore(v) {
  try {
    const db = await idb(), st = db.transaction('lib', 'readwrite').objectStore('lib'), tag = flTag(v);
    const keys = await new Promise((res) => { const q = st.getAllKeys(); q.onsuccess = () => res(q.result); q.onerror = () => res([]); });
    for (const k of keys) {
      if (!String(k).startsWith(tag)) { if (String(k).includes('|' + v + '|')) st.delete(k); continue; } // older build of same version
      const e = await new Promise((res) => { const q = st.get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); });
      if (!e) continue;
      const dir = String(k).slice(tag.length);
      for (const [n, d] of Object.entries(e.files)) tc.fs.writeFile(dir + '/' + n, d);
      if (e.deps != null) tc.fs.writeFile(dir + '.deps', e.deps);
      flSaved.add(k);
    }
    db.close();
  } catch (e) {}
}
async function flStore(v) {
  if (!v || v === man.fastled || !flLoaded[v]) return;
  const c = tc.fs.lookup('/cache'); if (!c) return;
  const todo = [];
  for (const [b, bd] of c.e) for (const [n, d] of bd.e || []) {
    const dir = '/cache/' + b + '/' + n, k = flTag(v) + dir;
    if (d.t !== 'd' || !n.startsWith('FastLED@' + v) || !d.e.has('.done') || flSaved.has(k)) continue;
    const files = {}; for (const [fn, f] of d.e) if (f.t === 'f') files[fn] = f.d.slice(0, f.n);
    todo.push([k, { files, deps: tc.fs.readFile(dir + '.deps') }]);
  }
  if (!todo.length) return;
  try {
    const db = await idb(), tx = db.transaction('lib', 'readwrite');
    for (const [k, e] of todo) tx.objectStore('lib').put(e, k);
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
    for (const [k] of todo) flSaved.add(k);
    db.close();
  } catch (e) {}
}
async function useFastled(v) {
  const fs = tc.fs, libs = fs.lookup('/ard/libraries'), pre = fs.lookup('/ard/pre');
  const NAMES = ['FastLED', 'FastLED.deps', 'FastLED.first', 'FastLED.more'];
  if (!flHome.lib) { flHome.lib = libs.e.get('FastLED'); flHome.pre = {}; for (const [b, d] of pre.e) if (d.t === 'd') flHome.pre[b] = NAMES.map((n) => d.e.get(n)); }
  let lib = flHome.lib, preOf = (b) => flHome.pre[b] || [];
  if (v && v !== man.fastled) {
    const pk = man.fastledPacks && man.fastledPacks[v];
    if (!pk) throw new Error('FastLED ' + v + ' is not installed for real build (rt/avr/avr.json)');
    if (!flLoaded[v]) {
      postMessage({ type: 'log', line: 'Loading FastLED ' + v + ' for real build…' });
      fs.untar(await loader(pk.size)(pk.file), '/fl/' + v);
      flLoaded[v] = true;
      await flRestore(v);
    }
    lib = fs.lookup('/fl/' + v + '/libraries/FastLED');
    preOf = (b) => { const d = fs.lookup('/fl/' + v + '/pre/' + b); return d ? NAMES.map((n) => d.e.get(n)) : []; };
  }
  libs.e.set('FastLED', lib);
  for (const [b, d] of pre.e) {
    if (d.t !== 'd') continue;
    const nodes = preOf(b);
    NAMES.forEach((n, i) => { if (nodes[i]) d.e.set(n, nodes[i]); else d.e.delete(n); });
  }
}

onmessage = async (e) => {
  const m = e.data;
  if (m.type === 'init') {
    if (!initP) initP = init().catch((err) => { initP = null; postMessage({ type: 'fail', error: String(err && err.message || err) }); throw err; });
    return;
  }
  if (m.type === 'build') {
    try {
      if (!initP) initP = init();
      await initP;
      try { await useFastled(m.fastled); } catch (err) { const t = String(err && err.message || err); postMessage({ type: 'log', id: m.id, line: t }); postMessage({ type: 'result', id: m.id, ok: false, log: t, diagnostics: [] }); return; }
      const opts = { fastled: m.fastled, bigLib: !!m.fastled && m.fastled !== man.fastled, board: m.board, cpu: m.cpu, warnings: m.warnings, cSketch: m.cSketch, name: m.name, log: (line) => postMessage({ type: 'log', id: m.id, line }) };
      tc.missing = new Set();
      let r = buildAvr(tc, m.files, m.main, opts);
      if (!r.ok && await loadMissing()) r = buildAvr(tc, m.files, m.main, opts);
      await flStore(m.fastled);
      const tr = [];
      if (r.elf) tr.push(r.elf.buffer);
      if (r.boot) tr.push(r.boot.bin.buffer);
      r.diagnostics = parseDiagnostics(r.log || '', '/sketch/');
      postMessage({ type: 'result', id: m.id, ...r }, tr);
    } catch (err) {
      postMessage({ type: 'result', id: m.id, ok: false, log: String(err && (err.stack || err.message) || err), internal: true });
    }
  }
};
