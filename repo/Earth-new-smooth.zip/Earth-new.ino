//#include "earth1616.h"
#include "earth2424.h"
#include "earth2425.h"
//#include "earth4545.h"

#include <FastLED.h>

#define WIDTH 24   // frames of earth2424 / earth2425 are 24x24 (16x16 shows part, scrolling)
#define HEIGHT 24
#define NUM_LEDS WIDTH * HEIGHT
#define DATA_PIN 6

CRGB leds[NUM_LEDS];

uint16_t XY( uint8_t x, uint8_t y)
{
  uint16_t i;

    if ((x>WIDTH-1) || (y>HEIGHT-1)) return 0;

    if( y & 0x01) {
      uint8_t reverseX = (WIDTH - 1) - x;
      i = (y * WIDTH) + reverseX;
    } else {
      i = (y * WIDTH) + x;
    }
    return i;
}

//int COLS = WIDTH;
//int ROWS = HEIGHT;

void setup() { 
     FastLED.addLeds<WS2812B, DATA_PIN, GRB>(leds, NUM_LEDS);  // GRB ordering is typical
     FastLED.setBrightness (255);
     FastLED.setMaxPowerInVoltsAndMilliamps(5, 1000);
     Serial.begin(9600);
     Serial.println("Start...");

}

// 1111'1000'0000'0000 = 0xf800
// 0000'0111'1110'0000 = 0x07e0
// 0000'0000'0001'1111 = 0x001f

CRGB Crgb565(uint16_t a){
  return CRGB((a >> 8) & 0xF8, (a >> 3) & 0xFC, (a << 3) & 0xF8);
}
/*CRGB Crgb565(uint16_t a){
  CRGB col;
  col.r = (byte) ((a & 0xF800)>>9); // mask out the 5 bits of red at the start of the word, shift it right not for 11 but 9 to make it brighter and take a byte.
  col.g = (byte) ((a & 0x07E0)>>3); // mask out the 6 bits of blue in the middle of the word, shift it right and take a byte //5
  col.b = (byte) ((a & 0x001F)<<2); // mask out the 5 bits of green in the end of the word and take a byte
  return col;
}*/

///////////GifAnim ////
void GifAnim(const uint_farptr_t arr1) {

//  if (loadingFlag) {loadingFlag = false; modeCode = 14;}	

  static byte frame = 0;
  uint16_t  sprite_ptr;
  byte frameWidth =  (byte) pgm_read_word_far(arr1 + 0*sizeof(uint16_t));
  byte frameHeight = (byte) pgm_read_word_far(arr1 + 1*sizeof(uint16_t));
  byte frames =      (byte) pgm_read_word_far(arr1 + 2*sizeof(uint16_t));

  sprite_ptr = 3 + frameWidth * frameHeight * frame;

  for (byte y = 0; y < frameHeight; y++) {
    for (byte x = 0; x < frameWidth; x++) {
//      CRGB col = Crgb565(pgm_read_word_far(sprite_ptr++));
      CRGB col = Crgb565(pgm_read_word_far(arr1+sprite_ptr++*sizeof(uint16_t)));      
      leds[XY(x, HEIGHT-1-y)] = col;
    }
  }
  
  frame++;
  if (frame >= frames) frame = 0;

  nscale8(leds, NUM_LEDS, 100);

//  delay(100);
}

///////////GifAnim2424////

  byte frame = 0;

void GifAnim2424(const uint_farptr_t arr1, const uint_farptr_t arr2) {

  //if (loadingFlag) {loadingFlag = false; modeCode = 14;}	

  uint16_t  sprite_ptr;
  CRGB col;
  static int8_t lines = 0;
  static int8_t direction = 1;

  byte frameWidth =  (byte) pgm_read_word_far(arr1 + 0*sizeof(uint16_t));
  byte frameHeight = (byte) pgm_read_word_far(arr1 + 1*sizeof(uint16_t));
  byte frames =      (byte) pgm_read_word_far(arr1 + 2*sizeof(uint16_t));

  if(frame<=19) sprite_ptr = (3 + frameWidth * frameHeight * frame + frameWidth*lines);
  if(frame>19) sprite_ptr = (3 + frameWidth * frameHeight * (frame-20) + frameWidth*lines);
  
  for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
     if (frame<=19) { col = Crgb565(pgm_read_word_far (arr1 + sprite_ptr++*sizeof(uint16_t))); }
     if (frame>19)  { col = Crgb565(pgm_read_word_far (arr2 + sprite_ptr++*sizeof(uint16_t))); }
        leds[XY(x, HEIGHT-1-y)] = col;
    }
    // next row: y + 1 (with y row 0 was drawn twice and last row of window was lost)
    if (frame<=19) sprite_ptr = (3 + frameWidth * frameHeight * frame + frameWidth*lines + (y+1)*frameWidth);
    if (frame>19) sprite_ptr = (3 + frameWidth * frameHeight * (frame-20) + frameWidth*lines + (y+1)*frameWidth);
  }
  
  frame++;
  if (frame >= frames) frame = 0;

// window scrolls over frame only when matrix is lower than frame (16x16: 8 rows; 24x24: none:
// with HEIGHT-8 rows below frame were read from next frame)
EVERY_N_MILLISECONDS(200) {
  if (frameHeight > HEIGHT) {
    lines+=direction;
    if (lines >= frameHeight-HEIGHT) direction = -1;
    if (lines <= 0) direction = 1;
  } else lines = 0;
}

//  nscale8(leds, NUM_LEDS, 100);

//  delay(100);
}

/////////////////////////////////// GifAnim

void loop() {
	
  EVERY_N_MILLISECONDS(100) {
	//EarthRoutine(earth2412);
  GifAnim2424(earth2424,earth2425);
//  GifAnim(earth1616);
  nscale8(leds, NUM_LEDS, 100);
  
  FastLED.show();
  
	}

}
