// эффекты

// **************** НАСТРОЙКИ ЭФФЕКТОВ ****************
// эффект "синусоиды" - ОТКЛЮЧЕН
//#define WAVES_AMOUNT 2    // количество синусоид

// эффект "шарики"
//#define BALLS_AMOUNT 3    // количество "шариков"
//#define CLEAR_PATH 1      // очищать путь
//#define BALL_TRACK 1      // (0 / 1) - вкл/выкл следы шариков
//#define DRAW_WALLS 0      // режим с рисованием препятствий для шаров (не работает на ESP и STM32)
//#define TRACK_STEP 70     // длина хвоста шарика (чем больше цифра, тем хвост короче)

// эффект "квадратик"
//#define BALL_SIZE 2       // размер шара
//#define RANDOM_COLOR 1    // случайный цвет при отскоке

// эффект "огонь"
//#define SPARKLES 1        // вылетающие угольки вкл выкл
//#define HUE_ADD 0         // добавка цвета в огонь (от 0 до 230) - меняет весь цвет пламени default 0

// эффект "кометы"
//#define TAIL_STEP 100     // длина хвоста кометы
//#define SATURATION 150    // насыщенность кометы (от 0 до 255)
//#define STAR_DENSE 60     // количество (шанс появления) комет

// ********************************* ШАРИКИ *********************************
/*
int coord[BALLS_AMOUNT][2];
int8_t vector[BALLS_AMOUNT][2];
CRGB ballColors[BALLS_AMOUNT];

void ballsRoutine() {
  if (loadingFlag) {
    modeCode = 17;
    loadingFlag = false;
    for (byte j = 0; j < BALLS_AMOUNT; j++) {
      int sign;

      // забиваем случайными данными
      coord[j][0] = WIDTH / 2 * 10;
      random(0, 2) ? sign = 1 : sign = -1;
      vector[j][0] = random(4, 15) * sign;
      coord[j][1] = HEIGHT / 2 * 10;
      random(0, 2) ? sign = 1 : sign = -1;
      vector[j][1] = random(4, 15) * sign;
      ballColors[j] = CHSV(random(0, 9) * 28, 255, 255);
    }
  }


  if (!BALL_TRACK)    // если режим БЕЗ следов шариков
    FastLED.clear();  // очистить
  else {              // режим со следами
    fader(TRACK_STEP);
  }

  // движение шариков
  for (byte j = 0; j < BALLS_AMOUNT; j++) {

    // отскок от нарисованных препятствий
    if (DRAW_WALLS) {
      uint32_t thisColor = getPixColorXY(coord[j][0] / 10 + 1, coord[j][1] / 10);
      if (thisColor == globalColor) {
        vector[j][0] = -vector[j][0];
      }
      thisColor = getPixColorXY(coord[j][0] / 10 - 1, coord[j][1] / 10);
      if (thisColor == globalColor) {
        vector[j][0] = -vector[j][0];
      }
      thisColor = getPixColorXY(coord[j][0] / 10, coord[j][1] / 10 + 1);
      if (thisColor == globalColor) {
        vector[j][1] = -vector[j][1];
      }
      thisColor = getPixColorXY(coord[j][0] / 10, coord[j][1] / 10 - 1);
      if (thisColor == globalColor) {
        vector[j][1] = -vector[j][1];
      }
    }

    // движение шариков
    for (byte i = 0; i < 2; i++) {
      coord[j][i] += vector[j][i];
      if (coord[j][i] < 0) {
        coord[j][i] = 0;
        vector[j][i] = -vector[j][i];
      }
    }

    if (coord[j][0] > (WIDTH - 1) * 10) {
      coord[j][0] = (WIDTH - 1) * 10;
      vector[j][0] = -vector[j][0];
    }
    if (coord[j][1] > (HEIGHT - 1) * 10) {
      coord[j][1] = (HEIGHT - 1) * 10;
      vector[j][1] = -vector[j][1];
    }
    leds[getPixelNumber(coord[j][0] / 10, coord[j][1] / 10)] =  ballColors[j];
  }
}
*/

// *********** "дыхание" яркостью ***********
/*boolean brightnessDirection;
void brightnessRoutine() {
  if (brightnessDirection) {
    breathBrightness += 2;
    if (breathBrightness > globalBrightness - 1) {
      brightnessDirection = false;
    }
  } else {
    breathBrightness -= 2;
    if (breathBrightness < 1) {
      brightnessDirection = true;
    }
  }
  FastLED.setBrightness(breathBrightness);
}*/

/*void colorsRoutine() {
  hue += 4;
  for (int i = 0; i < NUM_LEDS; i++) {
    if (getPixColor(i) > 0) leds[i] = CHSV(hue, 255, 255);
  }
}*/

/*
// *********** снегопад 2.0 ***********
void snowRoutine() {
  modeCode = 12;
  // сдвигаем всё вниз
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      drawPixelXY(x, y, getPixColorXY(x, y + 1));
    }
  }

  for (byte x = 0; x < WIDTH; x++) {
    // заполняем случайно верхнюю строку
    // а также не даём двум блокам по вертикали вместе быть
    if (getPixColorXY(x, HEIGHT - 2) == 0 && (random(0, SNOW_DENSE) == 0))
      drawPixelXY(x, HEIGHT - 1, 0xE0FFFF - 0x101010 * random(0, 4));
    else
      drawPixelXY(x, HEIGHT - 1, 0x000000);
  }
}

*/

/*
// ***************************** БЛУДНЫЙ КУБИК *****************************
int coordB[2];
int8_t vectorB[2];
CRGB ballColor;

void ballRoutine() {
  if (loadingFlag) {
    for (byte i = 0; i < 2; i++) {
      coordB[i] = WIDTH / 2 * 10;
      vectorB[i] = random(8, 20);
      ballColor = CHSV(random(0, 9) * 28, 255, 255);
    }
    modeCode = 16;
    loadingFlag = false;
  }
  for (byte i = 0; i < 2; i++) {
    coordB[i] += vectorB[i];
    if (coordB[i] < 0) {
      coordB[i] = 0;
      vectorB[i] = -vectorB[i];
      if (RANDOM_COLOR) ballColor = CHSV(random(0, 9) * 28, 255, 255);
      //vectorB[i] += random(0, 6) - 3;
    }
  }
  if (coordB[0] > (WIDTH - BALL_SIZE) * 10) {
    coordB[0] = (WIDTH - BALL_SIZE) * 10;
    vectorB[0] = -vectorB[0];
    if (RANDOM_COLOR) ballColor = CHSV(random(0, 9) * 28, 255, 255);
    //vectorB[0] += random(0, 6) - 3;
  }
  if (coordB[1] > (HEIGHT - BALL_SIZE) * 10) {
    coordB[1] = (HEIGHT - BALL_SIZE) * 10;
    vectorB[1] = -vectorB[1];
    if (RANDOM_COLOR) ballColor = CHSV(random(0, 9) * 28, 255, 255);
    //vectorB[1] += random(0, 6) - 3;
  }
  FastLED.clear();
  for (byte i = 0; i < BALL_SIZE; i++)
    for (byte j = 0; j < BALL_SIZE; j++)
      leds[getPixelNumber(coordB[0] / 10 + i, coordB[1] / 10 + j)] = ballColor;
}
*/

/*
// *********** радуга заливка ***********
void rainbowRoutine() {
  modeCode = 18;
  hue += 3;
  for (byte i = 0; i < WIDTH; i++) {
    CHSV thisColor = CHSV((byte)(hue + i * float(255 / WIDTH)), 255, 255);
    for (byte j = 0; j < HEIGHT; j++)      
      drawPixelXY(i, j, thisColor);   //leds[getPixelNumber(i, j)] = thisColor;
  }
}
*/
/*
// *********** радуга дигональная ***********
void rainbowDiagonalRoutine() {
  modeCode = 19;
  hue += 3;
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      CHSV thisColor = CHSV((byte)(hue + (float)(WIDTH / HEIGHT * x + y) * (float)(255 / maxDim)), 255, 255);      
      drawPixelXY(x, y, thisColor); //leds[getPixelNumber(i, j)] = thisColor;
    }
  }
}
*/

/*
// *********** радуга активных светодиодов (рисунка) ***********
void rainbowColorsRoutine() {
  hue++;
  for (byte i = 0; i < WIDTH; i++) {
    CHSV thisColor = CHSV((byte)(hue + i * float(255 / WIDTH)), 255, 255);
    for (byte j = 0; j < HEIGHT; j++)
      if (getPixColor(getPixelNumber(i, j)) > 0) drawPixelXY(i, j, thisColor);
  }
}
*/

/*

// ********************** огонь **********************
unsigned char matrixValue[8][16];
unsigned char line[WIDTH];
int pcnt = 0;

//these values are substracetd from the generated values to give a shape to the animation
const unsigned char valueMask[8][16] PROGMEM = {
  {32 , 0  , 0  , 0  , 0  , 0  , 0  , 32 , 32 , 0  , 0  , 0  , 0  , 0  , 0  , 32 },
  {64 , 0  , 0  , 0  , 0  , 0  , 0  , 64 , 64 , 0  , 0  , 0  , 0  , 0  , 0  , 64 },
  {96 , 32 , 0  , 0  , 0  , 0  , 32 , 96 , 96 , 32 , 0  , 0  , 0  , 0  , 32 , 96 },
  {128, 64 , 32 , 0  , 0  , 32 , 64 , 128, 128, 64 , 32 , 0  , 0  , 32 , 64 , 128},
  {160, 96 , 64 , 32 , 32 , 64 , 96 , 160, 160, 96 , 64 , 32 , 32 , 64 , 96 , 160},
  {192, 128, 96 , 64 , 64 , 96 , 128, 192, 192, 128, 96 , 64 , 64 , 96 , 128, 192},
  {255, 160, 128, 96 , 96 , 128, 160, 255, 255, 160, 128, 96 , 96 , 128, 160, 255},
  {255, 192, 160, 128, 128, 160, 192, 255, 255, 192, 160, 128, 128, 160, 192, 255}
};

//these are the hues for the fire,
//should be between 0 (red) to about 25 (yellow)
const unsigned char hueMask[8][16] PROGMEM = {
  {1 , 11, 19, 25, 25, 22, 11, 1 , 1 , 11, 19, 25, 25, 22, 11, 1 },
  {1 , 8 , 13, 19, 25, 19, 8 , 1 , 1 , 8 , 13, 19, 25, 19, 8 , 1 },
  {1 , 8 , 13, 16, 19, 16, 8 , 1 , 1 , 8 , 13, 16, 19, 16, 8 , 1 },
  {1 , 5 , 11, 13, 13, 13, 5 , 1 , 1 , 5 , 11, 13, 13, 13, 5 , 1 },
  {1 , 5 , 11, 11, 11, 11, 5 , 1 , 1 , 5 , 11, 11, 11, 11, 5 , 1 },
  {0 , 1 , 5 , 8 , 8 , 5 , 1 , 0 , 0 , 1 , 5 , 8 , 8 , 5 , 1 , 0 },
  {0 , 0 , 1 , 5 , 5 , 1 , 0 , 0 , 0 , 0 , 1 , 5 , 5 , 1 , 0 , 0 },
  {0 , 0 , 0 , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 1 , 1 , 0 , 0 , 0 }
};

void fireRoutine() {
  if (loadingFlag) {
    modeCode = 20;
    loadingFlag = false;
    FastLED.clear();
    generateLine();
    memset(matrixValue, 0, sizeof(matrixValue));
  }
  if (pcnt >= 100) {
    shiftUp();
    generateLine();
    pcnt = 0;
  }
  drawFrame(pcnt);
  pcnt += 30;
}


// Randomly generate the next line (matrix row)

void generateLine() {
  for (uint8_t x = 0; x < WIDTH; x++) {
    line[x] = random(64, 255);
  }
}

//shift all values in the matrix up one row

void shiftUp() {
  for (uint8_t y = HEIGHT - 1; y > 0; y--) {
    for (uint8_t x = 0; x < WIDTH; x++) {
      uint8_t newX = x;
      if (x > 15) newX = x - 15;
      if (y > 7) continue;
      matrixValue[y][newX] = matrixValue[y - 1][newX];
    }
  }

  for (uint8_t x = 0; x < WIDTH; x++) {
    uint8_t newX = x;
    if (x > 15) newX = x - 15;
    matrixValue[0][newX] = line[newX];
  }
}

// draw a frame, interpolating between 2 "key frames"
// @param pcnt percentage of interpolation

void drawFrame(int pcnt) {
  int nextv;

  //each row interpolates with the one before it
  for (unsigned char y = HEIGHT - 1; y > 0; y--) {
    for (unsigned char x = 0; x < WIDTH; x++) {
      uint8_t newX = x;
      if (x > 15) newX = x - 15;
      if (y < 8) {
        nextv =
          (((100.0 - pcnt) * matrixValue[y][newX]
            + pcnt * matrixValue[y - 1][newX]) / 100.0)
          - pgm_read_byte(&(valueMask[y][newX]));

        CRGB color = CHSV(
                       HUE_ADD + pgm_read_byte(&(hueMask[y][newX])), // H
                       255, // S
                       (uint8_t)max(0, nextv) // V
                     );

        leds[getPixelNumber(x, y)] = color;
      } else if (y == 8 && SPARKLES) {
        if (random(0, 20) == 0 && getPixColorXY(x, y - 1) != 0) drawPixelXY(x, y, getPixColorXY(x, y - 1));
        else drawPixelXY(x, y, 0);
      } else if (SPARKLES) {

        // старая версия для яркости
        if (getPixColorXY(x, y - 1) > 0)
          drawPixelXY(x, y, getPixColorXY(x, y - 1));
        else drawPixelXY(x, y, 0);

      }
    }
  }

  //first row interpolates with the "next" line
  for (unsigned char x = 0; x < WIDTH; x++) {
    uint8_t newX = x;
    if (x > 15) newX = x - 15;
    CRGB color = CHSV(
                   HUE_ADD + pgm_read_byte(&(hueMask[0][newX])), // H
                   255,           // S
                   (uint8_t)(((100.0 - pcnt) * matrixValue[0][newX] + pcnt * line[newX]) / 100.0) // V
                 );
    leds[getPixelNumber(newX, 0)] = color;
  }
}
*/


/*
// *********** снегопад 2.0 ***********
void snowRoutine() {
  modeCode = 12;
  // сдвигаем всё вниз
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      drawPixelXY(x, y, getPixColorXY(x, y + 1));
    }
  }

  for (byte x = 0; x < WIDTH; x++) {
    // заполняем случайно верхнюю строку
    // а также не даём двум блокам по вертикали вместе быть
    if (getPixColorXY(x, HEIGHT - 2) == 0 && (random(0, SNOW_DENSE) == 0))
      drawPixelXY(x, HEIGHT - 1, 0xE0FFFF - 0x101010 * random(0, 4));
    else
      drawPixelXY(x, HEIGHT - 1, 0x000000);
  }
}

*/

/*
//////////////// Sand-650 //////////////////
uint16_t ss_speed = 196;
bool var = 0;

byte FF[WIDTH][HEIGHT];
byte SF[WIDTH][HEIGHT];
uint16_t shift;

void changeFrame() {
  memcpy(FF, SF, WIDTH * HEIGHT);
  bool checked = 0;
  for(byte x = 0; x < WIDTH; x++){checked = 1; if(!SF[x][HEIGHT/2-HEIGHT/8]){checked = 0; break;}
   }
  if(checked){
    for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
      if(random()%3) SF[x][y] = 0;
    }
  }
}
  for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
      if (!SF[x][y]) continue;
      if (SF[x][y] && !SF[x][y - 1] && y) {SF[x][y - 1] = SF[x][y]; SF[x][y] = 0; }
      else if (SF[x][y] && SF[x][y - 1] && !SF[x + 1][y - 1]  && !(x==WIDTH-1) && y) {SF[x + 1][y - 1] = SF[x][y]; SF[x][y] = 0; }
       else if (SF[x][y] && SF[x][y - 1] && !SF[x - 1][y - 1] && x && y) {SF[x - 1][y - 1] = SF[x][y]; SF[x][y] = 0; }
    }
  }
  if (!(random() % 4)) SF[(var)?random(1,WIDTH-1):WIDTH/2][HEIGHT - 1] = random(10, 255);
}

void Sand650 () {

shift += ss_speed;
  if (shift >= 255) {
    changeFrame();
    shift%=256;
  }
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      CRGB col1 = CHSV(FF[x][y], 255, (FF[x][y]) ? 255 : 0);
      leds[XY(x, y)] = nblend(col1, CHSV(SF[x][y], 255, (SF[x][y]) ? 255 : 0), shift);
    }
  }
}
//////////////////////////////////////////// Sand-650 */

///////////////// Starfield /////////
/*
const uint8_t mapp = 255 / WIDTH;
struct{
  uint8_t angle;
  uint8_t radius;
} rMap[NUM_LEDS];

void Starfield () {

 if (loadingFlag) {
  loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        uint16_t coord = XY(x + C_X, y + C_Y);
        rMap[coord].angle = 128 * (atan2(y, x) / PI);
        rMap[coord].radius = hypot(x, y) * mapp; //thanks Sutaburosu
      }
    }
  }

FastLED.clear();
  static byte speed = 8;
  static uint16_t t;
  t += speed;
  uint16_t t1 = t / 2;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      uint16_t coord = XY(x,y);
      uint8_t angle = sin8(t1 / 2 + rMap[coord].angle * 3);
      uint8_t radius = (rMap[coord].radius) * 2 - t;
      uint8_t noise[3] = { inoise8(angle, radius, t1), inoise8(angle, 12032 + t1, radius), inoise8(radius, 120021 + t1, angle) };
      for(uint8_t i = 0; i < 3; i++){
        noise[i] = (noise[i] < 128) ? 0 : constrain((noise[i] - 128) * 3,0,255);
      }
      leds[coord] = CRGB(noise[0], noise[1], noise[2]);
    }
  }
}*/
///////////////////////////////////// Starfield

/*
/////////////// Playground /////////////////// 

byte effnum=0;

int code(int x, int y, int i, int t) { //put your formula here 
  uint16_t outputcode;
  
  switch (effnum) { 
   // case 0:outputcode = (x-sin8(x+t/3)/16)*(x-sin8(x+t/3)/16)+(y-cos8(y+t/2)/16)*(y-cos8(y+t/2)/16)-t; break;
    case 1: outputcode = (x-HEIGHT/2)*(y-WIDTH/2)-t;  break; //(с) stepko 
  }
  return outputcode;
}

void Playground() {

if (loadingFlag) {loadingFlag = false; effnum=1;} //

  int i = 0;
  int t = millis() / 10;
  for (int y = 0; y < HEIGHT; y++) {
    for (int x = 0; x < WIDTH; x++) {
      leds[XY(x, y)] = CHSV(code(x, y, i, t), 255, 255); // ColorFromPalette (PartyColors_p,code(x,y,i,t),255); 
      i++;
  }}
}
///////////////////////////////////////////// Playground
*/

/*
/////// Fire OldSchool ////////////////
byte buff[364]; //byte buff[(COLS+2)*(ROWS+2)]; 24+2 * 12+2

DEFINE_GRADIENT_PALETTE(firepal) { // define fire palette
  0,  0,  0,  0, //black
  50, 0,0,0,
  64,  255,  0,  0, // red
  100,  255,  255,  0, //yellow
  255,  255,  255,  255, // white
};

uint16_t buffXY (byte x, byte y){
return (y*(WIDTH+2)+x);
}

void fadeup(){
uint16_t sum;
for (byte x = 1; x < WIDTH+1; x++) {
  for (byte y = 0; y < HEIGHT+1; y++) {

     sum =  buff [buffXY(x,y)]; 
     sum += buff [buffXY(x-1,y+1)];
     sum += buff [buffXY(x,y+1)];
     sum += buff [buffXY(x+1,y+1)];
     sum /=4;
     buff [buffXY(x,y)]=sum;
}}
}

void randomline (){
  for (int i = 0; i < WIDTH+2; i++) {
    buff[buffXY(i,HEIGHT+1)] = !random8(2)? random8(65,200):0;
  }
}

void toLeds (){
//  CRGBPalette256 myPal = firepal;

  uint16_t buffIndex = 1;//(COLS+3);
  for (int y = 0; y < HEIGHT; y++) {
   for (int x = 0; x < WIDTH; x++) {
      int index = XY(x, (HEIGHT-1)-y);
      leds[index] = ColorFromPalette (firepal, buff [buffIndex],255);
      buffIndex++;
    }
  buffIndex+=2; 
  } 
}

void FireOldSchool() {

    if (loadingFlag) {
	  loadingFlag = false;
     modeCode = 14;
    }	

  randomline();
  fadeup();
  toLeds();

}
/////////////////////////////////////// Fire OldSchool
*/
/*
///////// Ugly Caustic ////////

#define uc_scale 24
#define uc_bri 128
#define uc_speed 8

uint8_t uc_noise[2][WIDTH + 1][HEIGHT + 1];

void uc_wu_pixel(int16_t x, int16_t y) {      //for ugly caustic
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  #undef WU_WEIGHT
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint8_t local_x = (x >> 8) + (i & 1);
    uint8_t local_y = (y >> 8) + ((i >> 1) & 1);
    if ((local_x >= 0 && local_x <= WIDTH) && (local_y >= 0 && local_y <= HEIGHT))
    uc_noise[1][local_x][local_y] = constrain(qsub8(uc_noise[1][local_x][local_y], (uc_bri * wu[i]) >> 8), 15, 255);
  }
}

uint16_t uc_x, uc_y, uc_z;

void fillNoise() {
  uint8_t dataSmoothing = 0;
  if (uc_speed < 50) {
    dataSmoothing = 200 - (uc_speed * 4);
  }
  for (uint8_t i = 0; i < WIDTH + 1; i++) {
    int32_t ioffset = uc_scale * i;
    for (uint8_t j = 0; j < HEIGHT + 1; j++) {
      int32_t joffset = uc_scale * j;
      
      uint8_t data = inoise8(uc_x + ioffset, uc_y + joffset, uc_z);
      
      data = qsub8(data, 16);
      data = qadd8(data, scale8(data, 39));
      
      if (dataSmoothing) {
        uint8_t olddata = uc_noise[0][i][j];
        uint8_t newdata = scale8(olddata, dataSmoothing) + scale8(data, 256 - dataSmoothing);
        data = newdata;
      }
      
      uc_noise[0][i][j] = data;
    }
  }
  uc_z += uc_speed;
  
  // apply slow drift to X and Y, just for visual variation.
  uc_x += uc_speed >> 3;
  uc_y -= uc_speed >> 4;
}
/*
/*void UglyCaustic() {

 fillNoise();
  memset8(&uc_noise[1][0][0],255,(WIDTH+1)*(HEIGHT+1));
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      uint8_t n0 = uc_noise[0][x][y];
      uint8_t n1 = uc_noise[0][x + 1][y];
      uint8_t n2 = uc_noise[0][x][y + 1];
      int8_t xl = n0 - n1;
      int8_t yl = n0 - n2;
      int16_t xa = (x << 8) + ((xl * avg8(n0, n1)) >> 1);
      int16_t ya = (y << 8) + ((yl * avg8(n0, n2)) >> 1);
      uc_wu_pixel(xa, ya);
    }
  }
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      nblend(leds[XY(i, j)], CHSV(150, uc_noise[1][i][j], 255),64);
    }
  }
}
/////////////////////////////// Ugly Caustic*/

/*
///////// Candle Routine//////////////
int dist(int x1, int y1, int x2, int y2) {
  return sqrt16((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

int dist0(int x1, int y1, int x2, int y2) {
  return sqrt16((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) / 2);
}

void CandleRoutine () {

 uint32_t t = millis();
  byte dX = map(inoise8(t, 0, t), 0, 255, 0, WIDTH);
  byte dY = map(inoise8(0, t), 0, 255, HEIGHT / 2, HEIGHT * 2);
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      int dista = dist0(x, y, WIDTH / 3, HEIGHT / 10);
      dista += dist0(x, y, WIDTH - 1 - WIDTH / 3, HEIGHT / 10);
      dista += dist0(x, y, WIDTH / 2, HEIGHT / 10);
      dista += dist(x, y, dX, dY);
      if (dista >= WIDTH + HEIGHT) dista = 0;
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, map(dista * 2, 0, (WIDTH + HEIGHT), 255, 0)), 30);
    }
  }
  blur2d(leds, WIDTH, HEIGHT, 64);

}
/////////////////////////////// Candle Routine*/

/*
///////// Colored Rain /////////

#define DOT_MAX (WIDTH*2)

//Control
uint8_t cr_speed = 127;    // 1-255
uint8_t cr_scale = 48;     // 1-DOT_MAX
uint8_t cr_hue = 1;       // 2-254 = Hue; 1= Random; 255=White
uint8_t cr_glich = 60;     // 1- 120;

//Shared functions //defined higher in magma
float fmap(const float x, const float in_min, const float in_max, const float out_min, const float out_max){
  return (out_max - out_min) * (x - in_min) / (in_max - in_min) + out_min;
}

float randomf(float min, float max)
{
  return fmap(random(1024), 0, 1023, min, max);
}


//void dimAll(uint8_t value) { for (uint16_t i = 0; i < NUM_LEDS; i++) { leds[i].nscale8(value); } } //defined higher

// Pattern class
class EffectMatrix {
private:
    float dotSpeed[2U][DOT_MAX];
    uint8_t dotColor[DOT_MAX];
    uint8_t dotPosX[DOT_MAX];
	float dotPosY[DOT_MAX];
    byte light[DOT_MAX];
    uint8_t hue;
    float count;

public:
    bool run();
};


bool EffectMatrix::run() {
  randomSeed(millis());
  if (loadingFlag) {
  for (uint8_t i = 0U; i < DOT_MAX; i++)
  {
    dotPosX[i] = random(0, WIDTH);
    dotPosY[i] = randomf(HEIGHT - HEIGHT /2, HEIGHT);
    dotSpeed[0U][i] = 1;
    dotSpeed[1U][i] = randomf(1.5, 2.5);
    dotColor[i] = hue;
    light[i] = random(196, 255);
  }
    loadingFlag = false;
  }
  float speedfactor = fmap(cr_speed, 1, 255, 0.06, 0.4);
  dimAll(map(cr_speed, 1, 255, 252, 240));
  
  CHSV color;

  for (uint8_t i = 0; i < constrain(cr_scale, 1, DOT_MAX); i++) {
    dotPosY[i] -= dotSpeed[1U][i] * speedfactor;

    if (cr_hue == 255) {
      color = rgb2hsv_approximate(CRGB::Gray);
      color.val = light[i];
    } else if (cr_hue == 1) {
      EVERY_N_MILLIS(600 / speedfactor) {
        hue = random(1, 250);
      }
      color = CHSV(hue, 255, light[i]);
    } else {
      color = CHSV(cr_hue, 255, light[i]);
    }

    drawPixelXYF_Y(dotPosX[i], dotPosY[i], color);

    count += speedfactor;

    if (cr_glich > 1 and (uint8_t)count%2 == 0) 
      if (random(256) < cr_glich) {
        dotPosX[i] = dotPosX[i] + random(-1, 2);
        light[i] = random(196, 255);
      }

    if(dotPosY[i] < -1) {
      dotPosX[i] = random(0, WIDTH);
      dotPosY[i] = randomf(HEIGHT - HEIGHT /2, HEIGHT);
      dotSpeed[1U][i] = randomf(1.5, 2.5); 
      light[i] = random(127U, 255U);
      dotColor[i] = hue;
    }
  }

  return true;
}

EffectMatrix effmtrx;

void ColoredRain (){
  effmtrx.run();
  //delay(16); // ~60FPS
}
//////////////////////////////// Colored Rain*/


/*
//////////////// SandRoutine ///////////////

#define hue_sand 150

void randomdot() {
  byte a = random8(WIDTH/4)+WIDTH*3/8; //WIDTH / 2;
  if (!random8(4)) leds[XY(a, HEIGHT - 1)].setHue(random8(hue_sand, hue_sand + 150)); // 0 or 1  
//	if (!random8(4)) leds[XY(a, HEIGHT - 1)] = ColorFromPalette(LavaColors_p, random8(hue, hue + 100));
}

void updatesand() {
  int index, indexXadd1Y, indexXsub1Y, indexXYadd1;
  for (int y = 0; y < HEIGHT - 1; y++) {
    for (int x = 1; x < WIDTH - 1; x++) {
      index = XY(x, y); indexXadd1Y = XY(x + 1, y); indexXsub1Y = XY(x - 1, y); indexXYadd1 = XY(x, y + 1);
      if (!leds[index] && !leds[indexXYadd1]) continue;
      if (!leds[index] && leds[indexXYadd1]) {leds[index] = leds[indexXYadd1]; leds[indexXYadd1] = 0;} 
        else if (leds[index] && leds[indexXYadd1] && !leds[indexXsub1Y] && !leds[indexXadd1Y]) 
         if (random8(2)) {leds[indexXsub1Y] = leds[indexXYadd1]; leds[indexXYadd1] = 0;} else {leds[indexXadd1Y] = leds[indexXYadd1]; leds[indexXYadd1] = 0;} 
          else if (leds[index] && leds[indexXYadd1] && !leds[indexXsub1Y] && leds[indexXadd1Y]) {leds[indexXsub1Y] = leds[indexXYadd1]; leds[indexXYadd1] = 0;} 
           else if (leds[index] && leds[indexXYadd1] && leds[indexXsub1Y] && !leds[indexXadd1Y]) {leds[indexXadd1Y] = leds[indexXYadd1]; leds[indexXYadd1] = 0;}
    }
  }
}

void randomdel() {
  for (int i = 0; i < NUM_LEDS; i++) {
    if (!random8(3)) leds[i] = 0;
  }
}

void falldown() {
  for (int y = 0; y < HEIGHT - 1; y++) {
    for (int x = 0; x < WIDTH; x++) {
      if (!leds[XY(x, y)] && leds[XY(x, y + 1)]) {leds[XY(x, y)] = leds[XY(x, y + 1)]; leds[XY(x, y + 1)] = 0;}
    }
  }
}

void countSand() {
  uint16_t totalSand = 0;
  for (uint16_t i = 0; i < NUM_LEDS; i++) {
    if (leds[i]) {
      totalSand++;
      if (totalSand >= NUM_LEDS / 3 + random8(30)) {randomdel(); falldown(); falldown(); falldown(); break;}  //N_LEDS/3 this how many sands on screen? maybe time to delete some? 
    }
  }
}

void SandRoutine() {
  
  if (loadingFlag) {
    loadingFlag = false;	
    modeCode = 14;
  }
  EVERY_N_MILLISECONDS(80) {updatesand(); randomdot();}  // 80 is speed of effect
  countSand();
}
//////////////////////////////////////////// SandRoutine*/

/*
/////////// Fire Brent ////////////
byte f_scale = 64;
byte f_speed = 7;
static uint32_t tt;

void FireBrent () {

 if (loadingFlag) {
  loadingFlag = false;
  tt = 0;
 }
  tt += f_speed;
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
     
      int16_t Bri = inoise8(x * f_scale, (y * f_scale) - tt) - (y * (255 / HEIGHT));
      byte Col = Bri;
       if (Bri < 0) Bri = 0; if(Bri != 0) Bri = 256 - (Bri * 0.2);
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, Col, Bri), f_speed);}
  }

}
/////////////////////////////////// Fire Brent*/

/*
////////// Curve /////////////////////

#define subPix 0

void drawCurve(uint8_t x, uint8_t y, uint8_t x2, uint8_t y2, uint8_t x3, uint8_t y3, CRGB col) {
  float xu = 0.0, yu = 0.0, u = 0.0;
  int i = 0;
  for (u = 0.0; u <= 1.0; u += 0.01) {
    xu = pow(1 - u, 3) * x + 3 * u * pow(1 - u, 2) * x2 + 3 * pow(u, 2) * (1 - u) * x3 +
      pow(u, 3) * x3;
    yu = pow(1 - u, 3) * y + 3 * u * pow(1 - u, 2) * y2 + 3 * pow(u, 2) * (1 - u) * y3 +
      pow(u, 3) * y3;
    leds[XY(xu, yu)] += col;
  }
}

void drawCurveF(float x, float y, float x2, float y2, float x3, float y3, CRGB col) {
  float xu = 0.0, yu = 0.0, u = 0.0;
  int i = 0;
  for (u = 0.0; u <= 1.0; u += 0.01) {
    xu = pow(1 - u, 3) * x + 3 * u * pow(1 - u, 2) * x2 + 3 * pow(u, 2) * (1 - u) * x3 +
      pow(u, 3) * x3;
    yu = pow(1 - u, 3) * y + 3 * u * pow(1 - u, 2) * y2 + 3 * pow(u, 2) * (1 - u) * y3 +
      pow(u, 3) * y3;
    drawPixelXYF(xu, yu, col);
  }
}

//byte huee; //already defined higher in bursts
//#define c_speed - 5 //already defined higher in bursts

void Curve () {

 if (loadingFlag) {
  loadingFlag = false;
  huee = 0;
  modeCode = 14;
    }	

  fadeToBlackBy(leds, NUM_LEDS, 150);
  byte x1 = beatsin8(18 + c_speed, 0, (WIDTH - 1));
  byte x2 = beatsin8(23 + c_speed, 0, (WIDTH - 1));
  byte x3 = beatsin8(27 + c_speed, 0, (WIDTH - 1));
  
  byte y1 = beatsin8(20 + c_speed, 0, (HEIGHT - 1));
  byte y2 = beatsin8(26 + c_speed, 0, (HEIGHT - 1));
  byte y3 = beatsin8(15 + c_speed, 0, (HEIGHT - 1));
  
  if (subPix)
    drawCurveF(x1, y1, x2, y2, x3, y3, CHSV(huee, 255, 255));
  else
    drawCurve(x1, y1, x2, y2, x3, y3, CHSV(huee, 255, 255));
  blur2d(leds, WIDTH, HEIGHT, 64);
  huee++;

}
////////////////////////////////////// Curve*/

/*
///////////////////Grid /////////////////
float offsetX = 0;
float offsetY = 0;
//uint8_t hue = 0;

void GridRoutine() 
{

  if (loadingFlag) {
	hue = 0;
    loadingFlag = false;
    modeCode = 14;
  }	

  offsetX = beatsin16(6, -180, 180);
  offsetY = beatsin16(6, -180, 180, 12000);

  EVERY_N_MILLISECONDS(10) {
    hue++;
  }

  for (int x = 0; x < WIDTH; x++) {
    for (int y = 0; y < HEIGHT; y++) {
      int16_t index = XY(x, y);

      if (index < 0) break;

      float hue = x * beatsin16(10, 1, 10) + offsetY;
      leds[index] = CHSV(hue, 200, sin8(x * 30 + offsetX));
      hue = y * 3 + offsetX;
      leds[index] += CHSV(hue, 200, sin8(y * 30 + offsetY));
    }
  }
}
///////////////////////////////////////// Grid*/


/*
////// Drops///////////////////
#define Sat (255)
#define Hue (150)
#define MaxRad WIDTH+HEIGHT
CRGBPalette16 currentPalette(PartyColors_p);

uint8_t d_hue;

int rad[(HEIGHT+WIDTH)/8];
byte posx[(HEIGHT+WIDTH)/8],posy[(HEIGHT+WIDTH)/8];

void drawPixelXY2(uint8_t x, uint8_t y, CRGB color) {
  if (x < 0 || x > (WIDTH - 1) || y < 0 || y > (HEIGHT - 1)) return;
    leds[XY(x,y)] += color;
}

void drawCircle(int x0, int y0, int radius, const CRGB &color){
  int aa = radius, bb = 0;
  int radiusError = 1 - aa;

  if (radius == 0) {
    drawPixelXY2(x0, y0, color);
    return;
  }
  while (aa >= bb)  {
    drawPixelXY2(aa + x0, bb + y0, color);
    drawPixelXY2(bb + x0, aa + y0, color);
    drawPixelXY2(-aa + x0, bb + y0, color);
    drawPixelXY2(-bb + x0, aa + y0, color);
    drawPixelXY2(-aa + x0, -bb + y0, color);
    drawPixelXY2(-bb + x0, -aa + y0, color);
    drawPixelXY2(aa + x0, -bb + y0, color);
    drawPixelXY2(bb + x0, -aa + y0, color);
    bb++;
    if (radiusError < 0)
      radiusError += 2 * bb + 1;
    else {
      aa--;
      radiusError += 2 * (bb - aa + 1);
    }
  }
}

void fillall() {

  if (loadingFlag) {
    loadingFlag = false;
    modeCode = 14;
  }

  for (int index = 0; index < NUM_LEDS; index++) {
    leds[index].g = index;
    leds[index].r = index;
    leds[index].b = index;
  }
}

void Drops() {

if (loadingFlag)
  {loadingFlag = false;
    currentPalette = CloudColors_p;
    d_hue = Hue;
      for (int i = 0; i < ((HEIGHT+WIDTH)/8)-1; i++)
  {
    posx[i]=random(WIDTH-1);
    posy[i]=random(HEIGHT-1);
    rad[i] = random(-1,MaxRad);
    }
  }
    fill_solid( currentPalette, 16, CHSV(d_hue,Sat,230));
    currentPalette[10] = CHSV(d_hue,Sat-60,255);
    currentPalette[9] = CHSV(d_hue,255-Sat,210);
    currentPalette[8] = CHSV(d_hue,255-Sat,210);
    currentPalette[7] = CHSV(d_hue,Sat-60,255);
    fillAll(ColorFromPalette(currentPalette,1));
     for (uint8_t i = ((HEIGHT+WIDTH)/8)-1; i > 0 ; i--){
    drawCircle(posx[i],posy[i], rad[i],ColorFromPalette(currentPalette,(256/16)*8.5-rad[i]));
    drawCircle(posx[i],posy[i], rad[i]-1,ColorFromPalette(currentPalette,(256/16)*7.5-rad[i]));
    if(rad[i] >= MaxRad){
    rad[i]=-1;
    posx[i]=random(WIDTH);
    posy[i]=random(HEIGHT);}
    else
    rad[i]++;
}
if(Hue == 0)
d_hue++;
blur2d(leds, WIDTH, HEIGHT, 64);
//delay(40);
}
/////////////////////////////// Drops

/*
/////// Fire with Sparks /////////
byte fs_scale = 50;
byte fs_speed = 35; // 20-100

bool withSparks = true; // true/false

const byte sparksCount = WIDTH/4;
const uint8_t spacer = HEIGHT/4;

static uint32_t ttt;

uint16_t RGBweight(uint16_t idx) {
  return (leds[idx].r + leds[idx].g + leds[idx].b);
}

class Spark {
  private:
    CRGB color;
    uint8_t Bri;
    //uint8_t fs_Hue;
    float x, y, speedy = (float)random(5, 30) / 10;
  
  public:
    void addXY(float nx, float ny) {
      //drawPixelXYF(x, y, 0);
      x += nx;
      y += ny * speedy;
    }

    float getY() {
      return y;
    }

    void reset() {
      uint32_t peak = 0;
      speedy = (float)random(5, 30) / 10;
      y = random(HEIGHT / 4, HEIGHT / 2);
      for (uint8_t i=0; i < WIDTH; i++) {
        uint32_t temp = RGBweight(XY(i, y));
        if (temp > peak) {
          x = i;
          peak = temp;
        }
      }
      
      color = leds[XY(x, y)];
      
    }

    void draw() {
      color.fadeLightBy(256 / (HEIGHT * 0.75));
      drawPixelXYF(x, y, color);
    }
}; 

Spark sparks[sparksCount];

bool firstStart = true;


void FireSparks() {

  if(firstStart) {
    for (byte i = 0; i < sparksCount; i++) sparks[i].reset();
    firstStart = false;
  }
  ttt += fs_speed;

  if (withSparks)
    for (byte i = 0; i < sparksCount; i++) {
      sparks[i].addXY((float)random(-1,2)/2, 0.75);
      if (sparks[i].getY() > HEIGHT and !random(0, 50)) sparks[i].reset();
      else sparks[i].draw();
    }

  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
     
      int16_t Bri = inoise8(x * fs_scale, (y * fs_scale) - ttt) - ((withSparks ? y + spacer : y) * (255 / HEIGHT));
      byte Col = Bri;
       if (Bri < 0) Bri = 0; if(Bri != 0) Bri = 256 - (Bri * 0.2);
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, Col, Bri), fs_speed);}
  }
//  delay(16);
}
////////////////////////////////// Fire with Sparks*/

/*
///////////// PulseTest //////////////////////
void PulseTest() {

  if (loadingFlag) {  loadingFlag = false;  modeCode = 14; }	  
//  fadeToBlackBy(leds, NUM_LEDS, 2);  
  static byte r = 9; //8  
  uint16_t apt=millis()/10;
  byte x = (apt/14)%WIDTH;
  byte y = (sin8(apt*5)+sin8(apt*4)+sin8(apt*2))/3*r/255;
  uint16_t index = XY (x,HEIGHT/2-r/2+y);
  leds[index].setHue(y*16-100); 
  blur2d(leds, WIDTH, HEIGHT, 3);
}
////////////////////////////////////////////// PulseTest*/

/*
/////////////// PArticles /////////////////// 
//some vars and subs are equal with FireBengal

//#define SPARKS_AM WIDTH
float P_FADE_KOEF = 1;

//float sparksPos[2][SPARKS_AM];
//float sparksSpeed[2][SPARKS_AM];
//float sparksFade[SPARKS_AM];
//byte sparksColor[SPARKS_AM];

//float genPos[2];
//float gravityPos[2];

float dist(float x1, float y1, float x2, float y2) {
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));}

//void reg(byte id) {
//  sparksPos[0][id] = fb_genPos[0];
//  sparksPos[1][id] = fb_genPos[1];
//  sparksSpeed[0][id] = (float)random(-15, 15)/10.;
//  sparksSpeed[1][id] = (float)random(-15, 15)/10.;
//  sparksFade[id] = 255;
//  sparksColor[id] = random();
// }  

void wu_pixel_col(uint32_t x, uint32_t y, CRGB * col) { 
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a,b) ((uint8_t) (((a)*(b)+(a)+(b))>>8))
  uint8_t wu[4] = {WU_WEIGHT(ix, iy), WU_WEIGHT(xx, iy),
                   WU_WEIGHT(ix, yy), WU_WEIGHT(xx, yy)};
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t xy = XY((x >> 8) + (i & 1), (y >> 8) + ((i >> 1) & 1));
    leds[xy].r = qadd8(leds[xy].r, col->r * wu[i] >> 8);
    leds[xy].g = qadd8(leds[xy].g, col->g * wu[i] >> 8);
    leds[xy].b = qadd8(leds[xy].b, col->b * wu[i] >> 8);
  }
}

int8_t sign(int8_t aaa){
  if(aaa < 0) return -1;
  if(aaa > 0) return 1;
  if(aaa == 0) return 0;
}
void p_phisics(byte id) {
  float force[2] { fb_gravityPos[0] - sparksPos[0][id], fb_gravityPos[1] - sparksPos[1][id]};
  float d = dist(force[0], force[1], force[0] * 2, force[1] * 2);
  force[0] *= (1. / d);
  force[1] *= (1. / d);
  d = constrain(d, 5., HEIGHT * 2.);
  float s = (1.5 * 10) / (d * d);
  force[0] *= s;
  force[1] *= s;
  sparksSpeed[0][id] += force[0];
  sparksSpeed[1][id] += force[1];
  sparksFade[id] -= (255. / (float)(((HEIGHT + WIDTH) / 2) * P_FADE_KOEF));
  float sq = ((sparksSpeed[0][id] * sparksSpeed[0][id]) + (sparksSpeed[1][id] * sparksSpeed[1][id]));
  if (sq > 2.25) {
    sq = sqrtf(sq);
    sparksSpeed[0][id] *= (1. / sq) * 1.5;
    sparksSpeed[1][id] *= (1. / sq) * 1.5;
  }
  sparksPos[0][id] += sparksSpeed[0][id];
  sparksPos[1][id] += sparksSpeed[1][id];
}

void p_render(byte id, CRGB Col) {
  if (loadingFlag) {
    for (byte i = 0; i < SPARKS_AM; i++) {
      reg(i,110); //<------------------------------------ тут яркость
      for (byte aaa = 0; aaa < i; aaa++) {
        p_phisics(aaa);
      }
    }
    loadingFlag = false;
  }
  p_phisics(id);
  if (sparksPos[1][id] < ((float)HEIGHT - 1.) and sparksPos[1][id] >= 0)
    if (sparksPos[0][id] < ((float)WIDTH - 1.) and sparksPos[0][id] >= 0) {
      CRGB color = Col;
      wu_pixel_col(sparksPos[0][id]*255, sparksPos[1][id]*255, & color);
    }
}

//void setGenPos(int x, int y) {
//  fb_genPos[0] = x;
//  fb_genPos[1] = y;
//}

//void setGravityPos(int x, int y) {
//  gravityPos[0] = x;
//  gravityPos[1] = y;
//}

//void setRegenRule(byte id, bool b) { if (b) reg(id); }

void Particles() {

  fadeToBlackBy(leds, NUM_LEDS, 40); //20
  setGenPos((float)beatsin16(10, 0, (WIDTH-1) * 10)/10., (float)beatsin16(10, 0, (HEIGHT-1) * 10, 0, 16384)/10.);
  setGravityPos((float)WIDTH / 2., (float)HEIGHT / 2.);
  for (byte i = 0; i < SPARKS_AM; i++) {
    setRegenRule(i, (sparksPos[0][i] <= 0 || sparksPos[0][i] >= (float)WIDTH - 1. || sparksPos[1][i] < 0 || sparksPos[1][i] >= (float)HEIGHT - 1. || sparksFade[i] <= 35) ? 1 : 0);
    p_render(i, CHSV(sparksColor[i], 255, constrain(sparksFade[i], 32, 255)));
  }
  //delay(16);
}
///////////////////////////////////////////// PArticles*/

/*
///////////// Volcano //////////////////////
//CRGB chsvLut[256];
byte bump[(WIDTH+2)*(HEIGHT+2)]; //also used for fire ring

//void generateCHSVlut(){
//for (int j= 0; j<256; j++) 
//  chsvLut[j] = ColorFromPalette(LavaColors_p, j, 255); 
//}

void generatebump (){
  int t=millis()/4;
  int index=0;
  
  for (byte j= 0; j< (HEIGHT+2); j++) {
    for (byte i=0; i< (WIDTH+2); i++) {                     
      byte col = (inoise8_raw(i * 25, j *25,t))/2; 
      bump[index++] = col; 
  }}
} 

void Bumpmap(){
  int yindex=WIDTH+3;
  int8_t vly=-(HEIGHT/2+1);
  
  for (byte y = 0; y < HEIGHT; y++) {  
    ++vly;
    int8_t vlx=-(WIDTH/2+1);
    for (byte x = 0; x < WIDTH; x++) {
      ++vlx;
      int8_t nx=bump[x+yindex+1]-bump[x+yindex-1];
      int8_t ny=bump[x+yindex+(WIDTH+2)]-bump[x+yindex-(WIDTH+2)]; 
      byte difx=abs8(vlx*7-nx);
      byte dify=abs8(vly*7-ny);
      int temp = difx*difx+dify*dify;
      int col = 255-temp/30;  //8 its a size of effect //24
      if (col<0) col=0;
      leds[XY(x,y)] = ColorFromPalette(LavaColors_p, col, 255); //thx satubarosu ))
    }
    yindex+=(WIDTH+2);
  }
}

void Volcano() {

  if (loadingFlag) {  loadingFlag = false;  modeCode = 14; } //generateCHSVlut();  }	
  
  generatebump();
  Bumpmap();     
}
////////////////////////////////////////////// Volcano */


//// cube 3D old///////////////////////////
/*double vectors[8][3] = {{3, 3, 3}, {-3, 3, 3}, { -3, -3, 3}, {3, -3, 3}, {3, 3, -3}, {-3, 3, -3}, {-3, -3, -3}, {3, -3, -3}};
//double vectors[8][3] = {{4, 4, 4}, { -4, 4, 4}, { -4, -4, 4}, {4, -4, 4}, {4, 4, -4}, { -4, 4, -4}, { -4, -4, -4}, {4, -4, -4}};
double perspective = 60.0f; //60.0f
int deltaX, deltaY, deltaZ, iter = 0;

int translateX(double x, double z) {
  return (int)((x + 12) + (z * (x / perspective))); //64
}

int translateY(double y, double z) {
  return (int)((y + 6) + (z * (y / perspective))); //32
}

void rotateX(int angle) {
  double rad, cosa, sina, Yn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < 8; i++) {
    Yn = (vectors[i][1] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][1] * sina) + (vectors[i][2] * cosa);
    vectors[i][1] = Yn;
    vectors[i][2] = Zn;
  }
}

void rotateY(int angle) {
  double rad, cosa, sina, Xn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < 8; i++)
  {
    Xn = (vectors[i][0] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][0] * sina) + (vectors[i][2] * cosa);
    vectors[i][0] = Xn;
    vectors[i][2] = Zn;
  }
}

void rotateZ(int angle) {
  double rad, cosa, sina, Xn, Yn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < 8; i++) {
    Xn = (vectors[i][0] * cosa) - (vectors[i][1] * sina);
    Yn = (vectors[i][0] * sina) + (vectors[i][1] * cosa);
    vectors[i][0] = Xn;
    vectors[i][1] = Yn;
  }
}

void drawVectors() {
  mydrawLine(translateX(vectors[0][0], vectors[0][2]), translateY(vectors[0][1], vectors[0][2]), translateX(vectors[1][0], vectors[1][2]), translateY(vectors[1][1], vectors[1][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[1][0], vectors[1][2]), translateY(vectors[1][1], vectors[1][2]), translateX(vectors[2][0], vectors[2][2]), translateY(vectors[2][1], vectors[2][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[2][0], vectors[2][2]), translateY(vectors[2][1], vectors[2][2]), translateX(vectors[3][0], vectors[3][2]), translateY(vectors[3][1], vectors[3][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[3][0], vectors[3][2]), translateY(vectors[3][1], vectors[3][2]), translateX(vectors[0][0], vectors[0][2]), translateY(vectors[0][1], vectors[0][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[4][0], vectors[4][2]), translateY(vectors[4][1], vectors[4][2]), translateX(vectors[5][0], vectors[5][2]), translateY(vectors[5][1], vectors[5][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[5][0], vectors[5][2]), translateY(vectors[5][1], vectors[5][2]), translateX(vectors[6][0], vectors[6][2]), translateY(vectors[6][1], vectors[6][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[6][0], vectors[6][2]), translateY(vectors[6][1], vectors[6][2]), translateX(vectors[7][0], vectors[7][2]), translateY(vectors[7][1], vectors[7][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[7][0], vectors[7][2]), translateY(vectors[7][1], vectors[7][2]), translateX(vectors[4][0], vectors[4][2]), translateY(vectors[4][1], vectors[4][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[0][0], vectors[0][2]), translateY(vectors[0][1], vectors[0][2]), translateX(vectors[4][0], vectors[4][2]), translateY(vectors[4][1], vectors[4][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[1][0], vectors[1][2]), translateY(vectors[1][1], vectors[1][2]), translateX(vectors[5][0], vectors[5][2]), translateY(vectors[5][1], vectors[5][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[2][0], vectors[2][2]), translateY(vectors[2][1], vectors[2][2]), translateX(vectors[6][0], vectors[6][2]), translateY(vectors[6][1], vectors[6][2]),CRGB(255,255,255),0,0);
  mydrawLine(translateX(vectors[3][0], vectors[3][2]), translateY(vectors[3][1], vectors[3][2]), translateX(vectors[7][0], vectors[7][2]), translateY(vectors[7][1], vectors[7][2]),CRGB(255,255,255),0,0);
}

void Cube3DRoutine() {

    if (loadingFlag) {
	  loadingFlag = false;
     modeCode = 14;
    }	
	FastLED.clear();
	drawVectors();
	if (iter == 0) {
		deltaX = random(7) - 3;		deltaY = random(7) - 3;		deltaZ = random(7) - 3;
		iter   = random(250) + 5;
	}
	rotateX(deltaX);	rotateY(deltaY);	rotateZ(deltaZ);
	iter--;
  //  timer = millis() - timer;
}
//////////////////////////////////////// Cube3D old
*/