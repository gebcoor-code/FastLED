// **************** НАСТРОЙКА МАТРИЦЫ ****************
#if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 0)
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y y

#elif (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 1)
#define _WIDTH HEIGHT
#define THIS_X y
#define THIS_Y x

#elif (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 0)
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y (HEIGHT - y - 1)

#elif (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 3)
#define _WIDTH HEIGHT
#define THIS_X (HEIGHT - y - 1)
#define THIS_Y x

#elif (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 2)
#define _WIDTH WIDTH
#define THIS_X (WIDTH - x - 1)
#define THIS_Y (HEIGHT - y - 1)

#elif (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 3)
#define _WIDTH HEIGHT
#define THIS_X (HEIGHT - y - 1)
#define THIS_Y (WIDTH - x - 1)

#elif (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 2)
#define _WIDTH WIDTH
#define THIS_X (WIDTH - x - 1)
#define THIS_Y y

#elif (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 1)
#define _WIDTH HEIGHT
#define THIS_X y
#define THIS_Y (WIDTH - x - 1)

#else
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y y
#pragma message "Wrong matrix parameters! Set to default"

#endif

uint16_t XY(uint8_t x, uint8_t y) {
  if ((x>WIDTH-1) || (y>HEIGHT-1)) {return NUM_LEDS;} //return virtual led counter
  if ((THIS_Y % 2 == 0) || MATRIX_TYPE) {               // если чётная строка
    return (THIS_Y * _WIDTH + THIS_X);
  } else {                                              // если нечётная строка
    return (THIS_Y * _WIDTH + _WIDTH - THIS_X - 1);
  }
}

void Line(int8_t x, int8_t y, int8_t x1, int8_t y1) {

  if ((x < 0 && x1 < 0) || (x >= WIDTH && x1 >= WIDTH) || 
      (y < 0 && y1 < 0) || (y >= HEIGHT && y1 >= HEIGHT)) {
    return;
  }
  
  //Brezenhem
  int8_t dx = abs(x1 - x);
  int8_t dy = abs(y1 - y);
  int8_t sx = (x < x1) ? 1 : -1;
  int8_t sy = (y < y1) ? 1 : -1;
  int8_t err = dx - dy;
  
  while (true) {
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
  
  #if (!LineColor)
      leds[XY((uint8_t)x, (uint8_t)y)] = CRGB::Yellow;
  #else
      leds[XY((uint8_t)x, (uint8_t)y)] = CRGB::White;
  #endif

    }
    
    if (x == x1 && y == y1) break;
    
    int8_t e2 = err * 2;
    
    if (e2 > -dy) {err -= dy; x += sx; }
    if (e2 < dx) { err += dx; y += sy; }
  }
}

void Line_color(int8_t x, int8_t y, int8_t x1, int8_t y1, const CRGB &color) {
  if ((x < 0 && x1 < 0) || (x >= WIDTH && x1 >= WIDTH) || 
      (y < 0 && y1 < 0) || (y >= HEIGHT && y1 >= HEIGHT)) {
    return;
  }
  
  // get current brigthness as sum
  int currentBrightness = color.r + color.g + color.b;
  
  int8_t dx = abs(x1 - x);
  int8_t dy = abs(y1 - y);
  int8_t sx = (x < x1) ? 1 : -1;
  int8_t sy = (y < y1) ? 1 : -1;
  int8_t err = dx - dy;
  
  while (true) {
    if (x >= 0 && x <= WIDTH-1 && y >= 0 && y <= HEIGHT-1) {
      //check up existing color
      CRGB existingColor = leds[XY(x, y)];
      int existingBrightness = existingColor.r + existingColor.g + existingColor.b;
      
      // draw only if empty or it is brighter
      if (existingBrightness == 0 || currentBrightness > existingBrightness) {
        leds[XY(x, y)] = color;
      }
    }
    
    if (x == x1 && y == y1) break;
    
    int8_t e2 = 2 * err;
    if (-dy < e2) {
      err -= dy;
      x += sx;
    }
    if (dx > e2) {
      err += dx;
      y += sy;
    }
  }
}

/////////DRAWS LiNEs/////////////////////////
////////////////////////////////////////////

void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, const CRGB & color) {
  int8_t deltaX = abs(x2 - x1);
  int8_t deltaY = abs(y2 - y1);
  int8_t signX = x1 < x2 ? 1 : -1;
  int8_t signY = y1 < y2 ? 1 : -1;
  int8_t error = deltaX - deltaY;
  
  leds[XY(x2, y2)] = color;
  while (x1 != x2 || y1 != y2) {
    leds[XY(x1, y1)] = color;
    int8_t error2 = error * 2;
    if (error2 > -deltaY) {
      error -= deltaY;
      x1 += signX;
    }
    if (error2 < deltaX) {
      error += deltaX;
      y1 += signY;
    }
  }
}

void mydrawLine (byte x, byte y, byte x1, byte y1, const CRGB &color, bool dot, bool grad){   // for 3Dtriangle

  byte xsteps = abs8(x - x1) + 1;
  byte ysteps = abs8(y - y1) + 1;
  byte steps = xsteps >= ysteps ? xsteps : ysteps;
  
  for (byte i = 1; i <= steps; i++) {
    byte dx = lerp8by8(x, x1, i * 255 / steps);
    byte dy = lerp8by8(y, y1, i * 255 / steps);
    
    if (dx<=WIDTH-1 && dy<=HEIGHT-1) {
      int index = XY(dx, dy);
      leds[index] += color; // change to += for brightness look
      if (grad) leds[index] %= (i * 255 / steps); //for draw gradient line
    }
  }
  
  if (dot) { //add white point at the ends of line 
    if (x<WIDTH && y<HEIGHT) leds[XY(x, y)] += CRGB::White;
    if (x1<WIDTH && y1<HEIGHT) leds[XY(x1, y1)] += CRGB::White;
  }
}

//////////// нужно поправить, просто 0 передавать и переставить переменные при вызове
void mydrawLine_DNA(byte y, byte y1, byte x, const CRGB &color, bool dot, bool grad) { //for DNA_horiz
  
byte steps = abs8(y - y1) + 1;
  
  for (byte i = 1; i <= steps; i++) {
    byte dy = lerp8by8(y, y1, i * 255 / steps);
    if (x<=WIDTH-1 && dy<=HEIGHT-1) {
      int index = XY(x, dy);
      leds[index] += color; // change to += for brightness look
      if (grad) leds[index] %= (i * 255 / steps); //for draw gradient line  
    }
  }
  
  if (dot) { //add white point at the ends of line 
    if (x<WIDTH && y<HEIGHT) leds[XY(x, y)] += CRGB::DarkSlateGray;
    if (x<WIDTH && y1<HEIGHT) leds[XY(x, y1)] += CRGB::White;
  }
}

void mydrawLine_twister(byte x, byte x1, byte y, const CHSV &color, bool dot, bool grad, byte numline, byte side, byte sinOff, uint16_t atw) { // my ugly hori line draw function )))
  
  byte steps = abs8(x1 - x)+1 ;
  for (uint16_t i = 1; i <= steps; i++) {
    byte dx = lerp8by8(x1, x, i * 255 / steps);
    uint16_t index = XY(dx, y);
    leds[index] = color; 
    if (grad) leds[index] %= (sin8(numline*8+side*64+atw+sinOff)+i*255/steps)/2; //for draw gradient line  
  }
    if (dot) { //add white point at the ends of line 
    leds[XY(x, y)] = CRGB::Black;
    leds[XY(x1, y)] = CRGB::Black;
  }
}

///////////////////////// drawlines

//////////// wu_pixel ///////////////
void wu_pixel(uint32_t x, uint32_t y, CRGB * col) { //awesome wu_pixel procedure by reddit u/sutaburosu
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t xy = XY((x >> 8) + (i & 1), (y >> 8) + ((i >> 1) & 1));
    leds[xy].r = qadd8(leds[xy].r, col -> r * wu[i] >> 8);
    leds[xy].g = qadd8(leds[xy].g, col -> g * wu[i] >> 8);
    leds[xy].b = qadd8(leds[xy].b, col -> b * wu[i] >> 8);
  }
}
//////////////////////////////////// wu_pixel

/////////////// drawPixel //////////////////////
void drawPixelXYF(float x,  float y,
  const CRGB & color) {
  if (x < 0 || y < 0 || x > ((float)WIDTH - 1) || y > ((float)HEIGHT - 1)) return;    
  // extract the fractional parts and derive their inverses
  uint8_t xx = (x - (int) x) * 255, yy = (y - (int) y) * 255, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    int16_t xn = x + (i & 1), yn = y + ((i >> 1) & 1);
    CRGB clr = leds[XY(xn, yn)];
    clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
    clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
    clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
    leds[XY(xn, yn)] = clr;
  }
  #undef WU_WEIGHT
}

void drawPixelXYF_X(float x, uint16_t y,
  const CRGB & color) {
  // extract the fractional parts and derive their inverses
  uint8_t xx = (x - (int) x) * 255, ix = 255 - xx;
  // calculate the intensities for each affected pixel
  uint8_t wu[2] = { ix, xx };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (int8_t i = 1; i >= 0; i--) {
    int16_t xn = x + (i & 1);
    CRGB clr = leds[XY(xn, y)];
      clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
      clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
      clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
    leds[XY(xn, y)] = clr;
  }
}

void drawPixelXYF_Y(uint16_t x, float y, const CRGB &color)
{
  if (x<0 || y<0 || x>((float)WIDTH) || y>((float)HEIGHT)) return;

  // extract the fractional parts and derive their inverses
  uint8_t yy = (y - (int)y) * 255, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  uint8_t wu[2] = {iy, yy};
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (int8_t i = 1; i >= 0; i--) {
      int16_t yn = y + (i & 1);
      CRGB clr = leds[XY(x, yn)];
      if(yn>0 && yn<(int)HEIGHT-1){
        clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
        clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
        clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
      } else if(yn==0 || yn==(int)HEIGHT-1) {
        clr.r = qadd8(clr.r, (color.r * 85) >> 8);
        clr.g = qadd8(clr.g, (color.g * 85) >> 8);
        clr.b = qadd8(clr.b, (color.b * 85) >> 8);
      }
    leds[XY(x, yn)] = clr;
  }
}

//in gyroscope only
void drawLineF(float x1, float y1,  float x2, float y2,
  const CRGB & col1,
    const CRGB & col2) {
  float deltaX = fabs(x2 - x1);
  float deltaY = fabs(y2 - y1);
  float steps = 255 / max(deltaX, deltaY);
  float error = deltaX - deltaY;
  CRGB col = col1;
  float signX = x1 < x2 ? 0.5 : -0.5;
  float signY = y1 < y2 ? 0.5 : -0.5;
  
  while (x1 != x2 || y1 != y2) {
    if ((signX > 0. && x1 > x2 + signX) || (signX < 0. && x1 < x2 + signX)) break;
    if ((signY > 0. && y1 > y2 + signY) || (signY < 0. && y1 < y2 + signY)) break;
    drawPixelXYF(x1, y1, nblend(col, col2, steps++));
    float error2 = error;
    if (error2 > -deltaY) {
      error -= deltaY;
      x1 += signX;
    }
    if (error2 < deltaX) {
      error += deltaX;
      y1 += signY;
    }
  }
}

void drawPixel(float x, float y, CRGB color) {
  drawPixelXYF(x, y, color);
  if (WIDTH > 24 || HEIGHT > 24) {
    if (x < WIDTH - 2) drawPixelXYF(x + 1, y, color);
    if (x > 1) leds[XY(x - 1, y)] += color;
    if (y < HEIGHT - 2) drawPixelXYF(x, y + 1, color);
    if (y > 1) drawPixelXYF(x, y - 1, color);
  }
}