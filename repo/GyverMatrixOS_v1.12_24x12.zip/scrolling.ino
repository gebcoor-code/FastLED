#include "font.h"

#define TEXT_HEIGHT 0     // высота, на которой бежит текст (от низа матрицы)
#define LET_WIDTH 5       // ширина буквы шрифта
#define LET_HEIGHT 8      // высота буквы шрифта
#define SPACE 1           // пробел

int offset = WIDTH;

uint8_t getFont(uint8_t font, uint8_t row) {
  if ((font>=0x41 && font<=0x5A) || (font>=0xC0 && font<=0xDF)) font &= 0xDF; //set letters as a capital.
  font = font - '0' + 0x10;   // перевод код символа из таблицы ASCII в номер согласно нумерации массива
  if (font <= 0x5A) return pgm_read_byte(&(fontHEX[font][row]));     // для английских букв и символов
  else if (font >= 0x70 && font <= 0x9F) {    // и пизд*ц ждя русских
    return pgm_read_byte(&(fontHEX[font - 0x2F][row]));
  } else if (font >= 0x60 && font <= 0x6F) {
    return pgm_read_byte(&(fontHEX[font - 0x0F][row]));
  }
}

void drawLetter(uint8_t index, uint8_t letter, int16_t offset, uint32_t color) {
  int8_t start_pos = 0, finish_pos = LET_WIDTH;
  CRGB letterColor;
  if (color == 1) letterColor = CHSV(byte(offset * 10), 255, 255);
  else if (color == 2) letterColor = CHSV(byte(index * 30), 255, 255);
  else letterColor = color;

  if (offset < -LET_WIDTH || offset > WIDTH) return;
  if (offset < 0) start_pos = -offset;
  if (offset > (WIDTH - LET_WIDTH)) finish_pos = WIDTH - offset;

  for (byte i = start_pos; i < finish_pos; i++) {
    int thisByte = getFont((byte)letter, i);

    for (byte j = 0; j < LET_HEIGHT; j++) {
      boolean thisBit;
      thisBit = thisByte & (1 << (LET_HEIGHT - 1 - j));
      if (thisBit) leds[XY(offset + i, TEXT_HEIGHT + j)] = letterColor;
      else leds[XY(offset + i, TEXT_HEIGHT + j)] = 0x000000;
    }
  }
}

void fillString(String text, uint32_t color) {
  if (loadingFlag) {
    offset = WIDTH;   // перемотка в правый край
    loadingFlag = false;    
    fullTextFlag = false;
  }
  
    FastLED.clear();
    int i = 0, j = 0;
    while (text[i] != '\0') {
      if ((byte)text[i] > 0xBF) {    // работаем с русскими буквами!
        i++;
      } else {
        drawLetter(j, text[i], offset + j * (LET_WIDTH + SPACE), color);
        i++;
        j++;
 
      }
    }
    fullTextFlag = false;

    offset--;
    if (offset < -j * (LET_WIDTH + SPACE)) {    // строка убежала
      offset = WIDTH + 3;
      fullTextFlag = true;
    }
    FastLED.show();

}