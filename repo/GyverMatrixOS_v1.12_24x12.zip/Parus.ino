//EXP GAMMA & COS_WAVE based 

uint8_t const exp_gamma[256] PROGMEM = { //put the array in the ROM
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,
    1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,   1,
    1,   2,   2,   2,   2,   2,   2,   2,   2,   2,   3,   3,   3,   3,   3,
    4,   4,   4,   4,   4,   5,   5,   5,   5,   5,   6,   6,   6,   7,   7,
    7,   7,   8,   8,   8,   9,   9,   9,   10,  10,  10,  11,  11,  12,  12,
    12,  13,  13,  14,  14,  14,  15,  15,  16,  16,  17,  17,  18,  18,  19,
    19,  20,  20,  21,  21,  22,  23,  23,  24,  24,  25,  26,  26,  27,  28,
    28,  29,  30,  30,  31,  32,  32,  33,  34,  35,  35,  36,  37,  38,  39,
    39,  40,  41,  42,  43,  44,  44,  45,  46,  47,  48,  49,  50,  51,  52,
    53,  54,  55,  56,  57,  58,  59,  60,  61,  62,  63,  64,  65,  66,  67,
    68,  70,  71,  72,  73,  74,  75,  77,  78,  79,  80,  82,  83,  84,  85,
    87,  89,  91,  92,  93,  95,  96,  98,  99,  100, 101, 102, 105, 106, 108,
    109, 111, 112, 114, 115, 117, 118, 120, 121, 123, 125, 126, 128, 130, 131,
    133, 135, 136, 138, 140, 142, 143, 145, 147, 149, 151, 152, 154, 156, 158,
    160, 162, 164, 165, 167, 169, 171, 173, 175, 177, 179, 181, 183, 185, 187,
    190, 192, 194, 196, 198, 200, 202, 204, 207, 209, 211, 213, 216, 218, 220,
    222, 225, 227, 229, 232, 234, 236, 239, 241, 244, 246, 249, 251, 253, 254,
    255};

const uint8_t cos_wave[256] PROGMEM = {
    0,   0,   0,   0,   1,   1,   1,   2,   2,   3,   4,   5,   6,   6,   8,
    9,   10,  11,  12,  14,  15,  17,  18,  20,  22,  23,  25,  27,  29,  31,
    33,  35,  38,  40,  42,  45,  47,  49,  52,  54,  57,  60,  62,  65,  68,
    71,  73,  76,  79,  82,  85,  88,  91,  94,  97,  100, 103, 106, 109, 113,
    116, 119, 122, 125, 128, 131, 135, 138, 141, 144, 147, 150, 153, 156, 159,
    162, 165, 168, 171, 174, 177, 180, 183, 186, 189, 191, 194, 197, 199, 202,
    204, 207, 209, 212, 214, 216, 218, 221, 223, 225, 227, 229, 231, 232, 234,
    236, 238, 239, 241, 242, 243, 245, 246, 247, 248, 249, 250, 251, 252, 252,
    253, 253, 254, 254, 255, 255, 255, 255, 255, 255, 255, 255, 254, 254, 253,
    253, 252, 252, 251, 250, 249, 248, 247, 246, 245, 243, 242, 241, 239, 238,
    236, 234, 232, 231, 229, 227, 225, 223, 221, 218, 216, 214, 212, 209, 207,
    204, 202, 199, 197, 194, 191, 189, 186, 183, 180, 177, 174, 171, 168, 165,
    162, 159, 156, 153, 150, 147, 144, 141, 138, 135, 131, 128, 125, 122, 119,
    116, 113, 109, 106, 103, 100, 97,  94,  91,  88,  85,  82,  79,  76,  73,
    71,  68,  65,  62,  60,  57,  54,  52,  49,  47,  45,  42,  40,  38,  35,
    33,  31,  29,  27,  25,  23,  22,  20,  18,  17,  15,  14,  12,  11,  10,
    9,   8,   6,   6,   5,   4,   3,   2,   2,   1,   1,   1,   0,   0,   0, 0};

int64_t frameCount = 0;

////// Plasma Waves //////////////////
void PlasmaWaves() {
    if (loadingFlag) {
      frameCount = 0; //added recently
	  loadingFlag = false;
    }	

EVERY_N_MILLISECONDS(1000 / 60) {
    frameCount++;
  }

  uint8_t t1 = cos8((42 * frameCount) / 30);
  uint8_t t2 = cos8((35 * frameCount) / 30);
  uint8_t t3 = cos8((38 * frameCount) / 30);

  for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
//      uint16_t pixelIndex = gridIndexHorizontal(x, y);

      // Calculate 3 seperate plasma waves, one for each color channel
      uint8_t r = cos8((x << 3) + (t1 >> 1) + cos8(t2 + (y << 3)));
      uint8_t g = cos8((y << 3) + t1 + cos8((t3 >> 2) + (x << 3)));
      uint8_t b = cos8((y << 3) + t2 + cos8(t1 + x + (g >> 2)));

      leds[XY(x,y)].r = pgm_read_byte(exp_gamma+r);
      leds[XY(x,y)].g = pgm_read_byte(exp_gamma+g);
      leds[XY(x,y)].b = pgm_read_byte(exp_gamma+b);
    }
  } 
}
/////////////////////////////////////// Plasma Waves

//////////////// Contrast Waves //////////////
void GammaCorrection() {   //gamma correction function 
byte r,g,b;
  for (uint16_t i=0; i<NUM_LEDS; i++){
    r=leds[i].r;
    g=leds[i].g;
    b=leds[i].b;
    leds[i].r = pgm_read_byte(exp_gamma + r);
    leds[i].g = pgm_read_byte(exp_gamma + g);
    leds[i].b = pgm_read_byte(exp_gamma + b);
  }
}

#define con_speed 5
#define w 2
#define C_SCALE 4

void Contrast() {

  uint16_t a1=millis()/32;
  uint16_t a2=a1/2;
  uint16_t a3=a1/3;

  uint16_t cx =  beatsin8 (10-con_speed,0,WIDTH)*C_SCALE;
  uint16_t cy =  beatsin8 (12-con_speed,0,HEIGHT)*C_SCALE;
  uint16_t cx1 = beatsin8 (13-con_speed,0,WIDTH)*C_SCALE;
  uint16_t cy1 = beatsin8 (15-con_speed,0,HEIGHT)*C_SCALE;
  uint16_t cx2 = beatsin8 (17-con_speed,0,WIDTH)*C_SCALE;
  uint16_t cy2 = beatsin8 (14-con_speed,0,HEIGHT)*C_SCALE;
  
  uint16_t xoffs=0;

  for (byte x = 0; x < WIDTH; x++) {

     xoffs += C_SCALE;
     uint16_t yoffs = 0;

    for (byte y = 0; y < HEIGHT; y++) {

       yoffs += C_SCALE;

      byte rdistort = pgm_read_byte(cos_wave + ((pgm_read_byte(cos_wave + (((x<<3)+a1)&255)) + pgm_read_byte(cos_wave + (((y<<3)-a2)&255)) + a3   )&255))>>1; 
      byte gdistort = pgm_read_byte(cos_wave + ((pgm_read_byte(cos_wave + (((x<<3)-a2)&255)) + pgm_read_byte(cos_wave + (((y<<3)+a3)&255)) + a1+32)&255))>>1; 
      byte bdistort = pgm_read_byte(cos_wave + ((pgm_read_byte(cos_wave + (((x<<3)+a3)&255)) + pgm_read_byte(cos_wave + (((y<<3)-a1)&255)) + a2+64)&255))>>1; 

      byte valueR = rdistort+ w*  (a1- ( ((xoffs - cx) *  (xoffs - cx) +  (yoffs - cy) *   (yoffs - cy))>>7  ));
      byte valueG = gdistort+ w*  (a2-( ((xoffs - cx1) * (xoffs - cx1) + (yoffs - cy1) *  (yoffs - cy1))>>7 ));
      byte valueB = bdistort+ w*  (a3-( ((xoffs - cx2) * (xoffs - cx2) + (yoffs - cy2) *  (yoffs - cy2))>>7 ));

      valueR = pgm_read_byte (cos_wave + valueR);
      valueG = pgm_read_byte (cos_wave + valueG);
      valueB = pgm_read_byte (cos_wave + valueB);

      uint16_t index = XY(x, y);
      leds[index].setRGB (valueR,valueG,valueB); 

    }
  }
  GammaCorrection();
}
/////////////////////////////////////////////// Contrast

//////////////////// Parus ////////////////////
inline uint8_t fastCosineCalc(uint16_t preWrapVal) {
  uint8_t wrapVal = (preWrapVal % 255);
  if (wrapVal < 0) wrapVal = 255 + wrapVal;
  return pgm_read_byte(cos_wave + wrapVal);
}

void Parus() {
if (loadingFlag) {
  loadingFlag = false;
  frameCount = 25500;
}

EVERY_N_MILLISECONDS(1000 / 60) {
    frameCount++;
  }
  
  uint16_t t = fastCosineCalc((42 * frameCount) / 30);
  uint16_t t2 = fastCosineCalc((35 * frameCount) / 30);
  uint16_t t3 = fastCosineCalc((38 * frameCount) / 30);
  
  for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
      uint16_t pixelIndex = XY(x, y);
      
      // Calculate 3 seperate plasma waves, one for each color channel
      uint8_t r = fastCosineCalc(((x << 3) + (t >> 1) + fastCosineCalc((t2 + (y << 3))))) * 0.5;
      uint8_t g = fastCosineCalc(((y << 3) + t + fastCosineCalc(((t3 >> 2) + (x << 3)))));
      uint8_t b = fastCosineCalc(((y << 3) + t2 + fastCosineCalc((t + x + (g >> 2)))));

      leds[XY(x,y)].r = pgm_read_byte(exp_gamma + r);
      leds[XY(x,y)].g = pgm_read_byte(exp_gamma + g);
      leds[XY(x,y)].b = pgm_read_byte(exp_gamma + b);
    }
  }
}
/////////////////////////////////////////////// Parus

//////////////////// Hipnotic ////////////////////
void Hipnotic() {

 int ha = millis()/8;
 for (byte x = 0; x < WIDTH; x++) {
   for (byte y = 0; y < HEIGHT; y++) {
     int index = XY(x, y);
     leds[index].b=pgm_read_byte(exp_gamma + sin8((x-8)*cos8((y+20)*4)/4+ha));
     leds[index].g=pgm_read_byte(exp_gamma + (sin8(x*16+ha/3)+cos8(y*8+ha/2))/2);
     leds[index].r=pgm_read_byte(exp_gamma +sin8(cos8(x*8+ha/3)+sin8(y*8+ha/4)+ha));
   }
  }
}
/////////////////////////////////////////////// Hipnotic
