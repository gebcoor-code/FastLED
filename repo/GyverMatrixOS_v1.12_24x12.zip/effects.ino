#include "palettes24x.h"

///////////////// SNOW ///////////////////////////
#define SNOW_DENSE 10     // плотность снегопада

void snowRoutine() {
  byte rr;    
   for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      if (leds[XY(x,y+1)] != CRGB (0x000000)) {
        rr=random(10);
        if ((rr !=  1) && (rr != 2)) leds[XY(x,y)] = leds[XY(x,y+1)];
        if ((rr == 1) && (x < WIDTH - 1)) leds[XY(x+1,y)] = leds[XY(x,y+1)];
        if ((rr == 2) && (x > 0)) leds[XY(x-1,y)] = leds[XY(x,y+1)];
        leds[XY(x,y+1)] = CRGB (0x000000);
      }
    }
  }
  for (byte x = 0; x < WIDTH; x++) {
      if ((leds[XY(x,HEIGHT-2)] == CRGB (0x000000)) && (random(0, SNOW_DENSE) == 0 ))
        leds[XY(x,HEIGHT-1)] = 0xE0FFFF - 0x101010 * random(0,5);
      else
        leds[XY(x,HEIGHT-1)] = CRGB(0x000000);
  }

  for (byte x = 0; x < WIDTH; x++) {
      leds[XY(x,0)] = 0;
  }

  //blur2d (leds,WIDTH, HEIGHT, 20);
   nscale8(leds, NUM_LEDS, 200);
}
//////////////////////////////////Snow

//////////////////////Matrix ////////////////////
void matrixRoutine() {
  if (loadingFlag) {loadingFlag = false; FastLED.clear(); }
  for (byte x = 0; x < WIDTH; x++) {
    CRGB thisColor = leds[XY(x,HEIGHT-1)];
    if (thisColor == 0)
    leds[XY(x,HEIGHT-1)] = 0x00FF00 * (random(0, 10) == 0);
    else if (thisColor < 0x002000)
      leds[XY(x,HEIGHT-1)] = 0;        
    else
      leds[XY(x,HEIGHT-1)] = thisColor - 0x002000;        
  }
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      leds[XY(x,y)] = leds[XY(x,y+1)];              
    }
  }
}
//////////////////////////////////////////////// Matrix

/////////////////Sparkles ///////////////////////////
void fader(byte step) {
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      fadePixel(i, j, step);
    }
  }
}
void fadePixel(byte i, byte j, byte step) {
  int pixelNum = XY(i, j);  
  if (leds[pixelNum] == 0) return;

  if (leds[pixelNum].r >= 10 || //30
      leds[pixelNum].g >= 10 || //30
      leds[pixelNum].b >= 10) { //30
    leds[pixelNum].fadeToBlackBy(step);
  } else {
    leds[pixelNum] = 0;
  }
}

///////////// Sparkles //////////////////
#define DENSE 5           // плотность конфетти //default 3
#define BRIGHT_STEP 50    // шаг уменьшения яркости //default 70

void sparklesRoutine() {
  for (byte i = 0; i < DENSE; i++) {
    byte x = random(0, WIDTH);
    byte y = random(0, HEIGHT);
    if (leds[XY(x,y)] == 0)
      leds[XY(x, y)] = CHSV(random(0, 255), 255, 255);
  }
  fader(BRIGHT_STEP);
}
///////////////////////sparkles

////////////// DNA Spirale /////////////////////
#define DNA_speeds 40 // speed of rotation 
#define DNA_freq 6 //change this will made spiral big or small 

void DNAspiralHoriz() { //rotated for 90 degrees to work properly on 24*12

  int ms = millis() / 10;
  nscale8(leds, NUM_LEDS, 120);
  
	for (byte i = 0; i < WIDTH; i++) {
		byte y = beatsin8(DNA_speeds, 0, WIDTH - 11, 0, i * DNA_freq) + beatsin8(DNA_speeds - 7, 0, WIDTH - 11, 0, i * DNA_freq + 128);
		byte y1 = beatsin8(DNA_speeds, 0, WIDTH - 11, 0, 128 + i * DNA_freq) + beatsin8(DNA_speeds - 7, 0, WIDTH - 11, 0, 128 + 64 + i * DNA_freq); 
    
		hue = i * 128 / (WIDTH - 1) + ms;
		CRGB color = CHSV(hue, 255, 255);
    
		if ((i + ms / 8) & 3) mydrawLine_DNA(y / 2, y1 / 2, i, color, 1, 1);
	}
} /////////// end DNA spirale Horiz

////////////// 3D triangle /////////////////////
void draw3Dtriangle () {

EVERY_N_MILLISECONDS(30) { hue++; }  //30 - speed of hue change
#define tr_speed -5                     //global speed of dots move  

	byte x1 = beatsin8 (18+tr_speed, 0, (WIDTH-1));
	byte x2 = beatsin8 (23+tr_speed, 0, (WIDTH-1)); 
	byte x3 = beatsin8 (27+tr_speed, 0, (WIDTH-1)); 
	byte x4 = beatsin8 (31+tr_speed, 0, (WIDTH-1)); 
	byte x5 = beatsin8 (33+tr_speed, 0, (WIDTH-1)); 

	byte y1 = beatsin8 (20+tr_speed, 0, (HEIGHT-1)); 
	byte y2 = beatsin8 (26+tr_speed, 0, (HEIGHT-1));
	byte y3 = beatsin8 (15+tr_speed, 0, (HEIGHT-1));
	byte y4 = beatsin8 (27+tr_speed, 0, (HEIGHT-1));
	byte y5 = beatsin8 (30+tr_speed, 0, (HEIGHT-1));

	CRGB color = CHSV (hue,255,255);

	fadeToBlackBy (leds,NUM_LEDS, 200);

	mydrawLine(x1, y1,  x2, y2, color, 0, 0); // 1 is white dot 0 is no white dot
	mydrawLine(x2, y2,  x3, y3, color, 0, 0);
	mydrawLine(x3, y3,  x1, y1, color, 0, 0);
	mydrawLine(x4, y4,  x1, y1, color, 0, 0);
	mydrawLine(x4, y4,  x2, y2, color, 0, 0);
	mydrawLine(x4, y4,  x3, y3, color, 0, 0);

	blur2d (leds,WIDTH, HEIGHT, 8);
}
/////////////////////////////////////////////// 3D Triangle

/////////////// Color Frizzles ////////////////
void ColorFrizzlesRoutine() {
  fadeToBlackBy(leds, NUM_LEDS, 70);
  for(byte i=11; i > 0;i--) {
    leds[XY(beatsin8(12+i,0,WIDTH+(random(5)-5)),beatsin8(15-i,0,HEIGHT+(random(5)-5)))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH+(random(5)-5))+1,beatsin8(15-i,0,HEIGHT+(random(5)-5)))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH+(random(5)-5))-1,beatsin8(15-i,0,HEIGHT+(random(5)-5)))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH+(random(5)-5)),beatsin8(15-i,0,HEIGHT+(random(5)-5))+1)]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH+(random(5)-5)),beatsin8(15-i,0,HEIGHT+(random(5)-5))-1)]+=CHSV(beatsin8(12,0,255),255,255);
/*  for(byte i=8; i > 0;i--){leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
  if(WIDTH >24 || HEIGHT >24){
    leds[XY(beatsin8(12+i,0,WIDTH-1)+1,beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1)-1,beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1)+1)]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1)-1)]+=CHSV(beatsin8(12,0,255),255,255);
  }*/
  }blur2d(leds,WIDTH,HEIGHT,16);
}
//////////////// Color Frizzles

/////////////// FlyBycicle /////////////////
void FlyBycicleRoutine() {
	
  FastLED.clear();
  for(byte i=0;i< 16;i++){
    drawPixelXYF((float)beatsin16(20,10,(WIDTH-2)*10,0,-beatsin16(10,1,2048)*i)/10,(float)beatsin16(20,10,(HEIGHT-2)*10,0,16384-beatsin16(10,0,2048)*i)/10,CHSV(0,0,255));
  }
}
//////////////////////////////////////////// FlyBycicle

//////////////// SineWavesRoutine //////////
#define SW_SPEED 30
#define SW_SCALE 1
#define SW_AMPLITUDE 200

static float fmap(const float x,
  const float in_min,
    const float in_max,
      const float out_min,
        const float out_max) {
  return (out_max - out_min) * (x - in_min) / (in_max - in_min) + out_min;
}

const uint8_t semiHeightMajor = HEIGHT / 2 + (HEIGHT % 2);
const uint8_t semiWidthMajor = WIDTH / 2 + (WIDTH % 2);
float e_s3_speed, e_s3_size; // amplitude of the curves
uint8_t _scale;

void SineWavesRoutine(bool swr) {
  if (loadingFlag) {
    loadingFlag = false;
    e_s3_speed = 0.004 * SW_SPEED + 0.015; // speed of the movement along the Lissajous curves
    e_s3_size = fmap(SW_AMPLITUDE, 1, 255, 3, 9); // amplitude of the curves
    _scale = map8(SW_SCALE, 50, 150);
  }
  
  float time_shift = millis();
  uint8_t y; uint8_t x;
  float cx; float cy;
  int8_t v;

 struct {
    float shiftX;
    float shiftY;
  }sshft[2];

  sshft[0].shiftX = float(e_s3_size * (sin16(e_s3_speed * 98.301 * time_shift))) / 32767.0;
  sshft[0].shiftY = float(e_s3_size * (sin16(e_s3_speed * 72.0874 * time_shift))) / 32767.0;
  sshft[1].shiftX = float(e_s3_size * (sin16(e_s3_speed * 134.3447 * time_shift))) / 32767.0;
  sshft[1].shiftY = float(e_s3_size * (sin16(e_s3_speed * 170.3884 * time_shift))) / 32767.0;
  //sshft[2].shiftX = float(e_s3_size * (sin16(e_s3_speed * 68.8107 * time_shift))) / 32767.0;
  //sshft[2].shiftY = float(e_s3_size * (sin16(e_s3_speed * 65.534 * time_shift))) / 32767.0;

  //Sinusoid I
  if (!swr) {
    for (y = 0; y < HEIGHT; y++) {
      for (x = 0; x < WIDTH; x++) {
      
        cx = (y - semiHeightMajor) + float(e_s3_size * (sin16(e_s3_speed * 98.301 * time_shift))) / 32767.0; // the 8 centers the middle on a 16x16
        cy = (x - semiWidthMajor) + float(e_s3_size * (cos16(e_s3_speed * 72.0874 * time_shift))) / 32767.0;
        v = sin8((_scale / 2) * sqrt((((float) cx * cx) + ((float) cy * cy))));
        leds[XY(x, y)].r = ~v;
      
        cx = (y - semiHeightMajor) + float(e_s3_size * (sin16(e_s3_speed * 134.3447 * time_shift))) / 32767.0;
        cy = (x - semiWidthMajor) + float(e_s3_size * (cos16(e_s3_speed * 170.3884 * time_shift))) / 32767.0;
        v = sin8((_scale / 2) * sqrt((((float) cx * cx) + ((float) cy * cy))));
        leds[XY(x, y)].b = ~v;
      }
    }
  }
  //Sinusoid II
  else {
    for (y = 0; y < HEIGHT; y++) {
      for (x = 0; x < WIDTH; x++) {
        cx = (y - semiHeightMajor) + sshft[0].shiftX; // the 8 centers the middle on a 16x16
        cy = (x - semiWidthMajor) + sshft[0].shiftY;
        int8_t v = sin8(_scale * sqrt(( cx * cx) + ( cy * cy)));
        leds[XY(x,y)].r = ~v;
      
        cx = (y - semiHeightMajor) + sshft[1].shiftX;
        cy = (x - semiWidthMajor) + sshft[1].shiftY;
        v = sin8(_scale * sqrt(( cx * cx) + ( cy * cy)));
        leds[XY(x,y)].b = ~v;
      }
    }
  }
}
//////////////////////////////////////////// SineWaves

/////////////// Twinkles (random fade) //////////////
void TwinklesRoutine() {

 if (loadingFlag) {loadingFlag=false; speed=0;}
 //byte offset = 0; //offset

  EVERY_N_MILLISECONDS(200) {
    speed++;
  }
  
  random16_set_seed(23579);
  double a = millis()*1.2;  //w/o 
  for (int i = 0; i < NUM_LEDS; i++) {
    hue = sin8((random16() / 256) + inoise8(random16() / 256 + a / 32) + i * 4);
    brightness = sin8(random16() / 256 + inoise8(random16() / 256 + a / 32) + a / 16);
    nblend(leds[i], CHSV(hue + speed, 255, brightness), 255);
    //nblend(leds[i], ColorFromPalette(LavaColors_p, hue + offset, bright), 128);	
  }
 }
/////////////////////////////////////////////////////TwinklesRoutine

/////////////////////// similar sine effects ////////

float code(double t, double i, double x, double y, byte effect) {

switch (effect){
	case 2:return sin(y*sin(t/2)*4+t*4+i*6); break; //вращающиеся полосы (t/2)*speed+
	case 6:return 1-fmod(( (0.3*t+x+sin(0.3*t+x)/2) -y/30),1.0); break; // matrix style, 0.3*t+
	} 
}

void processFrame(double t, double x, double y, byte effect) {
   EVERY_N_MILLISECONDS( 30 ) { hue++; }
  double i = (y * 16) + x;
  double frame = constrain(code(t, i, x, y, effect), -1, 1) * 255;
  if (frame >= 0) { leds[XY(x, (HEIGHT - 1 - y))]= CHSV(hue,255,frame); } //change to XY(x, y) for non rotate display
  else { leds[XY(x, (HEIGHT - 1 - y))] = CHSV(hue+55, 255, -frame); } //change to XY(x, y) for non rotate display
}

void SineEffectsRoutine(byte effect) {
	
  double t = millis() / 1000.0; // some formulas is hardcoded and fps get down. this speedup it
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      processFrame(t, x, y, effect);
    }
  }
}
/////////////////////////////////////////////////////Similar Sine Effects

//////////////////Spiro /////////////////
#define CenterX ((WIDTH / 2) - 0.5)
#define CenterY ((HEIGHT / 2) - 0.5)
byte AM = 3;
float Angle;
bool change = true;
bool incenter; 

void SpiroRoutine() {

  if (loadingFlag) {
    AM = 3;   //to start from the begin
    loadingFlag = false;
  }	
	
  fadeToBlackBy(leds, NUM_LEDS, 50);
  float t = (float)millis() / 500.0f;
  float CalcRad = (sin(t / 2) + 1);
  if (CalcRad <= 0.001) {
    if(!incenter){
    AM += ((change * 2) - 1);
    Angle = 6.28318531 / AM;
    if (AM <= 1) change = true;
    else if (AM >= (WIDTH + HEIGHT) / 2) change = false;}
    incenter = 1;
  } else incenter = 0;
  float radX = CalcRad * CenterX / 2;
  float radY = CalcRad * CenterY / 2;
  for (byte i = 0; i < AM; i++) {
    drawPixelXYF((CenterX + sin(t + (Angle * i)) * radX), (CenterY + cos(t + (Angle * i)) * radY), ColorFromPalette(HeatColors_p, t*10 + ((256 / AM) * i)));
  }
}
///////////////////////////////////////// Spiroroutine

////////////// SimpleSin ///////////////
  float f_offset = 0;
  
void SimpleSinRoutine() {

  FastLED.clearData();

  for (byte i = 0; i < WIDTH; i++) {
    f_offset += 0.025;
    float sinus = sin(((float)i+f_offset) / 3.0f);
    sinus += 1;
    sinus *= 5;
    leds[XY(i,sinus)] = CRGB(255, 255, 255);
  }
  blur2d(leds, WIDTH, HEIGHT, 128);
}
//////////////////////////////////////// SimpleSin

///// Ex9 - NiceOne ////////////////////
#define kBorderWidth 2

void Ex9NiceOne () {

uint8_t blurAmount = 20; // beatsin8(2, 10, 255);
  blur2d(leds, WIDTH, HEIGHT, blurAmount);

  // Use two out-of-sync sine waves
  uint8_t i = beatsin8(27, kBorderWidth, HEIGHT - kBorderWidth);
  uint8_t j = beatsin8(41, kBorderWidth, WIDTH - kBorderWidth);
  // Also calculate some reflections
  uint8_t ni = (WIDTH - 1) - i;
  uint8_t nj = (WIDTH - 1) - j;

  // The color of each point shifts over time, each at a different speed.
  uint16_t ms = millis();
  leds[XY(i, j)] += CHSV(ms / 11, 200, 255);
  leds[XY(j, i)] += CHSV(ms / 13, 200, 255);
  leds[XY(ni, nj)] += CHSV(ms / 17, 200, 255);
  leds[XY(nj, ni)] += CHSV(ms / 29, 200, 255);
  leds[XY(i, nj)] += CHSV(ms / 37, 200, 255);
  leds[XY(ni, j)] += CHSV(ms / 41, 200, 255);

}
//////////////////////////////////////// Ex9-NiceOne

////////// Starship /////////////////////

const float SPEED_ADJ = (float)NUM_LEDS /256;
#define chance 2048
#define s_speed 100 // 1-255
#define s_scale 8
#define DIR_CHARGE 2 // Chance to change direction 1-5 

byte dir = 3; //also used in starship
byte count = 0;
float x1, y1;
float speedFactor = fmap(s_speed, 1, 255, 0.25, 1);

void Starship () {

    if (loadingFlag) {
     // dir = 3;
     // palette = 0;
     // count = 0;
      float speedFactor = fmap(s_speed, 1, 255, 0.25, 1);

	    loadingFlag = false;
    }	


randomSeed(millis());
  fadeToBlackBy(leds, NUM_LEDS, map(s_speed, 1, 255, 5, 10));
  switch (dir) {
    case 0: // Up
      for (byte x = 0; x < WIDTH; x++) {
		    if (x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (float y = 0; y < HEIGHT; y+=speedFactor) {
          leds[XY(x, y)] = (((int)y == HEIGHT - 1) ? CRGB::Black : leds[XY(x, y+1)]);
        }
      }
      break;
    case 1: // Up - Right 
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = 0; y < HEIGHT; y++) {
          leds[XY(x, y)] = ((y == HEIGHT - 1 or (int)x == WIDTH - 1) ? CRGB::Black : leds[XY(x+1, y+1)]);
        }
      }
      break;
    case 2: // Right
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = (((int)x == WIDTH - 1) ? CRGB::Black : leds[XY(x+1, y)]);
        }
      }
      break;
    case 3: // Down - Right 
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = (((int)x == WIDTH - 1 or y == 0) ? CRGB::Black : leds[XY(x+1, y-1)]);
        }
      }
      break;
    case 4: // Down
      for (byte x = 0; x < WIDTH; x++) {
		    if (x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (float y = HEIGHT - 1; y > 0; y-=speedFactor) {
          leds[XY(x, y)] = (((int)y == 0) ? CRGB::Black : leds[XY(x, y-1)]);
        }
      }
      break;
    case 5: // Down - Left
      for (float x = WIDTH - 1; x > 0; x-=speedFactor) {
        if (!(uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = ((y == 0 or (int)x == 0) ? CRGB::Black : leds[XY(x-1, y-1)]);
        }
      }
      break;
    case 6: // Left
      for (float x = WIDTH - 1; x > 0; x-=speedFactor) {
        if ((uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = ((int)x == 0 ? CRGB::Black : leds[XY(x-1, y)]);
        }
      }
      break;
    case 7: // Up - Left 
      for (float x = WIDTH -1; x >0; x-=speedFactor) {
        if ((uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = ((y == HEIGHT - 1 or (int)x == 0) ? CRGB::Black : leds[XY(x-1, y+1)]);
        }
      }
      break;
  }


  for (byte i = 0; i < s_scale; i++) {
    x1 = (float)beatsin88(3840*speedFactor + i*256, 0, (WIDTH-1) *4, 0, s_scale*i*256) /4;
    y1 = (float)beatsin88(3072*speedFactor + i*256, 0, (HEIGHT-1) *4, 0, 0) /4;
    if ((x1 >= 0 and x1 <= WIDTH-1) and (y1 >= 0 and y1 <= HEIGHT -1)) drawPixel(x1, y1, ColorFromPalette(*pal_arr[palette], beatsin88(256*12.*speedFactor + i*256, 0, 255), 255));
  }

  blur2d(leds, WIDTH, HEIGHT, 64);
  dir = count%8;  
  palette = count%countpal; //qty of palettes in array pal_arr

}
//////////////////////////////////////// Starship

//////////Colored Bursts /////////////
static byte numLines = 10;    

#define CB_SPEED - 5 //global speed of dots move  

void ColoredBursts () {

  EVERY_N_MILLISECONDS(30) { hue++; } //30 - speed of hue change
  EVERY_N_MILLISECONDS(1000) {   // for change number of lines. Can be commented in not need
    if (random8(2)) {
      numLines++;
      if (numLines > 15) numLines = 15;
    } else { numLines--; if (numLines < 5) numLines = 5; }
  }
  
    fadeToBlackBy(leds, NUM_LEDS, 40);
  
  for (byte i = 0; i < numLines; i++) {
    
    byte x1 = beatsin8(12 + CB_SPEED, 0, (WIDTH - 1));
    byte x2 = beatsin8(10 + CB_SPEED, 0, (WIDTH - 1));
    byte y1 = beatsin8(25 + CB_SPEED, 0, (HEIGHT - 1), 0, i * 24);
    byte y2 = beatsin8(20 + CB_SPEED, 0, (HEIGHT - 1), 0, i * 48 + 64);
    
    CRGB color = CHSV(i * 255 / 10 + hue, 255, 255);
    hue++;
    mydrawLine(x1, x2, y1, y2, color, 0, 1); // for move
    // mydrawLine(WIDTH/2, HEIGHT/2, y1, y2, color, 0, 1); // for center
  }
  
  blur2d(leds, WIDTH, HEIGHT, 8);

}

////////////////////////////////////// Colored Bursts

////////////////// Drift ////////////

#define CenterX ((WIDTH / 2) - 0.5)
#define CenterY ((HEIGHT / 2) - 0.5)
//const byte maxDim = max(WIDTH, HEIGHT); //already defined higher
byte effect= 0;

void Drift() {

 if (loadingFlag) {
  loadingFlag = false;
  effect = random(4); }	

FastLED.clear(); //fadeToBlackBy(leds, NUM_LEDS, 16);
  t = millis()/20; //20 - default
  for(float i = 1; i <maxDim / 2; i+=0.5) {
    double angle = radians(t * (maxDim/2-i));
    drawPixelXYF(CenterX + sin(angle) * i, CenterY + cos(angle) * i, ColorFromPalette(PartyColors_p, (i * 20) + (t / 20))); //case for all
    switch(effect){
    case 1: case 3: drawPixelXYF(CenterX + cos(angle) * i, CenterY + sin(angle) * i, ColorFromPalette(PartyColors_p, (i * 20) + (t / 20)));break;
  }}
  switch(effect){
    case 2: case 3: blur2d(leds, WIDTH, HEIGHT, 16); break;
  }
//  fadeToBlackBy(leds, NUM_LEDS, 30);
}

///////////////////////////////////// Drift

///////////// Drift Rose ////////////
//#define CX WIDTH / 2. - 0.5  // defined higher
//#define CY HEIGHT / 2. - 0.5 // defined higher
#define L (min(WIDTH, HEIGHT)) // /2 - makes it squarer

void DriftRose () {

 for (byte i = 1; i < 37; i++) {
    drawPixelXYF(CenterX + (sin(radians(i * 10)) * (beatsin8(i, 0, L*2)-L)), CenterY + (cos(radians(i * 10)) * (beatsin8(i, 0, L*2)-L)), CHSV(i * 10, 255, 255));
  }
  fadeToBlackBy(leds, NUM_LEDS, 32);
  blur2d(leds, WIDTH, HEIGHT, 16);
}
///////////////////////////////////// Drift Rose

///////////// FireBengal ///////////
#define SPARKS_AM WIDTH + HEIGHT
//#define GenPosVar 1  //0 - in center, 1 - moves by boards set it as subparameter
float FADE_KOEF = .5;
float SpeedK = .98;
float SpeedDecX = .01;
float SpeedDecY = 0;
#define Bounce 0
#define GravityX 0
#define GravityY 1

int sparksPos[2][SPARKS_AM];
float sparksSpeed[2][SPARKS_AM];
float sparksFade[SPARKS_AM];
float sparksSat[SPARKS_AM];
byte sparksColor[SPARKS_AM];

int fb_genPos[2];
int fb_gravityPos[2];
static byte period = 10;
bool run = true;

//bool loadingFlag = true;
void reg(byte id, byte fb_fade) {
  sparksPos[0][id] = fb_genPos[0];
  sparksPos[1][id] = fb_genPos[1];
  sparksSpeed[0][id] = random(-10, 10);
  sparksSpeed[1][id] = random(-5, 20);
  sparksSat[id] = 10;
  sparksFade[id] = fb_fade; //здесь раньше было просто 255, но для fire bengal и для particles установил разные.
  sparksColor[id] = random();
}

void phisics(byte id) {
  if (SpeedK) {
    if (GravityX) {
      if (fb_gravityPos[0] < sparksPos[0][id])
        sparksSpeed[0][id] -= SpeedK;
      else
        sparksSpeed[0][id] += SpeedK;
    }
    if (GravityY) {
      if (fb_gravityPos[1] < sparksPos[1][id])
        sparksSpeed[1][id] -= SpeedK;
      else
        sparksSpeed[1][id] += SpeedK;
    }
  }
  sparksFade[id] -= (255. / (float)((HEIGHT + WIDTH) * FADE_KOEF));
  sparksSat[id] += (255. / (float)((WIDTH + WIDTH) * (FADE_KOEF - 0.2)));
  if (SpeedDecX || sparksSpeed[0][id]) {
    if (sparksSpeed[0][id] > 0)
      sparksSpeed[0][id] -= SpeedDecX;
    else
      sparksSpeed[0][id] += SpeedDecX;
    if (abs(sparksSpeed[0][id]) <= SpeedDecX)
      sparksSpeed[0][id] = 0;
  }
  if (SpeedDecY || sparksSpeed[1][id]) {
    if (sparksSpeed[1][id] > 0)
      sparksSpeed[1][id] -= SpeedDecY;
    else
      sparksSpeed[1][id] += SpeedDecY;
    if (abs(sparksSpeed[1][id]) <= SpeedDecY)
      sparksSpeed[1][id] = 0;
  }
  if (Bounce) { if (sparksPos[0][id] < 0 || sparksPos[0][id] >= WIDTH * 10) sparksSpeed[0][id] = -sparksSpeed[0][id]; if (sparksPos[1][id] < 0) sparksSpeed[1][id] = -sparksSpeed[1][id]; }
    sparksPos[0][id] += sparksSpeed[0][id];
    sparksPos[1][id] += sparksSpeed[1][id];
}

void render(byte id, CRGB Col) {
  if (loadingFlag) {
    for (byte i = 0; i < SPARKS_AM; i++) {
      reg(i,255);
      for (byte a = 0; a < i; a++) {
        phisics(a);
      }
    }
    loadingFlag = false;
  }
  phisics(id);
  if (sparksPos[1][id] < ((HEIGHT - 1) * 10) and sparksPos[1][id] >= 0)
    if (sparksPos[0][id] < ((WIDTH - 1) * 10) and sparksPos[0][id] >= 0) {
      CRGB color = Col;
      wu_pixel(sparksPos[0][id] * 25.6, sparksPos[1][id] * 25.6, & color);
    }
}

void setGenPos(int x, int y) {
  fb_genPos[0] = x;
  fb_genPos[1] = y;
}

void setGravityPos(int x, int y) {
  fb_gravityPos[0] = x;
  fb_gravityPos[1] = y;
}

void setRegenRule(byte id, bool b) {
  if (b) reg(id,255);
}

void FireBengal (bool GenPosVar) { //0 - from center, 1 - moves by boards

  fadeToBlackBy(leds, NUM_LEDS, beatsin8(5, 20, 100));
  if(GenPosVar){setGenPos(beatsin16(10, 0, WIDTH * 10), beatsin16(10, 0, HEIGHT * 10, 0, 16384));}
  else {setGenPos(WIDTH * 5, HEIGHT * 5); }
  setGravityPos(0, 0);
  for (byte i = 0; i < SPARKS_AM; i++) {
    setRegenRule(i,(sparksPos[0][i] <= 0 || sparksPos[0][i] >= (WIDTH - 1) * 10 || sparksPos[1][i] < 0) ? 1 : 0);
    render(i, CHSV(sparksColor[i], constrain(sparksSat[i], 5, 255), constrain(sparksFade[i], 32, 255)));
      EVERY_N_SECONDS(period) {
        for (byte i = 0; i < SPARKS_AM; i++) reg(i,255);
        period = random(10, 60);}
  }
}
//////////////////////////////////// FireBengal

/////////////// Crazy Bee///////////
byte b_coord[2][2];
uint16_t offest;

void CrazyBee() {

 fadeToBlackBy(leds, NUM_LEDS, 2);
  long t = millis();
  offest++;
  b_coord[0][1] = b_coord[0][0];
  b_coord[1][1] = b_coord[1][0];
  byte x = inoise8(t, offest);
  x = qadd8(qsub8(x,16),scale8(qsub8(x,16),39));
  byte y = inoise8(offest,t);
  y = qadd8(qsub8(y,16),scale8(qsub8(y,16),39));
  b_coord[0][0] = map(x, 0, 255, 0, WIDTH - 1);
  b_coord[1][0] = map(y, 0, 255, 0, HEIGHT - 1);
  //drawLine(b_coord[0][0], b_coord[1][0], b_coord[0][1], b_coord[1][1], CHSV(qadd8(qsub8(inoise8(offest),32),scale8(qsub8(inoise8(offest),16),39)),255,255));
  drawLine(b_coord[0][0], b_coord[1][0], b_coord[0][1], b_coord[1][1], CRGB::White);
  blur2d(leds, WIDTH, HEIGHT, 16);
}
//////////////////////////////////// Crazy Bee

////////// Plasm Ball //////////////

//double t = 0;
void PlasmBall () {

  fadeToBlackBy(leds, NUM_LEDS, 60);
  double t = millis()/8; //16
  for (byte i = 0; i < WIDTH; i++) {
    byte thisVal = inoise8(i * 30, t, t);
    byte thisMax = map(thisVal, 0, 255, 0, WIDTH);
    for (byte j = 0; j < HEIGHT; j++) {
      byte thisVal_ = inoise8(t, j * 30, t);
      byte thisMax_ = map(thisVal_, 0, 255, 0, HEIGHT);
      byte x = (i+thisMax_);// -(WIDTH * 2 - WIDTH) / 2);
      byte y = (j+thisMax);// -(WIDTH * 2 - WIDTH) / 2);
      byte cx = x;//(i+thisMax_);
      byte cy = y;//(j+thisMax);
      leds[XY(i, j)] += ((x-y > -2) && (x-y < 2)) || ((WIDTH - 1 - x-y) > -2 && (WIDTH - 1 - x-y < 2)) || (WIDTH - cx == 0) || (WIDTH - 1 - cx == 0) || ((HEIGHT - cy == 0) || (HEIGHT - 1 - cy == 0)) ? CHSV(beat8(5), thisVal_, thisVal) : CHSV(0, 0, 0);
    }
  }
  blur2d(leds, WIDTH, HEIGHT, 16);
  //t+=1.3;
//  delay(16);
}
/////////////////////////////////// Plasm Ball

/////////////// Magma /////////////
#define enlargedOBJECT_MAX_COUNT WIDTH*2
#define SPEED_ADJ (float)NUM_LEDS/512

//speed control
#define m_speed 255 // 1-255 

//scale control
#define m_scale 255 //1-255

//control magma bursts
const byte deltaValue = 6U; // 2-12 
const byte deltaHue = 8U; // высота ¤зыков пламени должна уменьшатьс¤ не так быстро, как ширина
//static double fmap(const double x, const double in_min, const double in_max, const double out_min, const double out_max){ //defined higher

//функция возвращает рандомное значение float между min и max с шагом 1/1024
float randomf(float min, float max) {
  return fmap(random(1024), 0, 1023, min, max);
}

   float ff_y, ff_z;                         // большие счЄтчики
    uint8_t step, ObjectNUM = WIDTH; 
    uint8_t shiftHue[HEIGHT];
    float trackingObjectPosX[enlargedOBJECT_MAX_COUNT];
    float trackingObjectPosY[enlargedOBJECT_MAX_COUNT];
    uint8_t trackingObjectHue[enlargedOBJECT_MAX_COUNT];
    float trackingObjectSpeedX[enlargedOBJECT_MAX_COUNT];
    float trackingObjectShift[enlargedOBJECT_MAX_COUNT];
    float speedfactor;


void Magma_regen() {
  for (uint8_t j = 0; j < HEIGHT; j++) {
    shiftHue[j] = map(j, 0, HEIGHT+HEIGHT/4, 255, 0); // init colorfade table
  }

  for (uint8_t i = 0 ; i < enlargedOBJECT_MAX_COUNT ; i++) {
    LeapersRestart_leaper(i);  
    trackingObjectHue[i] = 50U;
  }
}

void LeapersMove_leaper(uint8_t l) {
#define GRAVITY            0.1
  trackingObjectShift[l] -= GRAVITY * speedfactor;

  trackingObjectPosX[l] += trackingObjectSpeedX[l] * speedfactor;
  trackingObjectPosY[l] += trackingObjectShift[l] * speedfactor;

  // bounce off the ceiling?
  if (trackingObjectPosY[l] > HEIGHT + HEIGHT/4) {
    trackingObjectShift[l] = -trackingObjectShift[l];
  }
  
  // settled on the floor?
  if (trackingObjectPosY[l] <= (HEIGHT/8-1)) {
    LeapersRestart_leaper(l);
  }

  // bounce off the sides of the screen?
  if (trackingObjectPosX[l] < 0 || trackingObjectPosX[l] > WIDTH-1) {
    LeapersRestart_leaper(l);
  }
}

void LeapersRestart_leaper(uint8_t l) {
  randomSeed(millis());
  // leap up and to the side with some random component
  trackingObjectSpeedX[l] = randomf(-0.75, 0.75);
  trackingObjectShift[l] = randomf(0.50, 0.85);
  trackingObjectPosX[l] = randomf(0, WIDTH);
  trackingObjectPosY[l] = randomf(0, (float)HEIGHT/4-1);

  // for variety, sometimes go 100% faster
  if (random8() < 12) {
    trackingObjectShift[l] += trackingObjectShift[l] * 2;
  }

}

void Magma() {

 if (loadingFlag) {
    speedfactor = fmap(m_speed, 1, 255, SPEED_ADJ*0.1, SPEED_ADJ);
    ObjectNUM = map(m_scale, 1, 255, WIDTH, enlargedOBJECT_MAX_COUNT);
    Magma_regen();   
    loadingFlag = false;
  }

  fadeToBlackBy(leds, NUM_LEDS, 50);

  for (uint8_t i = 0; i < ObjectNUM; i++) {
    LeapersMove_leaper(i);
    drawPixelXYF(trackingObjectPosX[i], trackingObjectPosY[i], ColorFromPalette(MagmaColor_p, trackingObjectHue[i], 255));
  }

  for (uint8_t i = 0; i < WIDTH; i++) {
    for (uint8_t j = 0; j < HEIGHT; j++) {
      leds[XY(i, HEIGHT-1 - j)] += ColorFromPalette(MagmaColor_p, qsub8(inoise8(i * deltaValue, (j + ff_y + random8(2)) * deltaHue, ff_z), shiftHue[j]), 255U);
    }
  }

  ff_y += speedfactor * 2;
  ff_z += speedfactor;
  //blur2d(leds, WIDTH, HEIGHT, 64);
}
////////////////////////////////// Magma


//////////// Wandering Souls /////

//--Settings------
#define w_Speed 255
#define w_Scale 8
#define Run 3 // 0-AllIn1Direction/1-beatsin/2-linear/3-circular
#define lamp 0
#define trace 1 //0-None/1-DimAll/2-Blur2D/3-wings(for Lamp)
#define reseting 10 //reset time in seconds, 0-off
#define subPixel 1 //
#define broad 0 //
//---------------
#define LIGHTERS_AM WIDTH + HEIGHT

struct{
int16_t PosX;
int16_t PosY;
uint16_t SpeedX;
uint16_t SpeedY;
byte SpeedZ;
byte Color;
byte Mass;
} lighterr[LIGHTERS_AM];

void WanderingSouls () {

 if (loadingFlag) {
    loadingFlag = false;
    randomSeed(millis());
    for (byte i = 0; i < LIGHTERS_AM; i++) {
      if (Run == 2) {
        lighterr[i].SpeedX = random(-10, 10);
        lighterr[i].SpeedY = random(-10, 10);
      } else if (Run == 3) {
        lighterr[i].SpeedX = random(-10, 10); //angle speed
        lighterr[i].SpeedY = random(0, 360); //angle
        lighterr[i].Mass = random(5, 10); //vspeed
      } else {
        lighterr[i].SpeedX = random(3, 25);
        lighterr[i].SpeedY = random(3, 25);
        lighterr[i].Mass = random(15, 100);
      }
      lighterr[i].SpeedZ = random(3, 25);
      lighterr[i].PosX = random(0, WIDTH * 10);
      lighterr[i].PosY = random(0, HEIGHT * 10);
      lighterr[i].Color = random(0, 9) * 28;
    }
  }
  switch (trace) {
    case 0:
      FastLED.clear();
      break;
    case 1:
      fadeToBlackBy(leds, NUM_LEDS, 50);
      break;
    case 3:
      fadeToBlackBy(leds, NUM_LEDS, 200);
      break;
  }
  
  for (byte i = 0; i < map(w_Scale, 1, 16, 2, LIGHTERS_AM); i++) {
    lighterr[i].Color++;
    switch (Run) {
      case 0:
        lighterr[i].PosX += beatsin8(lighterr[0].SpeedX * w_Speed, 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        lighterr[i].PosY += beatsin8(lighterr[0].SpeedY * w_Speed, 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        break;
      case 1:
        if (broad) {
          lighterr[i].PosX = beatsin16(lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1), 0, (WIDTH - 1) * 10);
          lighterr[i].PosY = beatsin16(lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1), 0, (HEIGHT - 1) * 10);
        } else {
          lighterr[i].PosX += beatsin16(lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1), 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
          lighterr[i].PosY += beatsin16(lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1), 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        }
        break;
      case 2:
        lighterr[i].PosX += lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].PosY += lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1);
        break;
      case 3:
        lighterr[i].PosX += lighterr[i].Mass * cos(radians(lighterr[i].SpeedY)) / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].PosY += lighterr[i].Mass * sin(radians(lighterr[i].SpeedY)) / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].SpeedY += lighterr[i].SpeedX / map(w_Speed, 1, 255, 20, 2);
        break;
    }
    if (broad) {
      if (Run == 3) {
        if (lighterr[i].PosY < 0) {
          lighterr[i].PosY = 1;
          lighterr[i].SpeedY = 360 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosX < 0) {
          lighterr[i].PosY = 1;
          lighterr[i].SpeedY = 180 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosY >= (HEIGHT - 1) * 10) {
          lighterr[i].PosY = ((HEIGHT - 1) * 10) - 1;
          lighterr[i].SpeedY = 360 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosX >= (WIDTH - 1) * 10) {
          lighterr[i].PosX = ((WIDTH - 1) * 10) - 1;
          lighterr[i].SpeedY = 180 - lighterr[i].SpeedY;
        }
      } else if (Run == 1) {} else {
        if ((lighterr[i].PosX <= 0) || (lighterr[i].PosX >= (WIDTH - 1) * 10)) lighterr[i].SpeedX = -lighterr[i].SpeedX;
        if ((lighterr[i].PosY <= 0) || (lighterr[i].PosY >= (HEIGHT - 1) * 10)) lighterr[i].SpeedY = -lighterr[i].SpeedY;
      }
    } else {
      if (lighterr[i].PosX < 0) lighterr[i].PosX = (WIDTH - 1) * 10;
      if (lighterr[i].PosX > (WIDTH - 1) * 10) lighterr[i].PosX = 0;
      if (lighterr[i].PosY < 0) lighterr[i].PosY = (HEIGHT - 1) * 10;
      if (lighterr[i].PosY > (HEIGHT - 1) * 10) lighterr[i].PosY = 0;
    }
    CRGB color = CHSV((lamp) ? 0 : lighterr[i].Color, 255, (trace == 3) ? 128 + random8(2) * 111 : beatsin8(lighterr[i].SpeedZ / map(w_Speed, 1, 255, 10, 1), 128, 255));
    if (subPixel)
      wu_pixel(lighterr[i].PosX * 25.6, lighterr[i].PosY * 25.6, &color);
    else
      leds[XY(lighterr[i].PosX / 10, lighterr[i].PosY / 10)] += color;
  }
  if(lamp){
  for(int i=0; i < NUM_LEDS; i++){
    leds[i]=CHSV(50,10,255-leds[i].r);
  }}
  if (reseting > 0) {
    EVERY_N_SECONDS(reseting) {
      randomSeed(millis());
      for (byte i = 0; i < map(w_Scale, 1, 16, 2, LIGHTERS_AM); i++) {
        if (Run == 2) {
          lighterr[i].SpeedX = random(-10, 10);
          lighterr[i].SpeedY = random(-10, 10);
        } else if (Run == 3) {
          lighterr[i].SpeedX = random(-10, 10);
          lighterr[i].SpeedY = random(0, 360);
          lighterr[i].Mass = random(5, 10);
        } else {
          lighterr[i].SpeedX = random(3, 25);
          lighterr[i].SpeedY = random(3, 25);
        }
        lighterr[i].SpeedZ = random(3, 25);
        lighterr[i].Mass + random(-25, 25);
      }
    }
  }
  if(trace == 2){
    blur2d(leds, WIDTH, HEIGHT, 64);
  } //  delay(16);
}
////////////////////////////////// Wandering Souls

///////////// Flower250 //////////
float c = 0.4;   //diameter  0.3 - for square
float angle = 0.1;
int  counter = 0;

void Flower250 () {

 if (loadingFlag) {
    loadingFlag = false;
    c = 0.4;
    angle = 0.1;
    counter = 0;
 }
 EVERY_N_MILLISECONDS(4000) {
    angle +=0.1;
  }

float n = triwave8( counter)*2.2; 
    float a = n * angle;
    float r = c * sqrt16(n);
    byte x = r * cos(a)+WIDTH/2;
    byte y = r * sin(a)+HEIGHT/2;
   leds [XY(x,y)] += CHSV (millis(),255,255);
        counter +=1; 
   fadeToBlackBy(leds, NUM_LEDS, 5); //20

}
////////////////////////////////// Flower250

///////// FlyingWithoutSin ///////

#define descr 1024.0 
float
  f_x0,
  f_k = 1.996, //2.0 * cos(2.0 * PI * 10.0 / descr),  //koeff
  f_x1 = 0,                                           //start value is 0 
  f_x2 = -0.06, //-1.0 * sin(2.0 * PI * 10.0 /descr); //second value from formula
  f_x01,
  f_k1 = 1.997, //2.0 * cos(2.0 * PI * 9.0 / descr),
  f_x11 = 0,
  f_x21 = -0.05; //-1.0 * sin(2.0 * PI * 9.0 / descr);

void FlyingWithoutSin () {

 if (loadingFlag) {
    loadingFlag = false;
/*    f_k = 1.996;
    f_x1 = 0; 
    f_x2 = -0.06;
    f_k1 = 1.997;
    f_x11 = 0;
    f_x21 = -0.05;*/
 }

EVERY_N_MILLISECONDS(30) {
    f_x0 = f_k * f_x1 - f_x2;        //calculate next sin value from prev 2 value
    f_x2 = f_x1;
    f_x1 = f_x0;
    
    f_x01 = f_k1 * f_x11 - f_x21;   //calculate next sin value from prev 2 value
    f_x21 = f_x11;
    f_x11 = f_x01;
    
    byte x255 = f_x0 * WIDTH/2 + WIDTH/2;  //-1..1 => 0 to matrix size
    byte y255 = f_x01 * HEIGHT/2 + HEIGHT/2; //-1..1 => 0 to matrix size
      
    leds[XY(x255, y255)] += CHSV(millis() / 40, 255, 255);
    blur2d(leds, WIDTH,HEIGHT, 16);
 } 
}
////////////////////////////////// FlyingWithoutSin


/////// Lost Lands //////////////

void LostLands () {

uint16_t t = millis() / 10;
  for(uint8_t x = 0; x < WIDTH; x++){
    for(uint8_t y = 0; y < HEIGHT; y++){
      leds[XY(x, y)] = ColorFromPalette(CloudColors_p, inoise8((x * 100), (y * 10) - t, t / 2), 255 - (abs(x - WIDTH / 2) * (255 / WIDTH * 2))) - CHSV(0, 0, inoise8(x * 50, y * 50, t));
    }
  }
}
///////////////////////////////// Lost Lands

/////////////// Prismata ///////// same vars: Source
// палитра для типа реалистичного водопада (если ползунок Масштаб выставить на 100)
//extern const TProgmemRGBPalette16 WaterfallColors_p FL_PROGMEM = {0x000000, 0x060707, 0x101110, 0x151717, 0x1C1D22, 0x242A28, 0x363B3A, 0x313634, 0x505552, 0x6B6C70, 0x98A4A1, 0xC1C2C1, 0xCACECF, 0xCDDEDD, 0xDEDFE0, 0xB2BAB9};

// добавлено изменение текущей палитры (используется во многих эффектах ниже для бегунка Масштаб)
const TProgmemRGBPalette16 *palette_arr[] = {
    &PartyColors_p,
    &RainbowColors_p}; 
TProgmemRGBPalette16 *curPalette;// = palette_arr[0];

//void setCurrentPalette(){
//      if (modes[0].Scale > 100U) modes[0].Scale = 100U; // чтобы не было проблем при прошивке без очистки памяти
//      curPalette = palette_arr[(uint8_t)(modes[0].Scale/100.0F*((sizeof(palette_arr)/sizeof(TProgmemRGBPalette16 *))-0.01F))];
//}

// стандартные функции библиотеки LEDraw от @Palpalych (для адаптаций его эффектов)
void blurScreen(fract8 blur_amount, CRGB *LEDarray = leds) { blur2d(LEDarray, WIDTH, HEIGHT, blur_amount); }

void dimAll(uint8_t value, CRGB *LEDarray = leds) { nscale8(LEDarray, NUM_LEDS, value); }

uint8_t myScale8(uint8_t x) { // даёт масштабировать каждые 8 градаций (от 0 до 7) бегунка Масштаб в значения от 0 до 255 по типа синусоиде
  uint8_t x8 = x % 8U;
  uint8_t x4 = x8 % 4U;
  if (x4 == 0U)
    if (x8 == 0U)       return 0U;
    else                return 255U;
  else if (x8 < 4U)     return (1U   + x4 * 72U); // всего 7шт по 36U + 3U лишних = 255U (чтобы восхождение по синусоиде не было зеркально спуску)
//else
                        return (253U - x4 * 72U); // 253U = 255U - 2U
}

void Prismata () {
  
   if (loadingFlag)  {
    loadingFlag = false;
    brightness = 255U; // not used here
    speed = 30U;       // 1-255
    scale = 8;         // 1-100 is palette
    //setCurrentPalette();
    curPalette = palette_arr[(uint8_t)random(2)];
  } 
  hue++; // используем переменную сдвига оттенка из функций радуги, чтобы не занимать память
  blurScreen(20); // @Palpalych посоветовал делать размытие
  dimAll(255U - (scale - 1U) % 11U * 3U);

  for (uint8_t x = 0; x < WIDTH; x++)
  {
    uint8_t beat = (GET_MILLIS() * (accum88(x + 1)) * 28 * speed) >> 17;
    uint8_t y = scale8(sin8(beat), HEIGHT-1);
    //drawPixelXY(x, y, ColorFromPalette(*curPalette, x * 7 + hue));
    leds[XY(x,y)] = ColorFromPalette(*curPalette, x * 7 + hue);
  }
}
////////////////////////////////// Prismata

////////// SinShort /////////////
#define a (256 / WIDTH)

void SinShort() {
  double t = (float)millis()/4; //10
  for (byte i = 0; i < HEIGHT; i++) {
    uint16_t shift = (i * 16); float sin1 = (1+sin(radians(t + shift)))*128; byte bright =  112*(1+sin(radians(t + shift + 90)))+30; byte bright2 =  112*(1+sin(radians(t + shift + 270)))+30;
    drawPixelXYF_X(sin1 /a, i, CHSV(sin1, 255, bright));
    drawPixelXYF_X((WIDTH-1)-(sin1 / a), i, CHSV(~(byte)sin1, 255, bright2));
  }
  fadeToBlackBy(leds, NUM_LEDS, 64);
}
///////////////////////////////// SinShort

////////// Fire234 /////////////

//int f_BRIGHTNESS = 255;
int scalexy = 60; // scale of fire
int i_speed = 20; //speed of effect 

DEFINE_GRADIENT_PALETTE(ffirepal) { // define fire palette
  0,  0,  0,  0, //black
  32,  255,  0,  0, // red
  190,  255,  255,  0, //yellow
  255,  255,  255,  255 // white
};

void Fire234 () {

 CRGBPalette16 myPal = ffirepal;
  
 uint16_t atm = millis();
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      leds[XY((WIDTH - 1) - i, (HEIGHT - 1) - j)] = ColorFromPalette(myPal, qsub8(inoise8(i * scalexy, j * scalexy + atm, atm / i_speed), abs8(j - (HEIGHT - 1)) * 255 / (HEIGHT - 1)), 255); //255 - BRIGHTNESS
    }
  }

}
//////////////////////////////// Fire234


///////////// Nexus Routine ///////////
#define NEXUS (WIDTH)
#define BACKGROUND 0 //0 - черный, 1 - синий фон
#define N_SPEED 70 //uint8_t n_speed = 70; // скорость эффекта //50
#define N_SCALE 200 //uint8_t n_scale = 200; // количество капель

//fmap, drawPixelXYF_X, drawPixelXYF_Y defined in extrasubs

class EffectNexus {
  private:
    float dotPosX[NEXUS];
    float dotPosY[NEXUS];
    int8_t dotDirect[NEXUS];       // направление точки 
    CRGB dotColor[NEXUS];          // цвет точки
    float dotAccel[NEXUS];         // персональное ускорение каждой точки
    bool white = false;
    byte type = 1;
    bool randColor = false;
    float windProgress;
    

    void reload();
    void resetDot(uint8_t idx);

  public:
    bool run();
    void load();
};

///////////////////// Nexus //////////////
void EffectNexus::reload() {
  for (byte i = 0; i < NEXUS; i++) {
    dotDirect[i] = random(0, 4);                     // задаем направление
    dotPosX[i] = random(0, WIDTH);                   // Разбрасываем частицы по ширине
    dotPosY[i] = random(0, HEIGHT);                  // и по высоте
    dotColor[i] = ColorFromPalette(RainbowColors_p, random8(0, 9) * 31, 255); // цвет капли
    dotAccel[i] = (float)random(5, 11) / 70;        // делаем частицам немного разное ускорение 
  }
}

void EffectNexus::load() {
  randomSeed(millis());
  reload();
}

bool EffectNexus::run() {
  float speedfactor = fmap(N_SPEED, 1, 255, 0.1, .33);

  fadeToBlackBy(leds, NUM_LEDS, map(N_SPEED, 1, 255, 11, 100)); //33, для south ярковато

  for (byte i = 0; i < map(N_SCALE, 1, 255, 4, NEXUS); i++) {
    switch (dotDirect[i])
    {
    case 0:   // вверх
      dotPosY[i] += (speedfactor + dotAccel[i]);
      break;
    case 1:   //  вниз 
      dotPosY[i] -= (speedfactor + dotAccel[i]);
      break;
    case 2:   // вправо
      dotPosX[i] += (speedfactor + dotAccel[i]);
      break;
    case 3:   // влево
      dotPosX[i] -= (speedfactor + dotAccel[i]);
      break;
    default:
      break;
    } 

    // Обеспечиваем бесшовность по Y. И переносим каплю в начало трека
    if (dotPosY[i] < 0) {
      dotPosY[i] = (float)HEIGHT - 1.;    
      resetDot(i);
    }

    if (dotPosY[i] > (HEIGHT - 1)) {
      dotPosY[i] = 0;
      resetDot(i);
    }

    // Обеспечиваем бесшовность по X.
    if (dotPosX[i] < 0) {
      dotPosX[i] = (WIDTH - 1);
      resetDot(i);
    }
    if (dotPosX[i] > (WIDTH - 1)) {
      dotPosX[i] = 0;
      resetDot(i);
    }

  switch (dotDirect[i])
  {
  case 0:   // вверх
  case 1:   //  вниз 
    drawPixelXYF_Y(dotPosX[i], dotPosY[i], dotColor[i]);
    break;
  case 2:   // вправо
  case 3:   // влево
    drawPixelXYF_X(dotPosX[i], dotPosY[i], dotColor[i]);
    break;
  default:
    break;
  } 
  }
  return true;
}

void EffectNexus::resetDot(uint8_t idx) {
  randomSeed(micros());
  dotDirect[idx] = random8(0, 4);                     // задаем направление
  dotColor[idx] = ColorFromPalette(RainbowColors_p, random(0, 9) * 31, 255);              // цвет 
  dotAccel[idx] = (float)random(5, 10) / 70;     // делаем частицам немного разное ускорение 
  switch (dotDirect[idx])
  {
  case 0:   // вверх
    dotPosX[idx] = random8(0, WIDTH); // Разбрасываем капли по ширине
    dotPosY[idx] = 0;  // и по высоте
    break;
  case 1:   //  вниз 
    dotPosX[idx] = random8(0, WIDTH); // Разбрасываем капли по ширине
    dotPosY[idx] = HEIGHT-1;  // и по высоте
    break;
  case 2:   // вправо
    dotPosX[idx] = 0; // Разбрасываем капли по ширине
    dotPosY[idx] = random8(0, HEIGHT);  // и по высоте
    break;
  case 3:   // влево
    dotPosX[idx] = WIDTH-1; // Разбрасываем капли по ширине
    dotPosY[idx] = random8(0, HEIGHT);  // и по высоте
    break;
  default:
    break;
  } 
}

EffectNexus effnex;

void NexusRoutine () {

  if (loadingFlag) effnex.load(), loadingFlag = false;
  if (BACKGROUND)
    for (uint16_t i =0; i< NUM_LEDS; i++) leds[i] += CRGB(0, 2, 6);
  effnex.run();
//  delay(16); // ~= 60FPS
}
/////////////////////////////// Nexus

///////// Gyroscope ///////////
#define g_am 6
float angle_a[g_am];
float angle_b[g_am];

void Gyroscope() {

//  static byte g_hue;
  if (loadingFlag) {
    for (byte i = 0; i < g_am; i++) {
      angle_a[i] = radians(random());
      angle_b[i] = radians(random());
    }
    loadingFlag = false;
    hue=0;
  }
//  g_hue++;
  for (byte i = 1; i < g_am+1; i++) {
    angle_a[i-1] = fmod(angle_a[i-1] + (beatsin8(3, 0, 50, 0, 4 * i)-25)/100.f,6.28318531);
    angle_b[i-1] = fmod(angle_b[i-1] + (beatsin8(3, 0, 50, 0, (8 * i)+64)-25)/100.f,6.28318531);
    float radA1= angle_a[i-1]+3.14159265;
    //float radB1= angle_b[i-1]+3.14159265;

    float x = (1+sin(angle_a[i-1]) * cos(angle_b[i-1])) * WIDTH/2;
    float y = (1+sin(angle_a[i-1]) * sin(angle_b[i-1])) * HEIGHT/2;
    float z = cos(angle_a[i-1]);
    
    float x1 = WIDTH-1-x;//(1+sin(radA1) * cos(radB1)) * WIDTH/2;
    float y1 = HEIGHT-1-y;//(1+sin(radA1) * sin(radB1)) * HEIGHT/2;
    float z1 = cos(radA1);
    
    drawLineF(x,y,x1,y1, CHSV(127 + (i * 32) + hue, 255, constrain(112 * (1 + z) + 30, 96, 255)), CHSV(i * 32 + hue, 255, constrain(112 * (1 + z1) + 30, 96, 255)));
  }
  fadeToBlackBy(leds, NUM_LEDS, 64);
}
/////////////////////////////// Gyroscope


////////////////// Stars ///////
#define trackingOBJECT_MAX_COUNT WIDTH*2  // максимальное количество отслеживаемых объектов (очень вли¤ет на расход пам¤ти). Тестил - хватает и 24 вполне; (100U) ; используется еще в source

//константы размера матрицы вычисл¤етс¤ только здесь и не мен¤етс¤ в эффектах
const uint8_t CENTER_X_MINOR =  (WIDTH / 2) -  ((WIDTH - 1) & 0x01); // центр матрицы по » —”, сдвинутый в меньшую сторону, если ширина чЄтна¤
const uint8_t CENTER_Y_MINOR = (HEIGHT / 2) - ((HEIGHT - 1) & 0x01); // центр матрицы по »v–? ”, сдвинутый в меньшую сторону, если высота чЄтна¤

#define bballsMaxNUM trackingOBJECT_MAX_COUNT
#define spirocenterX CENTER_X_MINOR
#define spirocenterY CENTER_Y_MINOR
#define STAR_BLENDER 128U             // хз что это 
#define CENTER_DRIFT_SPEED 6U         // скорость перемещени¤ плавающего центра возникновени¤ звЄзд
unsigned int  s_counter;//, ringdelay;//, bringdelay, sumthum;
int16_t radius2;//, fpeed[WIDTH * 3], fcount[WIDTH * 3], fcountr[WIDTH * 3];//, xxx, yyy, dot = 3, rr, gg, bb, adjunct = 3;
float driftx, drifty;//, locusx, locusy, xcen, ycen, yangle, xangle;
float cangle, sangle;//xfire[WIDTH * 3], yfire[WIDTH * 3], radius, xslope[MATRIX_WIDTH * 3], yslope[MATRIX_WIDTH * 3]; 

void drawstar(int16_t xlocl, int16_t ylocl, int16_t biggy, int16_t little, int16_t points, int16_t dangle, uint8_t koler) {// random multipoint star
  radius2 = 255 / points;
  for (int i = 0; i < points; i++)  {
    mydrawLine(xlocl + ((little * (sin8(i * radius2 + radius2 / 2 - dangle) - 128.0)) / 128), ylocl + ((little * (cos8(i * radius2 + radius2 / 2 - dangle) - 128.0)) / 128), xlocl + ((biggy * (sin8(i * radius2 - dangle) - 128.0)) / 128), ylocl + ((biggy * (cos8(i * radius2 - dangle) - 128.0)) / 128), CHSV(koler , 255, 255),0,0);
    mydrawLine(xlocl + ((little * (sin8(i * radius2 - radius2 / 2 - dangle) - 128.0)) / 128), ylocl + ((little * (cos8(i * radius2 - radius2 / 2 - dangle) - 128.0)) / 128), xlocl + ((biggy * (sin8(i * radius2 - dangle) - 128.0)) / 128), ylocl + ((biggy * (cos8(i * radius2 - dangle) - 128.0)) / 128), CHSV(koler , 255, 255),0,0);
    }
}

uint8_t bballsCOLOR[bballsMaxNUM] ;                   // цвет звезды (используем повторно массив эффекта ћ¤чики)
uint8_t bballsX[bballsMaxNUM] ;                       // количество углов в звезде (используем повторно массив эффекта ћ¤чики)
int   bballsPos[bballsMaxNUM] ;                       // задержка пуска звезды относительно счЄтчика (используем повторно массив эффекта ћ¤чики)
uint8_t bballsNUM;                                    // количество звЄзд (используем повторно переменную эффекта ћ¤чики)

void Stars() {

  dimAll(89U);

  if (loadingFlag) {
    loadingFlag = false;
//    setCurrentPalette();
    driftx = random8(4, WIDTH - 4);//set an initial location for the animation center
    drifty = random8(4, HEIGHT - 4);// set an initial location for the animation center
    
    cangle = (sin8(random(25, 220)) - 128.0) / 128.0;//angle of movement for the center of animation gives a float value between -1 and 1
    sangle = (sin8(random(25, 220)) - 128.0) / 128.0;//angle of movement for the center of animation in the y direction gives a float value between -1 and 1
    //shifty = random (3, 12);//how often the drifter moves будет CENTER_DRIFT_SPEED = 6

    //pointy = 7; теперь количество углов у каждой звезды своЄ
    bballsNUM = (WIDTH + 6U) / 2U;//(modes[0].Scale - 1U) / 99.0 * (bballsMaxNUM - 1U) + 1U;
    if (bballsNUM > bballsMaxNUM) bballsNUM = bballsMaxNUM;
    for (uint8_t num = 0; num < bballsNUM; num++) {
      bballsX[num] = random8(3, 9);//pointy = random8(3, 9); // количество углов в звезде
      bballsPos[num] = s_counter + (num << 2) + 1U;//random8(50);//modes[0].Scale;//random8(50, 99); // задержка следующего пуска звезды
      bballsCOLOR[num] = random8();
    }
  }
  s_counter++;
  if (driftx > (WIDTH - spirocenterX / 2U))//change directin of drift if you get near the right 1/4 of the screen
    cangle = 0 - fabs(cangle);
  if (driftx < spirocenterX / 2U)//change directin of drift if you get near the right 1/4 of the screen
    cangle = fabs(cangle);
  if (s_counter % CENTER_DRIFT_SPEED == 0)
    driftx = driftx + cangle;//move the x center every so often

  if (drifty > ( HEIGHT - spirocenterY / 2U))// if y gets too big, reverse
    sangle = 0 - fabs(sangle);
  if (drifty < spirocenterY / 2U) // if y gets too small reverse
    sangle = fabs(sangle);
  if ((s_counter + CENTER_DRIFT_SPEED / 2U) % CENTER_DRIFT_SPEED == 0)
    drifty =  drifty + sangle;//move the y center every so often
  
  for (uint8_t num = 0; num < bballsNUM; num++) {
    if (s_counter >= bballsPos[num])//(s_counter >= ringdelay)
    {
      if (s_counter - bballsPos[num] <= WIDTH + 5U) {  //(s_counter - ringdelay <= WIDTH + 5){
        //drawstar(driftx  , drifty, 2 * (s_counter - ringdelay), (s_counter - ringdelay), pointy, blender + h, h * 2 + 85);
        drawstar(driftx  , drifty, 2 * (s_counter - bballsPos[num]), (s_counter - bballsPos[num]), bballsX[num], STAR_BLENDER + bballsCOLOR[num], bballsCOLOR[num] * 2);//, h * 2 + 85);// что, бл, за 85?!
        bballsCOLOR[num]++;
      }
      else
        //bballsX[num] = random8(3, 9);//pointy = random8(3, 9); // количество углов в звезде
        bballsPos[num] = s_counter + (bballsNUM << 1) + 1U;//random8(50, 99);//modes[0].Scale;//random8(50, 99); // задержка следующего пуска звезды
    }
  }
  //delay(30);
}
//////////////////////////////// Stars

//////// Ex7Sparkles /////////////////
void Ex7Sparkles() {

//   if (loadingFlag) {  loadingFlag = false;  hue = 0;}	
    
  // 6 beats per minute, between 1 and 10
  int numberOfSparkles = beatsin16(6, 1, 10);

  EVERY_N_MILLISECONDS(20) {
    for (int i = 0; i < numberOfSparkles; i++) {
      int pos = random16(NUM_LEDS);

      if (!leds[pos]) {
        leds[pos] = CHSV(hue + (pos / 10), 255, 255);
      }
    }
  }
  EVERY_N_MILLISECONDS(50) {
    hue -= 1;
  }
  fade_raw(leds, NUM_LEDS, 100);
 //   delay(40);
}
////////////////////////////////////// Ex7Sparkles

////////////// Pride ///////////////
void Pride() {

static uint16_t sPseudotime = 0;
  static uint16_t sLastMillis = 0;
  static uint16_t sHue16 = 0;

  uint8_t sat8 = beatsin88( 87, 220, 250);
  uint8_t brightdepth = beatsin88( 341, 96, 224);
  uint16_t brightnessthetainc16 = beatsin88( 203, (25 * 256), (40 * 256));
  uint8_t msmultiplier = beatsin88(147, 23, 60);

  uint16_t hue16 = sHue16;//gHue * 256;
  uint16_t hueinc16 = beatsin88(113, 1, 3000);

  uint16_t ms = millis();
  uint16_t deltams = ms - sLastMillis ;
  sLastMillis  = ms;
  sPseudotime += deltams * msmultiplier;
  sHue16 += deltams * beatsin88( 400, 5, 9);
  uint16_t brightnesstheta16 = sPseudotime;

  for ( uint16_t i = 0 ; i < NUM_LEDS; i++) {
    hue16 += hueinc16;
    uint8_t hue8 = hue16 / 256;

    brightnesstheta16  += brightnessthetainc16;
    uint16_t b16 = sin16( brightnesstheta16  ) + 32768;

    uint16_t bri16 = (uint32_t)((uint32_t)b16 * (uint32_t)b16) / 65536;
    uint8_t bri8 = (uint32_t)(((uint32_t)bri16) * brightdepth) / 65536;
    bri8 += (255 - brightdepth);

    CRGB newcolor = CHSV( hue8, sat8, bri8);

    uint16_t pixelnumber = i;
    pixelnumber = (NUM_LEDS - 1) - pixelnumber;

    nblend( leds[pixelnumber], newcolor, 64);
  }
}
//////////////////////////////////// Pride

///////////////// Source /////////// same variables: Prismata, Magma, Stars
//// точки из центра
//// сильно завязано на переменные Magma

uint8_t hue2;                                 // постепенный сдвиг оттенка или какой-нибудь другой цикличный счЄтчик
uint8_t sstep;                                      // какой-нибудь счЄтчик кадров или последовательностей операций
uint8_t sdeltaValue;                                // просто повторно используема¤ переменна¤

//#define trackingOBJECT_MAX_COUNT                         (100U)  // максимальное количество отслеживаемых объектов (очень вли¤ет на расход пам¤ти) //defined in Magma enlargedOBJECT_MAX_COUNT = WIDTH*2
float   trackingObjectSpeedY[enlargedOBJECT_MAX_COUNT];
uint8_t trackingObjectState[enlargedOBJECT_MAX_COUNT];
bool    trackingObjectIsShift[enlargedOBJECT_MAX_COUNT];
#define enlargedOBJECT_MAX_COUNT                     WIDTH*2-2 // максимальное количество сложных отслеживаемых объектов (меньше, чем trackingOBJECT_MAX_COUNT)
uint8_t enlargedObjectNUM;                                       // используемое в эффекте количество объектов

//константы размера матрицы вычисл¤етс¤ только здесь и не мен¤етс¤ в эффектах
const uint8_t CENTER_X_MAJOR =   WIDTH / 2  + (WIDTH % 2);           // центр матрицы по » —”, сдвинутый в большую сторону, если ширина чЄтна¤
const uint8_t CENTER_Y_MAJOR =  HEIGHT / 2  + (HEIGHT % 2);          // центр матрицы по »v–? ”, сдвинутый в большую сторону, если высота чЄтна¤

void particlesUpdate2(uint8_t i){
 
  trackingObjectState[i]--; //ttl // ещЄ и сюда надо speedfactor вкор¤чить. удачи там!

  //apply velocity
  trackingObjectPosX[i] += trackingObjectSpeedX[i];
  trackingObjectPosY[i] += trackingObjectSpeedY[i];
  if(trackingObjectState[i] == 0 || trackingObjectPosX[i] <= -1 || trackingObjectPosX[i] >= WIDTH || trackingObjectPosY[i] <= -1 || trackingObjectPosY[i] >= HEIGHT) 
    trackingObjectIsShift[i] = false;
}

void starfield2Emit(uint8_t i) {
  if (hue++ & 0x01) hue2++;//counter++;
  trackingObjectPosX[i] = WIDTH * 0.5;//CENTER_X_MINOR;// * RENDERER_RESOLUTION; //  particle->x = source->x;
  trackingObjectPosY[i] = HEIGHT * 0.5;//CENTER_Y_MINOR;// * RENDERER_RESOLUTION; //  // particle->y = source->y;

  trackingObjectSpeedX[i] = ((float)random8()-127.)/512.; // random(_hVar)-_constVel; // particle->vx
  trackingObjectSpeedY[i] = sqrt(0.0626-trackingObjectSpeedX[i]*trackingObjectSpeedX[i]); // sqrt(pow(_constVel,2)-pow(trackingObjectSpeedX[i],2)); // particle->vy зависит от particle->vx - не ошибка
  if(random8(2U)) { trackingObjectSpeedY[i]=-trackingObjectSpeedY[i]; }
  trackingObjectState[i] = random8(1, 255); // random8(minLife, maxLife);// particle->ttl
  if (speed & 0x01)
    trackingObjectHue[i] = hue2;// (counter/2)%255; // particle->hue
  else
    trackingObjectHue[i] = random8();
  trackingObjectIsShift[i] = true; // particle->isAlive
}

// неточный, зато более быстрый квадратный корень
float sqrt3(const float x){
  union {
    int i;
    float x;
  } u;
  u.x = x;
  u.i = (1<<29) + (u.i >> 1) - (1<<22);
  return u.x;
}

void Source() {

// CRGBPalette16 Cur_pal;

if (loadingFlag) {
  loadingFlag = false;
  palette=random(countpal);
  scale=100;
  speed=255;
  enlargedObjectNUM = (scale - 1U) / 99.0 * (enlargedOBJECT_MAX_COUNT - 1U) + 1U;
  if (enlargedObjectNUM > enlargedOBJECT_MAX_COUNT) enlargedObjectNUM = enlargedOBJECT_MAX_COUNT;
  sdeltaValue = enlargedObjectNUM / (sqrt3(CENTER_X_MAJOR*CENTER_X_MAJOR + CENTER_Y_MAJOR*CENTER_Y_MAJOR) * 4U) + 1U; // 4 - это потому что за 1 цикл частица пролетает ровно четверть рассто¤ни¤ между 2м¤ соседними пиксел¤ми
  for(int i = 0; i<enlargedObjectNUM; i++)
    trackingObjectIsShift[i] = false; // particle->isAlive
}
  
  sstep = sdeltaValue; //счЄтчик количества частиц в очереди на зарождение в этом цикле
  dimAll(127);

  //go over particles and update matrix cells on the way
  for(int i = 0; i<enlargedObjectNUM; i++) {
    if (!trackingObjectIsShift[i] && sstep) {
      starfield2Emit(i);
      sstep--;
    }
    if (trackingObjectIsShift[i]){ // particle->isAlive
      particlesUpdate2(i);

      //generate RGB values for particle
//      CRGB baseRGB = ColorFromPalette(RainbowColors_p, trackingObjectHue[i],255); // particles[i].hue RainbowColors_p
      CRGB baseRGB = ColorFromPalette(*pal_arr[palette], trackingObjectHue[i],255); //pal - array of palletes higher
      baseRGB.nscale8(trackingObjectState[i]);//эквивалент
      drawPixelXYF(trackingObjectPosX[i], trackingObjectPosY[i], baseRGB);
    }
  }
  EVERY_N_MILLISECONDS (5000) {
    palette++;
    if (palette>=countpal) palette=0;
  }  
}
//////////////////////////////////// Source

///////////GifAnim ////
CRGB Crgb565(uint16_t ag) {
  CRGB col;
  col.r = (byte) ((ag & 0xF800)>>8); // mask out 5 bits of red at the start of the word, shift it right not for 11 but 9 to make it brighter.
  col.g = (byte) ((ag & 0x07E0)>>3); // mask out 6 bits of blue in the middle of the word, shift it right and take a byte
  col.b = (byte) ((ag & 0x001F)<<2); // mask out 5 bits of green in the end of the word and take a byte
  return col;
}

void GifAnim(const uint_farptr_t arr1) {

  if (loadingFlag) {loadingFlag = false;}	

  static byte frame = 0;
  uint16_t  sprite_ptr;
  CRGB col;

  byte frameWidth =  (byte) pgm_read_word_far(arr1 + 0*sizeof(uint16_t));
  byte frameHeight = (byte) pgm_read_word_far(arr1 + 1*sizeof(uint16_t));
  byte frames =      (byte) pgm_read_word_far(arr1 + 2*sizeof(uint16_t));

  sprite_ptr = 3 + frameWidth * frameHeight * frame;

  for (byte y = 0; y < frameHeight; y++) {
    for (byte x = 0; x < frameWidth; x++) {
      col = Crgb565(pgm_read_word_far (arr1 + sprite_ptr++*sizeof(uint16_t)));
      leds[XY(x, HEIGHT-1-y)] = col;
    }
  }
  
  frame++;
  if (frame >= frames) frame = 0;

//nscale8(leds, NUM_LEDS, 200); //100
//  delay(100);
}

///////////GifAnim2424////

 void GifAnim2424(const uint_farptr_t arr1, const uint_farptr_t arr2, bool move) {

  if (loadingFlag) {loadingFlag = false;}

  uint16_t  sprite_ptr;
  CRGB col;
  static byte frame = 0;
  static int8_t lines = 0;
  static int8_t direction = 1;

  byte frameWidth =  (byte) pgm_read_word_far(arr1 + 0*sizeof(uint16_t));
  byte frameHeight = (byte) pgm_read_word_far(arr1 + 1*sizeof(uint16_t));
  byte frames =      (byte) pgm_read_word_far(arr1 + 2*sizeof(uint16_t));

  if(frame<=19) sprite_ptr = (3 + frameWidth * frameHeight * frame + frameWidth*2 + frameWidth*lines*move); //skip two first lines, it has strange data
  if(frame>19) sprite_ptr = (3 + frameWidth * frameHeight * (frame-20) + frameWidth*2 + frameWidth*lines*move);//skip two first lines, it has strange data
  
  for (byte y = 0; y < HEIGHT; y++) {
    for (byte x = 0; x < WIDTH; x++) {
     if (frame<=19) { col = Crgb565(pgm_read_word_far (arr1 + sprite_ptr++*sizeof(uint16_t))); }
     if (frame>19)  { col = Crgb565(pgm_read_word_far (arr2 + sprite_ptr++*sizeof(uint16_t))); }
        leds[XY(x, HEIGHT-1-y)] = col;
    }
    if (frame<=19) sprite_ptr = (3 + frameWidth * frameHeight * frame + frameWidth*2 + frameWidth*lines*move + y*frameWidth); //skip two first lines, it has strange data
    if (frame>19) sprite_ptr = (3 + frameWidth * frameHeight * (frame-20) + frameWidth*2 + frameWidth*lines*move + y*frameWidth);//skip two first lines, it has strange data
  }
  
  frame++;
  if (frame >= frames) frame = 0;

EVERY_N_MILLISECONDS(200) {
  lines+=direction;
  if (lines == HEIGHT-2) direction = -1; //skip two first lines, it has strange data
  if (lines == 2) direction = 1;//skip two first lines, it has strange data
}

//nscale8(leds, NUM_LEDS, 200); //100
//  delay(100);
}
/////////////////////////////////////// GifAnim2424


////////////// Sin Dots ///////////
void SinDots () {
//  if (loadingFlag) {loadingFlag = false;}
  fadeToBlackBy(leds, NUM_LEDS, 15);
//  byte t1 = millis() / 20; //speed
//  byte t2 = sin8(t1)/2;   //scale

  speed = millis()/20; //t1
  scale = sin8(speed)/2;   //t2

  for (byte i = 0; i < 13; i++) {
    byte x = sin8(speed + i * 20)*HEIGHT/255; 
    byte y = sin8(scale + i * 20)*WIDTH/255;   
    x= x>=HEIGHT? (HEIGHT-1):x;
    y= y>=WIDTH? (WIDTH-1):y;
    leds[XY(y, x)] = CHSV(i * 255 / 13, 255, 255); //y,x!!! это потому что перепутаны HEIGHT и WIDTH
  }
  blur2d(leds, HEIGHT, WIDTH, 16);
}
/////////////////////////////////// Sin Dots

///////////// SinPlasma //////////////////////
void SinPlasma () {
//   if (loadingFlag) {  loadingFlag = false;}	
   float t=millis()/250.0;
for (byte i = 0; i < HEIGHT; i++) { 
    for (byte j = 0; j < WIDTH; j++) {
        byte ind = sin8(i*8+sin8(i*2+6*t))/2+sin8(j*8+sin8(j*2+t*7)/2);
        leds [XY(j,i)] = CHSV (ind,255,255); //j,i!!! здесь хз, перепутано в оригинале было.
     }
}}
////////////////////////////////////////////// SinPlasma - ползущие пятна

///////////// Radar //////////////////////
float eff_theta;
float eff_offset;
//byte r_hue; 
const byte width_adj = (WIDTH < HEIGHT ? (HEIGHT - WIDTH) /2 : 0);
const byte height_adj = (HEIGHT < WIDTH ? (WIDTH - HEIGHT) /2: 0);

uint8_t mapsincos8(bool map, uint8_t theta, uint8_t lowest, uint8_t highest) {
  uint8_t beat = map ? sin8(theta) : cos8(theta);
  return lowest + scale8(beat, highest - lowest);
}

uint16_t mapsincos16(bool map, uint16_t theta, uint16_t lowest, uint16_t highest) {
  uint8_t beat = map ? sin16(theta) : cos16(theta);
  return lowest + scale16(beat, highest - lowest);
}

void radarRoutine() {
    
//    if (loadingFlag) {  loadingFlag = false;}	

    fadeToBlackBy(leds, NUM_LEDS, 5 + 20 * 85 / 255); //85-speed
    for (float offset = 0.0f; offset < (float)maxDim /2; offset +=0.25) {
      float x = (float)mapsincos8(false, eff_theta, offset * 4, maxDim * 4 - offset * 4) / 4.  - width_adj;
      float y = (float)mapsincos8(true, eff_theta, offset * 4, maxDim * 4 - offset * 4) / 4.  - height_adj;
      CRGB color = ColorFromPalette(RainbowColors_p, hue, 255 / random8(1, 12));
      drawPixelXYF(x, y, color);
    }
  EVERY_N_MILLIS(16) {
    eff_theta += 5.5 * (85 / 255.0) + 1; //85 - speed
    eff_offset += 3.5 * ((255 - 85) / 255.0) + 1; //85 - speed
    hue = millis() / 16;// eff_offset;
  }
}
////////////////////////////////////////////// Radar

///////////// Fontain //////////////////////
#define ANGLE_UP (M_PI / 2.0f)		            //Straight up (90deg)
#define FOUNTAIN_WIDTH (M_PI / 10.0f)         //Fountain width in radians (pi/12 is 15../deg)
#define NUM_PARTICLES 25                      //Max number of particles drawn //40
 
// My RandomFloat Function
float RandomNumber(float Min, float Max) { return (Min + (float(rand()) / float(RAND_MAX)) * (Max - Min)); }

class Particle{
private:
  float gravity = 0.08f; //0.07 на 16*16 норм, на 24*12 нужно посильней гравитацию
	float angle;
	float init_v;
public:
	uint8_t lifetime;
	float x, y;
	float xv, yv;
	bool active = false;
	uint8_t colorIndex;
	CRGB color;

	void Init(int posx, int posy) //this init is for fountain
	{
		x = posx;
		y = posy;
    angle = RandomNumber(ANGLE_UP - FOUNTAIN_WIDTH / 2.0f, ANGLE_UP + FOUNTAIN_WIDTH / 2.0f);
		init_v = RandomNumber(1.0f, 2.0f);
		yv = sin(angle) * init_v;
		xv = cos(angle) * init_v;
		colorIndex = rand();
    lifetime = rand();
    color = ColorFromPalette(*pal_arr[palette],colorIndex,lifetime,LINEARBLEND); //fountainPalette
  
		active = true;
	}

/*void Init2(int posx, int posy) {   //this init is for flame // чето не вызывается.
		gravity = 0;
    x = posx+(RandomNumber(-1.0f,1.0f));
		y = posy;
    yv = RandomNumber(0.3f,1.2f);
    xv = RandomNumber(-0.2f,0.2f);
    if(random8()>250) {             // Random Sparks
      yv = RandomNumber(1.2f,2.0f);
      xv = RandomNumber(-0.5f,0.5f);
      gravity = 0.07f;
    }
		colorIndex = rand();
    lifetime = random8(160,210);
    color = ColorFromPalette(*pal_arr[palette],lifetime,lifetime,LINEARBLEND);
		active = true;
	}*/

  void Update(byte ltlimit, byte ltdec){
    lifetime -= ltdec; //this is for combining fountain and flame
    yv -= gravity;
    x += xv;
    y += yv;
    color = ColorFromPalette(*pal_arr[palette],colorIndex,lifetime,LINEARBLEND); //fountainPalette
    if(x>WIDTH-1 || x<0 || y<0 || lifetime<ltlimit) active = false; //ltlimid is for combine some different subs - fountain and flame
  }

};

Particle particles[NUM_PARTICLES];

void Fountain() {

   if (loadingFlag) {loadingFlag = false;  palette=random(countpal);}	//9 - here qty of palettes in array;
   
   for(int i=0; i<NUM_PARTICLES; i++){
    if(particles[i].active) {
      drawPixelXYF(particles[i].x,particles[i].y, particles[i].color);
      particles[i].Update(0,2);
    }
    else particles[i].Init(WIDTH/2,0);

    EVERY_N_MILLISECONDS (5000) {
     palette++;
     if (palette>=countpal) palette=0;
    }  
  }
    fadeToBlackBy(leds,NUM_LEDS,40); //20
}
////////////////////////////////////////////// Fontain +9%RAM

/////////////// Flame ////////////////////////
void Flame() {
//   if (loadingFlag) {loadingFlag = false;  palette=random(countpal);}	//here must be qty of palettes in array; palette is defined higher in Fountain

  int initX = beatsin8(5, WIDTH/2-(WIDTH/4), WIDTH/2+(WIDTH/4)); // задает движение
  for(int i=0; i<NUM_PARTICLES; i++){
    if(particles[i].active) {
      drawPixelXYF(particles[i].x,particles[i].y, particles[i].color);
      particles[i].Update(10,5);
    }
    else particles[i].Init(initX,0);
  }
  fadeToBlackBy(leds,NUM_LEDS,80); //40

  EVERY_N_MILLISECONDS (5000) {
    palette++;
    if (palette>=countpal) palette=0;
  }  
}
////////////////////////////////////////////// Flame

///////////// WithoutSIN //////////////////////
void WithoutSin() {

if (loadingFlag) {loadingFlag = false; speed=0; scale=0; }	  

  for (uint16_t index = 0; index < NUM_LEDS; index++) {
    if ((index + speed) % (WIDTH + 1) == 0)
      leds[index] += CHSV((index / WIDTH) * 255 / HEIGHT + speed * 2, 255, 255);
  }
  
  if (++scale > 2) {scale = 0; speed++; }
  fadeToBlackBy(leds, NUM_LEDS, 15);
}
////////////////////////////////////////////// WithoutSIN почему то не работает нормально на 24*12, вместо двух встречных - один синус

///////////// DNASin //////////////////////
#define DNA_S_BRIGHTNESS 255
#define DNA_MN 255 / (WIDTH * 2)
#define DNA_SPEED 30 // speed of rotation 
byte freq = 9; //change this will made spiral big or small 
//byte dir = 1; //already defined higher

void DNASin() {

  if (loadingFlag) {  loadingFlag = false;  dir=1;}	  

  EVERY_N_MILLISECONDS(500) {
     freq+=dir;
    if (freq > 15 || freq < 1)
      dir *=-1;
   }

  fadeToBlackBy(leds, NUM_LEDS, 30);
    
  for (byte i = 0; i < HEIGHT; i++) {
    uint16_t ms = millis();
    leds[i * WIDTH + beatsin8(DNA_SPEED, 0, WIDTH - 1, 0, i * freq)] += CHSV(ms / 30 + i * 255 / (HEIGHT - 1), 255, beatsin8(DNA_SPEED, 30, DNA_S_BRIGHTNESS, 0, i * DNA_MN + 64));
    leds[i * WIDTH + beatsin8(DNA_SPEED, 0, WIDTH - 1, 0, 128 + i * freq)] += CHSV(ms / 30 + ((i * 255 / (HEIGHT - 1)) + 128), 255, beatsin8(DNA_SPEED, 30, DNA_S_BRIGHTNESS, 0, i * DNA_MN + 192));
  }
 blur2d(leds, WIDTH, HEIGHT, 30); //64
}
////////////////////////////////////////////// DNASin почти близнец withoutsin. апгрейдил изменяющейся частотой

//////// SinSparkles /////////////////
void SinSparkles() {
    
  int numSparkles = beatsin8(8, 1, 4);
  
  EVERY_N_MILLISECONDS(30) { hue++; }
  
  EVERY_N_MILLISECONDS(10) {
    for (int i = 0; i < numSparkles; i++) {
      uint16_t index = random(0, NUM_LEDS);
      leds[index] = CHSV(hue + index / 20, 255, 255);
    }
    fadeToBlackBy(leds, NUM_LEDS, 1);
  }
}
////////////////////////////////////// SinSparkles. копия ex7sparkles, но с размытием

//////// Twister /////////////////
void Twister() {
  
    uint16_t a_tw = millis() / 12;
    LEDS.clear();
  
    for (byte i = 0; i < HEIGHT; i++) {
    byte sinOff = sin8(i*8/PI+cos8(a_tw/2+i)/4+a_tw/3);

    byte x1 = sin8(sinOff+a_tw)*(WIDTH)/255;
    byte x2 = sin8(sinOff+a_tw+64)*(WIDTH)/255;
    byte x3 = sin8(sinOff+a_tw+128)*(WIDTH)/255;
    byte x4 = sin8(sinOff+a_tw+192)*(WIDTH)/255;
    x1= x1>=WIDTH? (WIDTH-1):x1;
    x2= x2>=WIDTH? (WIDTH-1):x2;
    x3= x3>=WIDTH? (WIDTH-1):x3;
    x4= x4>=WIDTH? (WIDTH-1):x4;

    hue = sin8(a_tw/20);
    if (x1<x2) mydrawLine_twister(x1, x2, i, CHSV (hue,255,255), 1, 1,i,0,sinOff,a_tw);
    if (x2<x3) mydrawLine_twister(x2, x3, i, CHSV (hue+64,255,255), 1, 1,i,1,sinOff,a_tw);
    if (x3<x4) mydrawLine_twister(x3, x4, i, CHSV (hue+128,255,255), 1, 1,i,2,sinOff,a_tw);
    if (x4<x1) mydrawLine_twister(x4, x1, i, CHSV (hue+192,255,255), 1,1,i,3,sinOff,a_tw);
    } 
  //GammaCorrection(); //uncomment this when load on matrix
}
////////////////////////////////////////////// Twister

/////////////// StarShips /////////////////// 
void MoveX(int8_t delta) {
  if (delta) {
    if (delta > 0) {
      for (uint8_t y = 0; y < HEIGHT; y++) {
        for (uint8_t x = 0; x < WIDTH; x++) {
          leds[XY(x, y)] = leds[XY(x + delta, y)];
        }
      }
    } else {
      for (uint8_t y = 0; y < HEIGHT; y++) {
        for (uint8_t x = WIDTH- 1; x > 0; x--) {
          leds[XY(x, y)] = leds[XY(x + delta, y)];
        }
      }
    }
  }
}

void MoveY(int8_t delta) {
  if (delta) {
    if (delta > 0) {
      for (uint8_t x = 0; x < WIDTH; x++) {
        for (uint8_t y = 0; y < HEIGHT; y++) {
          leds[XY(x, y)] = leds[XY(x, y + delta)];
        }
      }
    } else {
      for (uint8_t x = 0; x < WIDTH; x++) {
        for (uint8_t y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = leds[XY(x, y + delta)];
        }
      }
    }
  }
}

void drawPixel_ss(byte x, byte y, CRGB color) {
  leds[XY(x, y)] += color;
  if (WIDTH > 24 || HEIGHT > 24) {
    leds[XY(x + 1, y)] += color;
    leds[XY(x - 1, y)] += color;
    leds[XY(x, y + 1)] += color;
    leds[XY(x, y - 1)] += color;
  }
}

void StarShips() {

 if (loadingFlag) {loadingFlag = false; dir=0;}

  fadeToBlackBy(leds, NUM_LEDS, 16);
  switch (dir) {
    case 0:      MoveX(1);                       break;
    case 1:      MoveX(1);       MoveY(-1);      break;
    case 2:      MoveY(-1);                      break;
    case 3:      MoveX(-1);      MoveY(-1);      break;
    case 4:      MoveX(-1);                      break;
    case 5:      MoveX(-1);      MoveY(1);       break;
    case 6:      MoveY(1);                       break;
    case 7:      MoveX(1);       MoveY(1);       break;
  }
    for (byte i = 0; i < 8; i++) {
    byte x = beatsin8(12 + i, 2, WIDTH - 3);
    byte y = beatsin8(15 + i, 2, HEIGHT - 3);
    drawPixel_ss(x, y, ColorFromPalette(RainbowColors_p, beatsin8(12 + i, 0, 255), 255));
  }
  blur2d(leds, WIDTH, HEIGHT, 32);
  EVERY_N_SECONDS(2) {
    if (dir == 7) dir = 0;
    else dir++;
  }
}
///////////////////////////////////////////// StarShips

//////////////// Fire Ring ///////////////////

byte bump[(WIDTH+2)*(HEIGHT+2)]; //also used for fire ring

DEFINE_GRADIENT_PALETTE(firepal) { // define fire palette, с этой палитрой норм получается
  0,  0,  0,  0, //black
  50, 0,0,0,
  64,  255,  0,  0, // red
  100,  255,  255,  0, //yellow
  255,  255,  255,  255, // white
};
 
 //extern const byte firepal_p[] FL_PROGMEM = {0,0,0,0,50,0,0,0,64,255,0,0,100,255,255,0,255,255,255,255}; //в 16*16 норм, а тут почему-то тупит.
  
uint16_t buffXY (byte x, byte y){ return (y*(WIDTH+2)+x); }

void fadeup(){
uint16_t sum;
for (byte x = 1; x < WIDTH+1; x++) {
  for (byte y = 0; y < HEIGHT+1; y++) {

     sum =  bump [buffXY(x,y)]; 
     sum += bump [buffXY(x-1,y+1)];
     sum += bump [buffXY(x,y+1)];
     sum += bump [buffXY(x+1,y+1)];
     sum /=4;
     bump [buffXY(x,y)]=sum;
}}
}

void sinballs() {
  brightness = 230;   //bright, можно поярче посмотреть
  byte t1 = millis() / 10;
  byte t2 = sin8(t1)/2;
  for (byte i = 0; i < 11; i++) {
    byte x = sin8(t1 + i * 24)*(WIDTH)/255;  //0..COLS
    byte y = sin8(t2 + i * 24)*(HEIGHT)/255;  //0..ROWS 
    x= x>=WIDTH? (WIDTH-1):x;
    y= y>=HEIGHT? (HEIGHT-1):y;
    bump[buffXY(x+1, y+1)] = brightness;   // 1..COLS+1. 1..ROWS+1
  }
}

void toLeds (){
  CRGBPalette256 myPal = firepal;
  uint16_t buffIndex = 1;//(COLS+3);
  for (int y = 0; y < HEIGHT; y++) {
   for (int x = 0; x < WIDTH; x++) {
      int index = XY(x, (HEIGHT-1)-y);
      leds[index] = ColorFromPalette (myPal, bump[buffIndex],255); //heatcolors_p очень длинный шлейф
      buffIndex++;
    }
  buffIndex+=2; 
  } 
}

void FireRing() {
  if (loadingFlag) {
    loadingFlag = false;
    for (uint16_t i=0; i<(WIDTH+2)*(HEIGHT+2);i++) bump[i]=0;
  }	
  sinballs();
  fadeup();
  toLeds();
 // delay(30);
}
///////////////////////////////////////////// Fire Ring

/////////////// China2 //////////02.12.25////////// - треугольники из огня влево-вправо
void China2() {
  float t = millis()/50.;
  for(byte x =0; x <WIDTH; x++){
    for(byte y =0; y <HEIGHT; y++){
      leds[XY(x,y)]=ColorFromPalette(HeatColors_p,((sin8((x*10)+sin8(y*5+t*5.))+cos8(y*10))+1)+t)*2;
}}}
/////////////////////////////////////////////China2

/////////////// Recto1 //////////////////// радужный Sinus-гармошка
//byte recto1 = 20; //speed
byte step_recto1=1;

void Recto1() {
   if (loadingFlag) {loadingFlag=false; speed=20; scale=1;}
  for (int index = 0; index < NUM_LEDS; index++) { leds[index].nscale8(50); }

  for (int i = 0; i < WIDTH; i++)  {
    int tmp = cos8((i * speed) + (millis() >> 1));
    tmp = map8(tmp, 1, HEIGHT - 2);
    leds[XY(i, tmp)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
    leds[XY(i, tmp - 1)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
    leds[XY(i, tmp + 1)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
  }
  EVERY_N_MILLISECONDS(100) { 
      speed+=step_recto1; 
    if (speed>70 || speed<20)
      step_recto1*=-1;
    }
}
///////////////////////////////////////////// Recto1

/////////////// FireFlow //////////////////// - полосы ползающие. в исходнике было на 90 повернуто, пришлось допиливать для зигзага
void FireFlow() {
  const float hl = NUM_LEDS/15;
  int t = millis() / 15;

  for (byte x = 0; x < HEIGHT; x++) {
    for (byte y = 0; y < WIDTH; y++) {
      byte origX = y;
      byte origY = WIDTH - 1 - x;
      int linearIndex = origY * WIDTH + origX;
      
      int c = (abs(linearIndex - hl) / hl) * 20;
      byte b = sin8(c + t / 8);
      leds[XY(y, x)] = ColorFromPalette(LavaColors_p, (b + t) % 255, 255);
    }
  }
}
/////////////////////////////////////////////FireFlow

/////////////// VUSpectrum //////03.12.25/////// - Эквалайзер
#define SAMPLES           256U          // Must be a power of 8
#define NUM_BANDS       WIDTH
#define TOP            (HEIGHT - 1)                // Don't allow the bars to go offscreen
#define BAR_WIDTH      (WIDTH  / (NUM_BANDS - 1))  // If width >= 8 light 1 LED width per bar, >= 16 light 2 LEDs width bar etc

const float speedFactorVertical = (float)HEIGHT / 16;

class EffectVU {
private:
    byte colorShift = 255;
    // Sampling and FFT stuff
    float peak[NUM_BANDS];              // The length of these arrays must be >= NUM_BANDS
    float oldBarHeights[NUM_BANDS];
    float bandValues[NUM_BANDS];

    uint8_t last_max_peak;
    float maxVal;
    float amplitude = 0.4; // 0.025 - 0.5
    void horizontalColoredBars(uint8_t band, float barHeight);
    void whitePeak(uint8_t band);

public:
    bool run();
    void load();
};

void EffectVU::load() {
  for(uint16_t i=0; i<sizeof(oldBarHeights)/(sizeof(*oldBarHeights));i++)
  for(uint16_t i=0; i<sizeof(bandValues)/(sizeof(*bandValues));i++)
    bandValues[i]=0.0f;
}

bool EffectVU::run() {
  
  EVERY_N_MILLIS(random(50,100)) {  //here the dynamics of VU is set. was (50,300)
    last_max_peak=random(0,HEIGHT);
    maxVal = random(0,last_max_peak);
    for (uint16_t i = 0; i < (sizeof(bandValues) / sizeof(float)); i++) {
      bandValues[i] = random(2)? random(0, HEIGHT) : bandValues[i];
    }
  }

  float _scale = (maxVal==0? 0 : last_max_peak/maxVal) * amplitude;

  FastLED.clear();

  // Process the FFT data into bar heights
  for (byte band = 0; band < NUM_BANDS; band++) {

    // Scale the bars for the display
    float barHeight = bandValues[band] * _scale > 0/*threshold*/ ? (bandValues[band] * _scale) : 0.;
    if (barHeight > TOP) barHeight = TOP;

    // Small amount of averaging between frames
    barHeight = ((oldBarHeights[band] * 1) + barHeight) / 2;

    // Move peak up
    if (barHeight > peak[band]) {
      peak[band] = min((float)TOP, barHeight);
    }
    
    horizontalColoredBars(band, barHeight);
    whitePeak(band);

    // Save oldBarHeights for averaging later
    oldBarHeights[band] = barHeight;
  }

  // Decay peak
    for (byte band = 0; band < NUM_BANDS; band++)
      if (peak[band] > 0) peak[band] -= 0.25 * speedFactorVertical;
  return true;
}

void EffectVU::horizontalColoredBars(uint8_t band, float barHeight) {
  uint8_t xStart = BAR_WIDTH * band;
  
  EVERY_N_MILLIS(10) colorShift--;
  
  for (uint8_t x = xStart; x < xStart + BAR_WIDTH; x++) {
    for (float y = TOP; y >= (float)TOP - barHeight; y-= 0.5) {
        drawPixelXYF(x, (float)TOP - y, CHSV(band * (232 / NUM_BANDS) + colorShift, 255, 255));
//        drawPixelXYF(x, (float)TOP - y, ColorFromPalette(LavaColors_p, band * (232 / NUM_BANDS) + colorShift)); // можно задействовать countpal и pal_arr
    }
  }
}

void EffectVU::whitePeak(uint8_t band) {
  uint8_t xStart = BAR_WIDTH * band;
  float peakHeight = (float)TOP - peak[band] - 1;
  for (uint8_t x = xStart; x < xStart + BAR_WIDTH; x++) {
    drawPixelXYF(x, (float)TOP - peakHeight, CHSV(0,0,255));
  }
}

EffectVU eff;

void VUSpectrum() {
  
  if (loadingFlag) {
    eff.load();
    loadingFlag = false;
  }
  eff.run();
  delay(16);  // 16 - ~60fps
}
/////////////////////////////////////////////VUSpectrum

/////////////// Something //////04.12.25/////// - этакий глаз выворачивается

CRGB ColorFromPaletteExtended_other(const CRGBPalette16& pal, uint16_t index, uint8_t brightness, TBlendType blendType) {
  // Extract the four most significant bits of the index as a palette index.
  uint8_t index_4bit = (index >> 12);
  // Calculate the 8-bit offset from the palette index.
  uint8_t offset = (uint8_t)(index >> 4);
  // Get the palette entry from the 4-bit index
  const CRGB* entry = &(pal[0]) + index_4bit;
  uint8_t red1      = entry->red;
  uint8_t green1    = entry->green;
  uint8_t blue1     = entry->blue;

  uint8_t blend = offset && (blendType != NOBLEND);
  if (blend) {
    if (index_4bit == 15) {
      entry = &(pal[0]);
    } else {
      entry++;
    }
    // Calculate the scaling factor and scaled values for the lower palette value.
    uint8_t f1 = 255 - offset;
    red1       = scale8_LEAVING_R1_DIRTY(red1, f1);
    green1     = scale8_LEAVING_R1_DIRTY(green1, f1);
    blue1      = scale8_LEAVING_R1_DIRTY(blue1, f1);

    // Calculate the scaled values for the neighbouring palette value.
    uint8_t red2   = entry->red;
    uint8_t green2 = entry->green;
    uint8_t blue2  = entry->blue;
    red2           = scale8_LEAVING_R1_DIRTY(red2, offset);
    green2         = scale8_LEAVING_R1_DIRTY(green2, offset);
    blue2          = scale8_LEAVING_R1_DIRTY(blue2, offset);
    cleanup_R1();

    // These sums can't overflow, so no qadd8 needed.
    red1 += red2;
    green1 += green2;
    blue1 += blue2;
  }
  if (brightness != 255) {
     //nscale8x3_video(red1, green1, blue1, brightness);
    nscale8x3(red1, green1, blue1, brightness);
  }
   return CRGB(red1, green1, blue1);
}

void Something() {

  FastLED.clear();
  float ms                = millis() / 200.f;
  const float kHalfWidth  = WIDTH / 2;
  const float kHalfHeight = HEIGHT / 2;

  const float density = 1.1175f + 0.0275f * sinf(ms * 1.09f);
  for (float y = 0; y <= kHalfHeight + 2; y += density)
    for (float x = 0; x <= kHalfWidth + 2; x += density) {
      float hyp = hypotf(x, y) * -3.f;
      float fx  = sinf(ms + hyp / 8.f) * 84.f;
      float fy  = cosf(ms * .78f + hyp / 8.f) * 224.f;
      //CRGB col = ColorFromPaletteExtended_other(HeatColors_p, (ms * 24.f + hyp * 4.f) * 256.f, 255, LINEARBLEND);
      CRGB col = ColorFromPaletteExtended_other(*pal_arr[palette], (ms * 24.f + hyp * 4.f) * 256.f, 255, LINEARBLEND);      
      wu_pixel(256 * (x + kHalfWidth) + fx, 256 * (y + kHalfHeight) + fy, &col);
      if (x) wu_pixel(256 * (-x + kHalfWidth) + fx, 256 * (y + kHalfHeight) + fy, &col);
      if (y) wu_pixel(256 * (x + kHalfWidth) + fx, 256 * (-y + kHalfHeight) + fy, &col);
      if (x && y) wu_pixel(256 * (-x + kHalfWidth) + fx, 256 * (-y + kHalfHeight) + fy, &col);
    }
  EVERY_N_MILLISECONDS (5000) {
    palette++;
    if (palette>=countpal)
      palette=0;
  }    
}
/////////////////////////////////////////////Something