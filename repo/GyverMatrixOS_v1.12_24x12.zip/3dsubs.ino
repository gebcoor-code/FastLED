//all 3d subs
//18.12.25, coor@

#define dots 72
float vectors[dots][3];

float perspective = 60.0;
int8_t deltaX, deltaY, deltaZ, iter = 0;
float scale3D = 1.0;
float scaleDirection = 0.01;
byte dotsCount; //used to limit dots array in every func

#define stepDirection 0.01

int8_t translateX(float x,  float z) {

#if (FixScaleX == 1)  //North needs ScaleX correction
  float scaledX = x * scale3D * 1.2;
#else
  float scaledX = x * scale3D;
#endif

  float scaledZ = z * scale3D;
  return (int8_t)((scaledX + WIDTH/2) + (scaledZ * (scaledX / perspective)));
}

int8_t translateY(float y, float z) {
  float scaledY = y * scale3D;
  float scaledZ = z * scale3D;
  return (int8_t)((scaledY + HEIGHT/2) + (scaledZ * (scaledY / perspective)));
}

void rotateX(int8_t angle) {
  float rad = angle * PI / 180;
  float cosa = cos(rad);
  float sina = sin(rad);
  for (byte i = 0; i < dotsCount; i++) {
    float y = vectors[i][1];
    float z = vectors[i][2];
    vectors[i][1] = y * cosa - z * sina;
    vectors[i][2] = y * sina + z * cosa;
  }
}

void rotateY(int8_t angle) {
  float rad = angle * PI / 180;
  float cosa = cos(rad);
  float sina = sin(rad);
  for (byte i = 0; i < dotsCount; i++) {
    float x = vectors[i][0];
    float z = vectors[i][2];
    vectors[i][0] = x * cosa - z * sina;
    vectors[i][2] = x * sina + z * cosa;
  }
}

void rotateZ(int8_t angle) {
  float rad = angle * PI / 180;
  float cosa = cos(rad);
  float sina = sin(rad);
  for (byte i = 0; i < dotsCount; i++) {
    float x = vectors[i][0];
    float y = vectors[i][1];
    vectors[i][0] = x * cosa - y * sina;
    vectors[i][1] = x * sina + y * cosa;
  }
}

///////////// 3DCube Hidden Edges /////08.12.25////////

bool isFaceVisible(int8_t v1, int8_t v2, int8_t v3) {
  float edge1[3] = { vectors[v2][0] - vectors[v1][0], vectors[v2][1] - vectors[v1][1],  vectors[v2][2] - vectors[v1][2]  };
  float edge2[3] = { vectors[v3][0] - vectors[v1][0],  vectors[v3][1] - vectors[v1][1],  vectors[v3][2] - vectors[v1][2]  };
  float normal[3] = { edge1[1] * edge2[2] - edge1[2] * edge2[1],  edge1[2] * edge2[0] - edge1[0] * edge2[2],  edge1[0] * edge2[1] - edge1[1] * edge2[0]  };
  float dot = normal[2]; // Only Z component matters
  return (dot > 0);
}

// Draw a face only if it's visible
void drawFaceIfVisible(int8_t v1, int8_t v2, int8_t v3, int8_t v4) {
  // Check visibility using first three vertices
  if (isFaceVisible(v1, v2, v3)) {
    Line(translateX(vectors[v1][0], vectors[v1][2]), translateY(vectors[v1][1], vectors[v1][2]),
         translateX(vectors[v2][0], vectors[v2][2]), translateY(vectors[v2][1], vectors[v2][2]));
    Line(translateX(vectors[v2][0], vectors[v2][2]), translateY(vectors[v2][1], vectors[v2][2]),
         translateX(vectors[v3][0], vectors[v3][2]), translateY(vectors[v3][1], vectors[v3][2]));
    Line(translateX(vectors[v3][0], vectors[v3][2]), translateY(vectors[v3][1], vectors[v3][2]),
         translateX(vectors[v4][0], vectors[v4][2]), translateY(vectors[v4][1], vectors[v4][2]));
    Line(translateX(vectors[v4][0], vectors[v4][2]), translateY(vectors[v4][1], vectors[v4][2]),
         translateX(vectors[v1][0], vectors[v1][2]), translateY(vectors[v1][1], vectors[v1][2]));
  }
}

void drawVectors() {
  drawFaceIfVisible(0, 1, 2, 3);
  drawFaceIfVisible(4, 7, 6, 5); // Reverse order
  drawFaceIfVisible(0, 4, 5, 1);
  drawFaceIfVisible(2, 6, 7, 3); // Reverse order
  drawFaceIfVisible(0, 3, 7, 4);
  drawFaceIfVisible(1, 5, 6, 2); // Reverse order
}

void ScaleAndRotate(float maxSc, float minSc, bool rX, bool rY, bool rZ, int8_t deltaAngle, int8_t maxAngle) {

  if (iter == 0) {
    deltaX = random(maxAngle) + deltaAngle;    deltaY = random(maxAngle) + deltaAngle;    deltaZ = random(maxAngle) + deltaAngle; //было исходно random(7)-3; теперь r(5)+2
//    if (deltaX==0) deltaX=1; if (deltaY==0) deltaY=1; if (deltaZ==0) deltaZ=1;
    if (abs(deltaX)<2) deltaX=2; if (abs(deltaY)<2) deltaY=2; if (abs(deltaZ)<2) deltaZ=2;
    iter = random(250) + 5;
  }
  scale3D += scaleDirection;
  if (scale3D >= maxSc) {
    scale3D = maxSc;
    scaleDirection = -stepDirection;
  } else if (scale3D <= minSc) {
    scale3D = minSc;
    scaleDirection = stepDirection;
  }
  if (rX) rotateX(deltaX);  if (rY) rotateY(deltaY);  if (rZ) rotateZ(deltaZ);
  iter--;
}

void Cube3DHid() {

  if(loadingFlag) {
    loadingFlag = false;
    //init 3dcube
    dotsCount = 8; //for cube
    vectors[0][0] = 5;  vectors[0][1] = 5;  vectors[0][2] = 5;
    vectors[1][0] = -5; vectors[1][1] = 5;  vectors[1][2] = 5;
    vectors[2][0] = -5; vectors[2][1] = -5; vectors[2][2] = 5;
    vectors[3][0] = 5;  vectors[3][1] = -5; vectors[3][2] = 5;
    vectors[4][0] = 5;  vectors[4][1] = 5;  vectors[4][2] = -5;
    vectors[5][0] = -5; vectors[5][1] = 5;  vectors[5][2] = -5;
    vectors[6][0] = -5; vectors[6][1] = -5; vectors[6][2] = -5;
    vectors[7][0] = 5;  vectors[7][1] = -5; vectors[7][2] = -5;
  }

  FastLED.clear();
  drawVectors();
  ScaleAndRotate(1.4, 0.7, 1,1,1,-3,7); 
//  delay(10);
}
////////////////////////////////// 3D Cube Hidden Edges

///// Sphere3D /////12.12.25///////////////

// uniform distribution using the golden ratio with offset for poles
void initUniformSpherePoints2() {
  const float goldenAngle = PI * (3.0 - sqrt(5.0));
  const float offset = 2.0 / dotsCount;
  
  for (byte i = 0; i < dotsCount; i++) {
    float y = (i * offset) - 1.0 + (offset * 0.5);  // y от -1 до 1
    float radiusAtY = sqrt(1.0 - y * y);
    float theta = goldenAngle * i;
    
    vectors[i][0] = 5.0 * cos(theta) * radiusAtY;
    vectors[i][1] = 5.0 * y;
    vectors[i][2] = 5.0 * sin(theta) * radiusAtY;
  }
}

//uniform dots (kind of Fibonacci)
void initSphereSpiraleUniform() {
  const float radius = 5.0;
  const int turns = 7;
  
  const float offset = 2.0 / dotsCount;
  const float increment = turns * 2.0 * PI * offset;
  
  for (byte i = 0; i < dotsCount; i++) {
    float y = 1.0 - (i * offset);
    
    if (i == 0) y = 0.999;
    else if (i == dotsCount-1) y = -0.999;
    float r = sqrt(1.0 - y*y);
    float phi = i * increment;
    
    vectors[i][0] = radius * r * cos(phi);
    vectors[i][1] = radius * y;
    vectors[i][2] = radius * r * sin(phi);
  }
}

//spirale classic 
void initSphereSpirale() {
  const float radius = 5.0;
  const int turns = 6;
  
  for (byte i = 0; i < dotsCount; i++) {
    float t = i / ((float)dotsCount - 1.0);
    float z = 1.0 - 2.0 * t;
    float r = sqrt(1.0 - z * z);  //x² + y² + z² = 1
    float phi = turns * 2.0 * PI * t;
    
    //to dec coords
    vectors[i][0] = radius * r * cos(phi);
    vectors[i][1] = radius * z;
    vectors[i][2] = radius * r * sin(phi);
  }
}

//White to red 3step gradient
void drawWhiteToRedGradient() {
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);
    
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
      float z = vectors[i][2];
      int idx = XY(x,y);
//4 levels
      CRGB new_color = 
        (z > 0)     ? CRGB(255, 255, 255) :    //Close: White
        (z > -1)    ? CRGB(128,0,0) :          //Red1                         
        (z > -2)    ? CRGB(96,0,0) :           //Red2
        (z > -3)    ? CRGB(80,0,0):            //Red3
                      CRGB(60,0,0);            //Red4

      if (new_color > leds[idx]) leds[idx] = new_color;      
    }
  }
}

void drawNeonSparkles() {
  speed += 5;
  
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);
    
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
      float z = vectors[i][2];
      int idx = XY(x,y);
      //hue = (x * 15 + y * 10 + speed) % 255;
      hue = (x * 5 + y * 5 + speed) % 255;
      if (z > -1) {
        CRGB base_color = CHSV(hue, 255, 255);

        //sparkles
        if (random8(100) < 20) leds[idx] = CRGB::White;
        else                   leds[idx] = base_color;
        
        if (x > 0) leds[XY(x-1, y)] = blend(leds[XY(x-1, y)], CHSV(hue, 230, 200), 200);
        if (x < WIDTH-1) leds[XY(x+1, y)] = blend(leds[XY(x+1, y)], CHSV(hue, 230, 200), 200);
        if (y > 0) leds[XY(x, y-1)] = blend(leds[XY(x, y-1)], CHSV(hue, 230, 200), 200);
        if (y < HEIGHT-1) leds[XY(x, y+1)] = blend(leds[XY(x, y+1)], CHSV(hue, 230, 200), 200);      
      } else leds[idx] = blend(leds[idx], CHSV(hue, 200, 100), 200);
    }
  }
}

void Sphere3D(bool init, bool type) {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = 72; 
    if (!init)  initUniformSpherePoints2(); //golden ratio over sphere surface with moved upper and lower points for better dots distribution
    else          initSphereSpiraleUniform(); //Fibonacci Spirale
  }
  FastLED.clear();
  if (!type) drawWhiteToRedGradient(); //red to white gradient
  else       drawNeonSparkles(); //neon sparkles

  ScaleAndRotate(2.7, 1.1, 1,1,1,-3,7);
//  delay(10);
}
////////////////////////////////// Sphere3D

////////////////// Octahedron //////////////////

bool isTriagFaceVisible(int8_t v1, int8_t v2, int8_t v3) {
  float ax = vectors[v2][0] - vectors[v1][0];
  float ay = vectors[v2][1] - vectors[v1][1];
  float az = vectors[v2][2] - vectors[v1][2];
  float bx = vectors[v3][0] - vectors[v1][0];
  float by = vectors[v3][1] - vectors[v1][1];
  float bz = vectors[v3][2] - vectors[v1][2];
  float nz = ax * by - ay * bx;
  return (nz < 0);
}

void drawTriangleIfVisible(int8_t v1, int8_t v2, int8_t v3) {
  if (!isTriagFaceVisible(v1, v2, v3)) return;
  
  int8_t x1 = translateX(vectors[v1][0], vectors[v1][2]);
  int8_t y1 = translateY(vectors[v1][1], vectors[v1][2]);
  int8_t x2 = translateX(vectors[v2][0], vectors[v2][2]);
  int8_t y2 = translateY(vectors[v2][1], vectors[v2][2]);
  int8_t x3 = translateX(vectors[v3][0], vectors[v3][2]);
  int8_t y3 = translateY(vectors[v3][1], vectors[v3][2]);
  
  Line(x1, y1, x2, y2);
  Line(x2, y2, x3, y3);
  Line(x3, y3, x1, y1);
}

void drawOctahedron() {
  drawTriangleIfVisible(0, 1, 2);
  drawTriangleIfVisible(0, 2, 3);
  drawTriangleIfVisible(0, 3, 4);
  drawTriangleIfVisible(0, 4, 1);
  drawTriangleIfVisible(5, 2, 1);
  drawTriangleIfVisible(5, 3, 2);
  drawTriangleIfVisible(5, 4, 3);
  drawTriangleIfVisible(5, 1, 4);
}

void Octahedron() {

  if(loadingFlag) {
    loadingFlag = false;
    //init octahedron
    dotsCount = 6; //for octahedron
    vectors[0][0] = 0;  vectors[0][1] = 0;  vectors[0][2] = 5;
    vectors[1][0] = 5;  vectors[1][1] = 0;  vectors[1][2] = 0;
    vectors[2][0] = 0;  vectors[2][1] = 5;  vectors[2][2] = 0;
    vectors[3][0] = -5; vectors[3][1] = 0;  vectors[3][2] = 0;
    vectors[4][0] = 0;  vectors[4][1] = -5; vectors[4][2] = 0;
    vectors[5][0] = 0;  vectors[5][1] = 0;  vectors[5][2] = -5;
  }

  FastLED.clear();
  //  fadeToBlackBy (leds,NUM_LEDS, 150);
  
  drawOctahedron(); 
  ScaleAndRotate(3.0, 0.9,1,1,1,-3,7);
//  delay(10);
}
///////////////////////////////// Octahedron

//////////// Сircle3D //////////////
//Circle
void drawCircle() {

  for (int i = 0; i < dotsCount; i++) {
    int next = (i + 1) % dotsCount;
    
    int8_t x1 = translateX(vectors[i][0], vectors[i][2]);
    int8_t y1 = translateY(vectors[i][1], vectors[i][2]);
    int8_t x2 = translateX(vectors[next][0], vectors[next][2]);
    int8_t y2 = translateY(vectors[next][1], vectors[next][2]);
    
    Line(x1, y1, x2, y2);
  }
}

void Circle3D() {

  if(loadingFlag) {
    loadingFlag = false;
    dotsCount = 24;
//    if (!variant) dotsCount = 24; //for two circles
//    else          dotsCount = 36; // 3 ort circles from dots
//XY
    vectors[0][0] = 5.0; vectors[0][1] = 0.0; vectors[0][2] = 0.0;
    vectors[1][0] = 4.33; vectors[1][1] = 2.5; vectors[1][2] = 0.0;
    vectors[2][0] = 2.5; vectors[2][1] = 4.33; vectors[2][2] = 0.0;
    vectors[3][0] = 0.0; vectors[3][1] = 5.0; vectors[3][2] = 0.0;
    vectors[4][0] = -2.5; vectors[4][1] = 4.33; vectors[4][2] = 0.0;
    vectors[5][0] = -4.33; vectors[5][1] = 2.5; vectors[5][2] = 0.0;
    vectors[6][0] = -5.0; vectors[6][1] = 0.0; vectors[6][2] = 0.0;
    vectors[7][0] = -4.33; vectors[7][1] = -2.5; vectors[7][2] = 0.0;
    vectors[8][0] = -2.5; vectors[8][1] = -4.33; vectors[8][2] = 0.0;
    vectors[9][0] = 0.0; vectors[9][1] = -5.0; vectors[9][2] = 0.0;
    vectors[10][0] = 2.5; vectors[10][1] = -4.33; vectors[10][2] = 0.0;
    vectors[11][0] = 4.33; vectors[11][1] = -2.5; vectors[11][2] = 0.0;
//XZ
    vectors[12][0] = 5.0; vectors[12][1] = 0.0; vectors[12][2] = 0.0;
    vectors[13][0] = 4.33; vectors[13][1] = 0.0; vectors[13][2] = 2.5;
    vectors[14][0] = 2.5; vectors[14][1] = 0.0; vectors[14][2] = 4.33;
    vectors[15][0] = 0.0; vectors[15][1] = 0.0; vectors[15][2] = 5.0;
    vectors[16][0] = -2.5; vectors[16][1] = 0.0; vectors[16][2] = 4.33;
    vectors[17][0] = -4.33; vectors[17][1] = 0.0; vectors[17][2] = 2.5;
    vectors[18][0] = -5.0; vectors[18][1] = 0.0; vectors[18][2] = 0.0;
    vectors[19][0] = -4.33; vectors[19][1] = 0.0; vectors[19][2] = -2.5;
    vectors[20][0] = -2.5; vectors[20][1] = 0.0; vectors[20][2] = -4.33;
    vectors[21][0] = 0.0; vectors[21][1] = 0.0; vectors[21][2] = -5.0;
    vectors[22][0] = 2.5; vectors[22][1] = 0.0; vectors[22][2] = -4.33;
    vectors[23][0] = 4.33; vectors[23][1] = 0.0; vectors[23][2] = -2.5;
//YZ
 /*   vectors[24][0] = 0.0; vectors[24][1] = 5.0; vectors[24][2] = 0.0;
    vectors[25][0] = 0.0; vectors[25][1] = 4.33; vectors[25][2] = 2.5;
    vectors[26][0] = 0.0; vectors[26][1] = 2.5; vectors[26][2] = 4.33;
    vectors[27][0] = 0.0; vectors[27][1] = 0.0; vectors[27][2] = 5.0;
    vectors[28][0] = 0.0; vectors[28][1] = -2.5; vectors[28][2] = 4.33;
    vectors[29][0] = 0.0; vectors[29][1] = -4.33; vectors[29][2] = 2.5;
    vectors[30][0] = 0.0; vectors[30][1] = -5.0; vectors[30][2] = 0.0;
    vectors[31][0] = 0.0; vectors[31][1] = -4.33; vectors[31][2] = -2.5;
    vectors[32][0] = 0.0; vectors[32][1] = -2.5; vectors[32][2] = -4.33;
    vectors[33][0] = 0.0; vectors[33][1] = 0.0; vectors[33][2] = -5.0;
    vectors[34][0] = 0.0; vectors[34][1] = 2.5; vectors[34][2] = -4.33;
    vectors[35][0] = 0.0; vectors[35][1] = 4.33; vectors[35][2] = -2.5;    */
  }

  FastLED.clear();
 // fadeToBlackBy (leds,NUM_LEDS, 100);

  drawCircle();
//  if (!variant) drawCircle();              
//  else drawWhiteToRedGradient();
  
  // drawTintedPoints();
 //drawPointsOnly();
  //drawWhiteAndRed();
  
  ScaleAndRotate(2.7,0.9,1,1,1,-3,7);
//  delay(10);
}
///////////////////////////////// Circle3D

///////// HAPPY 2026 ! (YEAR) //////////
void drawText() {
  byte totalLines = dotsCount/2; 
  
  for(byte line = 0; line < totalLines; line++) {
    byte startIdx = line * 2;
    byte endIdx = line * 2 + 1;
    
    int8_t x1 = translateX(vectors[startIdx][0], vectors[startIdx][2]);
    int8_t y1 = translateY(vectors[startIdx][1], vectors[startIdx][2]);
    int8_t x2 = translateX(vectors[endIdx][0], vectors[endIdx][2]);
    int8_t y2 = translateY(vectors[endIdx][1], vectors[endIdx][2]);
    
    Line(x1, y1, x2, y2);
  }
}

void Happy3D() {

  if(loadingFlag) {
    loadingFlag = false;
    dotsCount = 66; //for HAPPY 2026 -66. if YEAR ! - 72

    // H (0-5)
    vectors[0][0] = -9; vectors[0][1] = 5; vectors[0][2] = 0;    vectors[1][0] = -9; vectors[1][1] = 1; vectors[1][2] = 0;    vectors[2][0] = -7; vectors[2][1] = 5; vectors[2][2] = 0;
    vectors[3][0] = -7; vectors[3][1] = 1; vectors[3][2] = 0;    vectors[4][0] = -9; vectors[4][1] = 3; vectors[4][2] = 0;    vectors[5][0] = -7; vectors[5][1] = 3; vectors[5][2] = 0;
    // A (6-13)
    vectors[6][0] = -5; vectors[6][1] = 5; vectors[6][2] = 0;    vectors[7][0] = -3; vectors[7][1] = 5; vectors[7][2] = 0;    vectors[8][0] = -5; vectors[8][1] = 5; vectors[8][2] = 0;
    vectors[9][0] = -5; vectors[9][1] = 1; vectors[9][2] = 0;    vectors[10][0] = -3; vectors[10][1] = 5; vectors[10][2] = 0;    vectors[11][0] = -3; vectors[11][1] = 1; vectors[11][2] = 0;
    vectors[12][0] = -5; vectors[12][1] = 3; vectors[12][2] = 0;    vectors[13][0] = -3; vectors[13][1] = 3; vectors[13][2] = 0;
    // P (14-21)
    vectors[14][0] = -1; vectors[14][1] = 5; vectors[14][2] = 0;    vectors[15][0] = 1;  vectors[15][1] = 5; vectors[15][2] = 0;    vectors[16][0] = -1; vectors[16][1] = 5; vectors[16][2] = 0;
    vectors[17][0] = -1; vectors[17][1] = 1; vectors[17][2] = 0;    vectors[18][0] = 1;  vectors[18][1] = 5; vectors[18][2] = 0;    vectors[19][0] = 1;  vectors[19][1] = 3; vectors[19][2] = 0;
    vectors[20][0] = -1; vectors[20][1] = 3; vectors[20][2] = 0;    vectors[21][0] = 1;  vectors[21][1] = 3; vectors[21][2] = 0;
    // P (22-29)
    vectors[22][0] = 3; vectors[22][1] = 5; vectors[22][2] = 0;    vectors[23][0] = 5; vectors[23][1] = 5; vectors[23][2] = 0;    vectors[24][0] = 3; vectors[24][1] = 5; vectors[24][2] = 0;
    vectors[25][0] = 3; vectors[25][1] = 1; vectors[25][2] = 0;    vectors[26][0] = 5; vectors[26][1] = 5; vectors[26][2] = 0;    vectors[27][0] = 5; vectors[27][1] = 3; vectors[27][2] = 0;
    vectors[28][0] = 3; vectors[28][1] = 3; vectors[28][2] = 0;    vectors[29][0] = 5; vectors[29][1] = 3; vectors[29][2] = 0;
    // Y (30-35)
    vectors[30][0] = 7; vectors[30][1] = 5; vectors[30][2] = 0;    vectors[31][0] = 7; vectors[31][1] = 4; vectors[31][2] = 0;    vectors[32][0] = 9; vectors[32][1] = 5; vectors[32][2] = 0;
    vectors[33][0] = 9; vectors[33][1] = 4; vectors[33][2] = 0;    vectors[34][0] = 8; vectors[34][1] = 3; vectors[34][2] = 0;    vectors[35][0] = 8; vectors[35][1] = 1; vectors[35][2] = 0;
    /*
    // Y (36-41)
    vectors[36][0] = -8; vectors[36][1] = -1; vectors[36][2] = 0;    vectors[37][0] = -8; vectors[37][1] = -2; vectors[37][2] = 0;    vectors[38][0] = -6; vectors[38][1] = -1; vectors[38][2] = 0;
    vectors[39][0] = -6; vectors[39][1] = -2; vectors[39][2] = 0;    vectors[40][0] = -7; vectors[40][1] = -3; vectors[40][2] = 0;    vectors[41][0] = -7; vectors[41][1] = -5; vectors[41][2] = 0;
    // E (42-49)
    vectors[42][0] = -4; vectors[42][1] = -1; vectors[42][2] = 0;    vectors[43][0] = -4; vectors[43][1] = -5; vectors[43][2] = 0;    vectors[44][0] = -4; vectors[44][1] = -1; vectors[44][2] = 0;
    vectors[45][0] = -2; vectors[45][1] = -1; vectors[45][2] = 0;    vectors[46][0] = -4; vectors[46][1] = -3; vectors[46][2] = 0;    vectors[47][0] = -2; vectors[47][1] = -3; vectors[47][2] = 0;
    vectors[48][0] = -4; vectors[48][1] = -5; vectors[48][2] = 0;    vectors[49][0] = -2; vectors[49][1] = -5; vectors[49][2] = 0;
    // A (50-57)
    vectors[50][0] = 0; vectors[50][1] = -1; vectors[50][2] = 0;    vectors[51][0] = 2; vectors[51][1] = -1; vectors[51][2] = 0;    vectors[52][0] = 0; vectors[52][1] = -1; vectors[52][2] = 0;
    vectors[53][0] = 0; vectors[53][1] = -5; vectors[53][2] = 0;    vectors[54][0] = 2; vectors[54][1] = -1; vectors[54][2] = 0;    vectors[55][0] = 2; vectors[55][1] = -5; vectors[55][2] = 0;
    vectors[56][0] = 0; vectors[56][1] = -3; vectors[56][2] = 0;    vectors[57][0] = 2; vectors[57][1] = -3; vectors[57][2] = 0;
    // R (58-67)
    vectors[58][0] = 4; vectors[58][1] = -1; vectors[58][2] = 0;    vectors[59][0] = 6; vectors[59][1] = -1; vectors[59][2] = 0;    vectors[60][0] = 4; vectors[60][1] = -1; vectors[60][2] = 0;
    vectors[61][0] = 4; vectors[61][1] = -5; vectors[61][2] = 0;    vectors[62][0] = 6; vectors[62][1] = -1; vectors[62][2] = 0;    vectors[63][0] = 6; vectors[63][1] = -3; vectors[63][2] = 0;
    vectors[64][0] = 4; vectors[64][1] = -3; vectors[64][2] = 0;    vectors[65][0] = 6; vectors[65][1] = -3; vectors[65][2] = 0;    vectors[66][0] = 5; vectors[66][1] = -4; vectors[66][2] = 0;
    vectors[67][0] = 6; vectors[67][1] = -5; vectors[67][2] = 0;
    // ! (68-69)
    vectors[68][0] = 9; vectors[68][1] = -1; vectors[68][2] = 0;    vectors[69][0] = 9; vectors[69][1] = -3; vectors[69][2] = 0;    vectors[70][0] = 9; vectors[70][1] = -5; vectors[70][2] = 0;
    vectors[71][0] = 9; vectors[71][1] = -5; vectors[71][2] = 0;
    */
    // 2 (36-41)
    vectors[36][0] = -8; vectors[36][1] = -1; vectors[36][2] = 0;    vectors[37][0] = -6; vectors[37][1] = -1; vectors[37][2] = 0;    vectors[38][0] = -6; vectors[38][1] = -1; vectors[38][2] = 0;
    vectors[39][0] = -8; vectors[39][1] = -5; vectors[39][2] = 0;    vectors[40][0] = -8; vectors[40][1] = -5; vectors[40][2] = 0;    vectors[41][0] = -6; vectors[41][1] = -5; vectors[41][2] = 0;
    // 0 (42-49)
    vectors[42][0] = -4; vectors[42][1] = -1; vectors[42][2] = 0;    vectors[43][0] = -2; vectors[43][1] = -1; vectors[43][2] = 0;    vectors[44][0] = -2; vectors[44][1] = -1; vectors[44][2] = 0;
    vectors[45][0] = -2; vectors[45][1] = -5; vectors[45][2] = 0;    vectors[46][0] = -2; vectors[46][1] = -5; vectors[46][2] = 0;    vectors[47][0] = -4; vectors[47][1] = -5; vectors[47][2] = 0;
    vectors[48][0] = -4; vectors[48][1] = -5; vectors[48][2] = 0;    vectors[49][0] = -4; vectors[49][1] = -1; vectors[49][2] = 0;    
    // 2 (50-55)
    vectors[50][0] = 0; vectors[50][1] = -1; vectors[50][2] = 0;    vectors[51][0] = 2; vectors[51][1] = -1; vectors[51][2] = 0;    vectors[52][0] = 2; vectors[52][1] = -1; vectors[52][2] = 0;
    vectors[53][0] = 0; vectors[53][1] = -5; vectors[53][2] = 0;    vectors[54][0] = 0; vectors[54][1] = -5; vectors[54][2] = 0;    vectors[55][0] = 2; vectors[55][1] = -5; vectors[55][2] = 0;
    // 6 (56-65)
    vectors[56][0] = 4; vectors[56][1] = -1; vectors[56][2] = 0;    vectors[57][0] = 6; vectors[57][1] = -1; vectors[57][2] = 0;    vectors[58][0] = 4; vectors[58][1] = -1; vectors[58][2] = 0;
    vectors[59][0] = 4; vectors[59][1] = -5; vectors[59][2] = 0;    vectors[60][0] = 4; vectors[60][1] = -5; vectors[60][2] = 0;    vectors[61][0] = 6; vectors[61][1] = -5; vectors[61][2] = 0;
    vectors[62][0] = 6; vectors[62][1] = -3; vectors[62][2] = 0;    vectors[63][0] = 6; vectors[63][1] = -5; vectors[63][2] = 0;    vectors[64][0] = 4; vectors[64][1] = -3; vectors[64][2] = 0;
    vectors[65][0] = 6; vectors[65][1] = -3; vectors[65][2] = 0;    
  }

  FastLED.clear();
 // fadeToBlackBy (leds,NUM_LEDS, 150);

  drawText();              
  ScaleAndRotate(2.0,0.9,0,0,1,4,5); //rotate X,Y - off, just Rotate Z, rotate angle +2
//  delay(10);
}
//////////////////////////////////////// HAPPY 2026 (YEAR)

//////////// Icosahedron //////////////

void drawIcosahedron() {
  // North (5 triangles)
  drawTriangleIfVisible(0, 1, 2);
  drawTriangleIfVisible(0, 2, 3);
  drawTriangleIfVisible(0, 3, 4);
  drawTriangleIfVisible(0, 4, 5);
  drawTriangleIfVisible(0, 5, 1);
  
  // South (5 triangles)
  drawTriangleIfVisible(11, 7, 6);
  drawTriangleIfVisible(11, 8, 7);
  drawTriangleIfVisible(11, 9, 8);
  drawTriangleIfVisible(11, 10, 9);
  drawTriangleIfVisible(11, 6, 10);
  
  // Middle (10 triangles)
  drawTriangleIfVisible(1, 6, 2);
  drawTriangleIfVisible(2, 6, 7);
  drawTriangleIfVisible(2, 7, 3);
  drawTriangleIfVisible(3, 7, 8);
  drawTriangleIfVisible(3, 8, 4);
  drawTriangleIfVisible(4, 8, 9);
  drawTriangleIfVisible(4, 9, 5);
  drawTriangleIfVisible(5, 9, 10);
  drawTriangleIfVisible(5, 10, 1);
  drawTriangleIfVisible(1, 10, 6);
}

void Icosahedron() {

  if(loadingFlag) {
    loadingFlag = false;
    dotsCount = 12; //icosahedron
    vectors[0][0] = 0.0;    vectors[0][1] = 8.0;    vectors[0][2] = 0.0;
    vectors[1][0] = 7.5;    vectors[1][1] = 3.0;    vectors[1][2] = 0.0;
    vectors[2][0] = 2.3;    vectors[2][1] = 3.0;    vectors[2][2] = 7.2;
    vectors[3][0] = -6.1;   vectors[3][1] = 3.0;    vectors[3][2] = 4.4;
    vectors[4][0] = -6.1;   vectors[4][1] = 3.0;    vectors[4][2] = -4.4;
    vectors[5][0] = 2.3;    vectors[5][1] = 3.0;    vectors[5][2] = -7.2;
    vectors[6][0] = 7.5;    vectors[6][1] = -3.0;   vectors[6][2] = 0.0;
    vectors[7][0] = 2.3;    vectors[7][1] = -3.0;   vectors[7][2] = 7.2;
    vectors[8][0] = -6.1;   vectors[8][1] = -3.0;   vectors[8][2] = 4.4;
    vectors[9][0] = -6.1;   vectors[9][1] = -3.0;   vectors[9][2] = -4.4;
    vectors[10][0] = 2.3;   vectors[10][1] = -3.0;  vectors[10][2] = -7.2;
    vectors[11][0] = 0.0;   vectors[11][1] = -8.0;  vectors[11][2] = 0.0;
  }

  FastLED.clear();
//  fadeToBlackBy (leds,NUM_LEDS, 100);
  drawIcosahedron();  
  ScaleAndRotate(1.7, 0.9,1,1,1,-3,6);
//  delay(10);
}
///////////////////////////////// Icosahedron

/////////// Cube3Ddots ///////////

void initCube26() {
  int pointIndex = 0;
  
  int8_t coords[] = {-4, 0, 4};
  
  for (int8_t x = 0; x < 3; x++) {
    for (int8_t y = 0; y < 3; y++) {
      for (int8_t z = 0; z < 3; z++) {
        if (!(x == 1 && y == 1 && z == 1)) {
          vectors[pointIndex][0] = coords[x];
          vectors[pointIndex][1] = coords[y];
          vectors[pointIndex][2] = coords[z];
          pointIndex++;
}}}}}

void Cube3Ddots() {
   if(loadingFlag) {
    loadingFlag = false;
    dotsCount = 26; //3*3*3-1. внутреннюю точку убираем
    initCube26();    
  }
  FastLED.clear();
  //fadeToBlackBy (leds,NUM_LEDS, 100);
  drawWhiteToRedGradient();              
  ScaleAndRotate(2.2, 0.7,1,1,1,-3,7);
 // delay(10);
}
///////////////////////////////// Cube3Ddots

/////////// Christmas Tree 3D //////

//3d-Spirale
void initSpirale() {
  const float spiralSpeed = 5.0;
  const float height = 10.0;
  const float startRadius = 0.2;
  const float endRadius = 4.0;  //3 или 4, хз пока, 4 вроде широковато.
  const float radiusGrowthPower =1.0;
  
  for (byte i = 0; i < dotsCount; i++) {
    float t = i / ((float)dotsCount - 1.0);
    float theta = spiralSpeed * 2.0 * PI * t;
    float r = startRadius + (endRadius - startRadius) * pow(t, radiusGrowthPower);
    float h = height * (t - 0.5);
    
    vectors[i][0] = r * cos(theta);
    vectors[i][1] = h;
    vectors[i][2] = r * sin(theta);
  }
}

//Green gradient - christmas tree
void GreenGradient() {
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);

    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {

      float z = vectors[i][2];
      int idx = XY(x, y);
      
      CRGB pixel_color =
        (z > 2)  ? CRGB(0, 255, 0) :
        (z > 0)  ? CRGB(0, 230, 0) :
        (z > -1) ? CRGB(0, 180, 0) : 
        (z > -2) ? CRGB(0, 150, 0) :         
        (z > -3) ? CRGB(0, 110, 0) :         
                   CRGB(0, 80, 0);      

    // Random white sparkles
    if (random(7) == 5)   pixel_color = CRGB(255, 255, 255); 
   
    // red top
    if (i >= 0 && i <= 8) pixel_color = CRGB(255, 0, 0); 
    
    leds[idx] = pixel_color;
    }
  }
}

void ChristmasTree3D() {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = 72;
    initSpirale(); //spirale
  }
  FastLED.clear();
  GreenGradient();   //Green gradient - Christmas Tree
  //fadeToBlackBy (leds,NUM_LEDS, 150);
  ScaleAndRotate(3.0, 1.0, 1,1,1,-2,9);
  //delay(10);
}

///////////////////////////////// Christmas Tree 3D

//////////// Text '2026' spherical ////

void SphericalText3D() {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = 30;

  //2
  vectors[0][0] = -8.4f; vectors[0][1] = 2.2f; vectors[0][2] = -1.828f; vectors[1][0] = -5.7f; vectors[1][1] = 2.2f; vectors[1][2] = 0.424f; vectors[2][0] = -5.7f; vectors[2][1] = 2.2f; vectors[2][2] = 0.424f;
  vectors[3][0] = -8.4f; vectors[3][1] = -2.2f; vectors[3][2] = -1.828f; vectors[4][0] = -8.4f; vectors[4][1] = -2.2f; vectors[4][2] = -1.828f; vectors[5][0] = -5.7f; vectors[5][1] = -2.2f; vectors[5][2] = 0.424f;
  //0
  vectors[6][0] = -3.9f; vectors[6][1] = 2.2f; vectors[6][2] = 1.842f; vectors[7][0] = -1.8f; vectors[7][1] = 2.2f; vectors[7][2] = 2.552f; vectors[8][0] = -1.8f; vectors[8][1] = 2.2f; vectors[8][2] = 2.552f;
  vectors[9][0] = -1.8f; vectors[9][1] = -2.2f; vectors[9][2] = 2.552f; vectors[10][0] = -1.8f; vectors[10][1] = -2.2f; vectors[10][2] = 2.552f; vectors[11][0] = -3.9f; vectors[11][1] = -2.2f; vectors[11][2] = 1.842f;
  vectors[12][0] = -3.9f; vectors[12][1] = -2.2f; vectors[12][2] = 1.842f; vectors[13][0] = -3.9f; vectors[13][1] = 2.2f; vectors[13][2] = 1.842f; 
  //2
  vectors[14][0] = 0.3f; vectors[14][1] = 2.2f; vectors[14][2] = 2.917f; vectors[15][0] = 2.4f; vectors[15][1] = 2.2f; vectors[15][2] = 2.552f; vectors[16][0] = 2.4f; vectors[16][1] = 2.2f; vectors[16][2] = 2.552f;
  vectors[17][0] = 0.3f; vectors[17][1] = -2.2f; vectors[17][2] = 2.917f;vectors[18][0] = 0.3f; vectors[18][1] = -2.2f; vectors[18][2] = 2.917f; vectors[19][0] = 2.4f; vectors[19][1] = -2.2f; vectors[19][2] = 2.552f;
  //6
  vectors[20][0] = 4.2f; vectors[20][1] = 2.2f; vectors[20][2] = 1.842f; vectors[21][0] = 6.3f; vectors[21][1] = 2.2f; vectors[21][2] = 0.424f; vectors[22][0] = 4.2f; vectors[22][1] = 2.2f; vectors[22][2] = 1.842f;
  vectors[23][0] = 4.2f; vectors[23][1] = -2.2f; vectors[23][2] = 1.842f; vectors[24][0] = 4.2f; vectors[24][1] = -2.2f; vectors[24][2] = 1.842f; vectors[25][0] = 6.3f; vectors[25][1] = -2.2f; vectors[25][2] = 0.424f;
  vectors[26][0] = 6.3f; vectors[26][1] = 0.0f; vectors[26][2] = 0.424f; vectors[27][0] = 6.3f; vectors[27][1] = -2.2f; vectors[27][2] = 0.424f; vectors[28][0] = 4.2f; vectors[28][1] = 0.0f; vectors[28][2] = 1.842f;
  vectors[29][0] = 6.3f; vectors[29][1] = 0.0f; vectors[29][2] = 0.424f;
}

  FastLED.clear();

  drawText();              
  ScaleAndRotate(2.0,1.5,1,1,1,-3,7); 
  delay(10);
}
////////////////////////////////////// Text 2026! spherical 

//////////////HAPPY YEAR! //////////// spherical

void drawLineWithClipping(int8_t x1, int8_t y1, float z1, int8_t x2, int8_t y2, float z2) {

  if (z1 >= 0 && z2 >= 0) { Line_color(x1, y1, x2, y2, CRGB(0xFF, 0xFF, 0xFF));  return; } //Just White
  if (z1 < 0 && z2 < 0) { Line_color(x1, y1, x2, y2, CRGB(0x60, 0x00, 0x00)); return; } //Just Red
  
  float t = -z2 / (z1 - z2); // if z = 0
  
  // interpolate
  int8_t x_mid = x1 + (int8_t)(t * (x2 - x1));
  int8_t y_mid = y1 + (int8_t)(t * (y2 - y1));
  
  // draw with diff.colors
  Line_color(x1, y1, x_mid, y_mid, CRGB(0xFF, 0xFF, 0xFF)); // White (z>=0)
  Line_color(x_mid, y_mid, x2, y2, CRGB(0x60, 0x00, 0x00));   // Red (z<0)  
}

void drawTextGrad() {
  int totalLines = dotsCount / 2; 
  
  for(byte line = 0; line < totalLines; line++) {
    byte startIdx = line * 2;
    byte endIdx = line * 2 + 1;
    
    float* p1 = vectors[startIdx];
    float* p2 = vectors[endIdx];
    
    float z1_draw = (p1[2] < 0) ? -p1[2] : p1[2];
    float z2_draw = (p2[2] < 0) ? -p2[2] : p2[2];
    
    // min, avoiding zero div
    if (z1_draw < 0.01f) z1_draw = 0.01f;
    if (z2_draw < 0.01f) z2_draw = 0.01f;
    
    int8_t sx1 = translateX(p1[0], z1_draw);
    int8_t sy1 = translateY(p1[1], z1_draw);
    int8_t sx2 = translateX(p2[0], z2_draw);
    int8_t sy2 = translateY(p2[1], z2_draw);
    
    // Check whether line even partly on the screen
    if ((sx1 < 0 && sx2 < 0) || (sx1 >= WIDTH && sx2 >= WIDTH) ||
        (sy1 < 0 && sy2 < 0) || (sy1 >= HEIGHT && sy2 >= HEIGHT)) {
      continue; // out of screen
    }
    
    drawLineWithClipping(sx1, sy1, p1[2], sx2, sy2, p2[2]);
  }
}

void HappyYear3D() {

  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = 72; //72

    // H (x: 0, 4) 0°, 28.57°
    vectors[0][0] = 5.00; vectors[0][1] = 1.00; vectors[0][2] = 0.00;   vectors[1][0] = 5.00; vectors[1][1] = -2.00; vectors[1][2] = 0.00;   vectors[2][0] = 4.39; vectors[2][1] = 1.00; vectors[2][2] = -2.39;
    vectors[3][0] = 4.39; vectors[3][1] = -2.00; vectors[3][2] = -2.39;   vectors[4][0] = 5.00; vectors[4][1] = -0.50; vectors[4][2] = 0.00;   vectors[5][0] = 4.39; vectors[5][1] = -0.50; vectors[5][2] = -2.39;
    
    // A (x: 5, 9) 35.71°, 64.29°
    vectors[6][0] = 4.06; vectors[6][1] = 1.00; vectors[6][2] = -2.91;   vectors[7][0] = 2.91; vectors[7][1] = 1.00; vectors[7][2] = -4.06;   vectors[8][0] = 4.06; vectors[8][1] = 1.00; vectors[8][2] = -2.91;
    vectors[9][0] = 4.06; vectors[9][1] = -2.00; vectors[9][2] = -2.91;   vectors[10][0] = 2.91; vectors[10][1] = 1.00; vectors[10][2] = -4.06;   vectors[11][0] = 2.91; vectors[11][1] = -2.00; vectors[11][2] = -4.06;
    vectors[12][0] = 4.06; vectors[12][1] = -0.50; vectors[12][2] = -2.91;   vectors[13][0] = 2.91; vectors[13][1] = -0.50; vectors[13][2] = -4.06;
    
    // P (x: 10, 14) 71.43°, 100.00°
    vectors[14][0] = 1.59; vectors[14][1] = 1.00; vectors[14][2] = -4.75;   vectors[15][0] = 0.00; vectors[15][1] = 1.00; vectors[15][2] = -5.00;   vectors[16][0] = 1.59; vectors[16][1] = 1.00; vectors[16][2] = -4.75;
    vectors[17][0] = 1.59; vectors[17][1] = -2.00; vectors[17][2] = -4.75;   vectors[18][0] = 0.00; vectors[18][1] = 1.00; vectors[18][2] = -5.00;   vectors[19][0] = 0.00; vectors[19][1] = -0.50; vectors[19][2] = -5.00;  
    vectors[20][0] = 1.59; vectors[20][1] = -0.50; vectors[20][2] = -4.75;   vectors[21][0] = 0.00; vectors[21][1] = -0.50; vectors[21][2] = -5.00;
    
    // P (x: 15, 19) 107.14°, 135.71°
    vectors[22][0] = -1.44; vectors[22][1] = 1.00; vectors[22][2] = -4.79;    vectors[23][0] = -2.91; vectors[23][1] = 1.00; vectors[23][2] = -4.06;    vectors[24][0] = -1.44; vectors[24][1] = 1.00; vectors[24][2] = -4.79;
    vectors[25][0] = -1.44; vectors[25][1] = -2.00; vectors[25][2] = -4.79;    vectors[26][0] = -2.91; vectors[26][1] = 1.00; vectors[26][2] = -4.06;    vectors[27][0] = -2.91; vectors[27][1] = -0.50; vectors[27][2] = -4.06;
    vectors[28][0] = -1.44; vectors[28][1] = -0.50; vectors[28][2] = -4.79;    vectors[29][0] = -2.91; vectors[29][1] = -0.50; vectors[29][2] = -4.06;
    
    // Y (x: 20, 24) 142.86°, 171.43°
    vectors[30][0] = -3.68; vectors[30][1] = 1.00; vectors[30][2] = -3.53;    vectors[31][0] = -4.39; vectors[31][1] = -0.50; vectors[31][2] = -2.39;    vectors[32][0] = -4.75; vectors[32][1] = 1.00; vectors[32][2] = -1.59;
    vectors[33][0] = -4.39; vectors[33][1] = -0.50; vectors[33][2] = -2.39;    vectors[34][0] = -4.39; vectors[34][1] = -0.50; vectors[34][2] = -2.39;    vectors[35][0] = -4.39; vectors[35][1] = -2.00; vectors[35][2] = -2.39;
    
    // Y (x: 28, 32) 200.00°, 228.57°
    vectors[36][0] = -4.70; vectors[36][1] = 1.00; vectors[36][2] = 1.71;    vectors[37][0] = -4.95; vectors[37][1] = -0.50; vectors[37][2] = 0.86;    vectors[38][0] = -5.00; vectors[38][1] = 1.00; vectors[38][2] = 0.00;
    vectors[39][0] = -4.95; vectors[39][1] = -0.50; vectors[39][2] = 0.86;    vectors[40][0] = -4.95; vectors[40][1] = -0.50; vectors[40][2] = 0.86;    vectors[41][0] = -4.95; vectors[41][1] = -2.00; vectors[41][2] = 0.86;
    
    // E (x: 33, 37) 235.71°, 264.29°
    vectors[42][0] = -4.06; vectors[42][1] = 1.00; vectors[42][2] = 2.91;    vectors[43][0] = -4.06; vectors[43][1] = -2.00; vectors[43][2] = 2.91;    vectors[44][0] = -4.06; vectors[44][1] = 1.00; vectors[44][2] = 2.91;
    vectors[45][0] = -2.91; vectors[45][1] = 1.00; vectors[45][2] = 4.06;    vectors[46][0] = -4.06; vectors[46][1] = -0.50; vectors[46][2] = 2.91;    vectors[47][0] = -2.91; vectors[47][1] = -0.50; vectors[47][2] = 4.06;
    vectors[48][0] = -4.06; vectors[48][1] = -2.00; vectors[48][2] = 2.91;    vectors[49][0] = -2.91; vectors[49][1] = -2.00; vectors[49][2] = 4.06;
    
    // A (x: 38, 42) 271.43°, 300.00°
    vectors[50][0] = -2.29; vectors[50][1] = 1.00; vectors[50][2] = 4.54;    vectors[51][0] = -1.00; vectors[51][1] = 1.00; vectors[51][2] = 4.90;    vectors[52][0] = -2.29; vectors[52][1] = 1.00; vectors[52][2] = 4.54;
    vectors[53][0] = -2.29; vectors[53][1] = -2.00; vectors[53][2] = 4.54;    vectors[54][0] = -1.00; vectors[54][1] = 1.00; vectors[54][2] = 4.90;    vectors[55][0] = -1.00; vectors[55][1] = -2.00; vectors[55][2] = 4.90;
    vectors[56][0] = -2.29; vectors[56][1] = -0.50; vectors[56][2] = 4.54;    vectors[57][0] = -1.00; vectors[57][1] = -0.50; vectors[57][2] = 4.90;
    
    // R (x: 43, 47) 307.14°, 335.71°
    vectors[58][0] = 0.00; vectors[58][1] = 1.00; vectors[58][2] = 5.00;    vectors[59][0] = 1.59; vectors[59][1] = 1.00; vectors[59][2] = 4.75;    vectors[60][0] = 0.00; vectors[60][1] = 1.00; vectors[60][2] = 5.00;
    vectors[61][0] = 0.00; vectors[61][1] = -2.00; vectors[61][2] = 5.00;    vectors[62][0] = 1.59; vectors[62][1] = 1.00; vectors[62][2] = 4.75;    vectors[63][0] = 1.59; vectors[63][1] = -0.50; vectors[63][2] = 4.75;
    vectors[64][0] = 0.00; vectors[64][1] = -0.50; vectors[64][2] = 5.00;    vectors[65][0] = 1.59; vectors[65][1] = -0.50; vectors[65][2] = 4.75;    vectors[66][0] = 0.80; vectors[66][1] = -0.50; vectors[66][2] = 4.94;
    vectors[67][0] = 1.59; vectors[67][1] = -2.00; vectors[67][2] = 4.75;
    
    // ! (x: 48) угол: 342.86°
    vectors[68][0] = 3.37; vectors[68][1] = 1.00; vectors[68][2] = 3.75;    vectors[69][0] = 3.37; vectors[69][1] = -0.50; vectors[69][2] = 3.75;
    vectors[70][0] = 3.37; vectors[70][1] = -2.00; vectors[70][2] = 3.75;    vectors[71][0] = 3.37; vectors[71][1] = -2.00; vectors[71][2] = 3.75;
  }
  
  FastLED.clear();
  //fadeToBlackBy (leds,NUM_LEDS, 100);
  drawTextGrad();
  ScaleAndRotate(2.7, 1.7,1,1,1,1,4);
  //delay(10);
}
////////////////////////////////////// HAPPY YEAR