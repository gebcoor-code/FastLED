#include <SSD1306Wire.h>
#include "font.h"

SSD1306Wire oled(0x3c, 14, 12); // SDA , SCL

#define WIDTH 128
#define HEIGHT 64

#define rotAngle 15 //вращение по Z вверх и вниз

bool loadingFlag = true;

//string vars
#define LET_WIDTH 5       // ширина буквы шрифта
#define dW 31     // ширина окна, pt. хз, если ставить 32, то не работает (черный экран). при этом 16 и uint16 - норм
#define dH 8    // высота окна, pt
uint32_t bitSub[dH]; //битовая подложка
String text = "3D-SCROLLING STRING. !@#$%^&*(){}[]~` 1234567890.     "; 

uint8_t chari = 0; //текущий символ
uint8_t columni = 0;
bool needSpace = false; //так реализовал просветы между символами.

//3D vars
#define dots dW*dH
float vectors[dots][3];

float perspective = 60.0;
int8_t deltaX, deltaY, deltaZ=2, iter = rotAngle;
float scale3D = 2.5;
float scaleDirection = 0.05;
byte dotsCount;
#define stepDirection 0.05

//boolean fullTextFlag = false; //пока без триггера окончания, потом допилю.

void setup() {
  oled.init(); //  Инициализируем дисплей
//  oled.flipScreenVertically(); // Устанавливаем зеркальное отображение экрана, к примеру, удобно, если вы хотите желтую область сделать вверху
}

int translateX(double x, double z) {
  float scaledX = x * scale3D;
  float scaledZ = z * scale3D;  
  int tt = (int)((scaledX + WIDTH/2) + (scaledZ * (scaledX / perspective)));
  return (tt>WIDTH-1) ? WIDTH-1:
         (tt<0)       ? 0:
                        tt;
}

int translateY(double y, double z) {
  float scaledY = y * scale3D;
  float scaledZ = z * scale3D;  
  int tt = (int8)((scaledY + HEIGHT/2) + (scaledZ * (scaledY / perspective)));
  return (tt>HEIGHT-1) ? HEIGHT-1:
         (tt<0)        ? 0:
                         tt;
}

void rotateX(int angle) {
  double rad, cosa, sina, Yn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++) {
    Yn = (vectors[i][1] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][1] * sina) + (vectors[i][2] * cosa);
    vectors[i][1] = Yn;
    vectors[i][2] = Zn;
  }
}

void rotateY(int angle) {
  double rad, cosa, sina, Xn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++)
  {
    Xn = (vectors[i][0] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][0] * sina) + (vectors[i][2] * cosa);
    vectors[i][0] = Xn;
    vectors[i][2] = Zn;
  }
}

void rotateZ(int angle) {
  double rad, cosa, sina, Xn, Yn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++) {
    Xn = (vectors[i][0] * cosa) - (vectors[i][1] * sina);
    Yn = (vectors[i][0] * sina) + (vectors[i][1] * cosa);
    vectors[i][0] = Xn;
    vectors[i][1] = Yn;
  }
}

void ScaleAndRotate_Zonly(float maxSc, float minSc) {

  if (iter == 0) {
    deltaZ *=-1;
    iter = rotAngle*2; //+-rotAngle
  }
  scale3D += scaleDirection;
  if (scale3D >= maxSc) {
    scale3D = maxSc;
    scaleDirection = -stepDirection;
  } else if (scale3D <= minSc) {
    scale3D = minSc;
    scaleDirection = stepDirection;
  }
  rotateZ(deltaZ);
  iter--;
}

uint8_t getFont(uint8_t font, uint8_t row) {
  if ((font>=0x41 && font<=0x5A) || (font>=0xC0 && font<=0xDF)) font &= 0xDF;
  font = font - '0' + 0x10;
  
  if (font <= 0x5A) 
    return pgm_read_byte(&(fontHEX[font][row]));
  else if (font >= 0x70 && font <= 0x9F) {
    return pgm_read_byte(&(fontHEX[font - 0x2F][row]));
  } 
  else { // font >= 0x60 && font <= 0x6F
    return pgm_read_byte(&(fontHEX[font - 0x0F][row]));
  }
}

void setPixel(uint8_t x, uint8_t y, bool state) {
  if (x >= dW || y >= dH) return;
  if (state) bitSub[y] |= (1 << x);
  else       bitSub[y] &= ~(1 << x);
}

bool getPixel(uint8_t x, uint8_t y) {
  if (x >= dW || y >= dH) return false;
  return (bitSub[y] >> x) & 0x01;
}

void shiftDisplayLeft() {
  for (uint8_t y = 0; y < dH; y++) bitSub[y] >>= 1;
}

void updateScrollingText() {
  shiftDisplayLeft();
  
  if (needSpace) {
    for (uint8_t y = 0; y < dH; y++) bitSub[y] &= ~(1 << (dW - 1));
    needSpace = false;
    return;
  }
  
  while (chari < text.length() && (byte)text[chari] > 0xBF) {
    chari++;
  }
  
  if (chari >= text.length()) {
    chari = 0;
    columni = 0;
    needSpace = true;
    return;
  }
  
  uint8_t charCode = (uint8_t)text[chari];
  uint8_t columnData = getFont(charCode, columni);
  
  for (uint8_t y = 0; y < dH; y++) {
    bitSub[y] &= ~(1 << (dW - 1));
    bool pixel = (columnData >> (dH - 1 - y)) & 0x01;
     if (pixel) bitSub[y] |= (1 << (dW - 1));
  }
  
 // columni++;
  
  if (++columni >= LET_WIDTH) {
    columni = 0;
    chari++;
    needSpace = true;
  }
}

void connectPoints(uint8_t i1, uint8_t i2) {
  int8_t x1 = translateX(vectors[i1][0], vectors[i1][2]);
  int8_t y1 = translateY(vectors[i1][1], vectors[i1][2]);
  int8_t x2 = translateX(vectors[i2][0], vectors[i2][2]);
  int8_t y2 = translateY(vectors[i2][1], vectors[i2][2]);
  
/*  if (x1 >= 0 && x1 < WIDTH && y1 >= 0 && y1 < HEIGHT &&
      x2 >= 0 && x2 < WIDTH && y2 >= 0 && y2 < HEIGHT) */
    oled.drawLine(x1, y1, x2, y2);
}

void drawText3DConnected() {

/*
  // подложка под буквы
  for (byte i = 0; i < dotsCount; i+=2) { //7
    if (!getPixel(i % dW, i / dW)) {
      int8_t x = translateX(vectors[i][0], vectors[i][2])+random(15)-7;
      int8_t y = translateY(vectors[i][1], vectors[i][2])+random(15)-7;
      
      if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT && vectors[i][2]>=0) 
        oled.setPixel(x,y);
    }
  }*/

  // Соединяем соседние точки на подложке. 0 - право-низ, направление инкремента - вверх и влево
  for (byte i = 0; i < dotsCount; i++) {
    uint8_t dRow = i / dW;
    uint8_t dCol = i % dW;
    
    if (!getPixel(dCol, dRow)) continue;
    
    // слева
    if ((dCol < dW - 1) && getPixel(dCol + 1, dRow))
      connectPoints(i, i + 1);
    
    // сверху
    if ((dRow < dH - 1) && getPixel(dCol, dRow + 1))
      connectPoints(i, i + dW);
    
    // слева-сверху, если (x+1,y+1), но !(x,y+1) и !(x+1,y)
    if (dCol < dW - 1 && dRow < dH - 1 && getPixel(dCol + 1, dRow + 1) && !getPixel(dCol,dRow+1) && !getPixel(dCol+1,dRow))
        connectPoints(i, i + dW + 1);
    
    // справа-сверху, если (x-1,y+1), но !(x-1,y) и !(x,y+1)
    if (dCol > 0 && dRow < dH - 1 && getPixel(dCol - 1, dRow + 1) && !getPixel(dCol-1,dRow) && !getPixel(dCol,dRow+1))
        connectPoints(i, i + dW - 1);
  }
}

void initSphereVectors(float radius) {
  uint8_t i = 0;
  
  for (uint8_t row = 0; row < dH; row++) {
    for (uint8_t col = 0; col < dW; col++) {
      //инвертируем здесь
      //float u = (float)(dW - 1 - col) / (dW - 1);
      float v = (float)(dH - 1 - row) / (dH - 1);
      
      //без инверсии
      float u = (float)col / (dW - 1);
      //float v = (float)row / (dH - 1);

      //задаем умеренную кривизну, для лучшей читаемости
      float phi = u * PI * 0.9;           // 60% половины сферы //0.6 - оптимально, сферичность по X. Если 1.0 - образуется заворот по сфере справа
      float theta = v * PI * 0.4;         // 40% от полюса к полюсу 0.4 - оптимально, сферичность по Y
      
      // Сдвиг по сфере по X и по Y
      phi += PI * 0.1; //0.2-оптимально  по X. Заворот влево, если меньше 0.2
      theta += PI * 0.3; //0.3-оптимально по Y
      
      vectors[i][0] = radius * sin(theta) * cos(phi);  // x
      vectors[i][1] = radius * cos(theta);             // y  
      vectors[i][2] = radius * sin(theta) * sin(phi);  // z
      
      //масштабирование
      vectors[i][0] *= 2.3;  // по X, для OLED128
      vectors[i][1] *= 1;  // по Y, для OLED64
      
      i++;
    }
  }
}
void initSine(float amplitudeY, float frequencyX) {
  uint8_t i = 0;
  
  // Диапазон по X: -5..5 (ширина 10)
  // Диапазон по Y будет зависеть от синуса
  
  for (uint8_t row = 0; row < dH; row++) {
    for (uint8_t col = 0; col < dW; col++) {
      // X от -5 до 5
      float x = 5.0 - 10.0 * col / (dW - 1); // X mirrored, as renderToScreen() does (WIDTH-1-x); float, map() is integer
      
      // Базовый Y (без синуса) от -5 до 5
      float baseY = -5.0 + 10.0 * row / (dH - 1);
      
      // Добавляем синус к Y (по X)
      // frequencyX определяет сколько периодов синуса уместится в диапазон X
      float y = baseY + amplitudeY * sin(x * frequencyX);
      
      // Z можно оставить 0 или добавить небольшую глубину
      float z = 0.0;  // Плоская по Z
      // Или небольшая рябь:
      // float z = 0.3 * sin(x * 2.0) * cos(y * 1.5);
      
      vectors[i][0] = x;
      vectors[i][1] = y;
      vectors[i][2] = z;
      
      i++;
    }
  }
}

float sineTime = 0;

void initSineAnimated(float amplitudeX, float amplitudeY, float frequencyX, float frequencyY) {
  uint8_t i = 0;
  sineTime += 0.02;
  
  // Масштабы как выше
  float scaleX = 10;
  float scaleY = 8;   // Попробуй 1.5 если нужно выше
  float scaleZ = 2.0;
  
  for (uint8_t row = 0; row < dH; row++) {
    for (uint8_t col = 0; col < dW; col++) {
      // Инверсия по обеим осям
      //float u = (float)(dW - 1 - col) / (dW - 1);
      float u = (float)col / (dW - 1);
      float v = (float)(dH - 1 - row) / (dH - 1);
      
      float x = (u * 2.0 - 1.0) * scaleX;
      float y = (v * 2.0 - 1.0) * scaleY;
      
      // Анимированная синусоида
      float z = amplitudeX * sin(x * frequencyX + sineTime) + 
                amplitudeY * cos(y * frequencyY + sineTime * 0.6);
      
      vectors[i][0] = x;
      vectors[i][1] = y;
      vectors[i][2] = z * scaleZ;
      
      i++;
    }
  }
}

//для проверки, прямой вывод подложки
void renderToScreen() {
  for (uint8_t y = 0; y < dH; y++) {
    for (uint8_t x = 0; x < dW; x++) {
      if (getPixel(x, y)) {
//        uint8_t ledX = x+ WIDTH/2-2;
//        uint8_t ledY = y+ HEIGHT/2-2;
        if (x < WIDTH && y < HEIGHT)  oled.setPixel(WIDTH-1-x,y);
}}}}

void loop() {

  if (loadingFlag) {
    dotsCount=dots;
    loadingFlag=false;
    initSphereVectors(9); //10
    //initSphereVectorsWavy(9); //более менее, но надо тюнить
    //initSphereVectorsAnimated(9); //пока шляпа
    //initSine(2, 0.5);
  }  
  oled.clear();
  
  updateScrollingText();
    renderToScreen();
  drawText3DConnected();
  //ScaleAndRotate_Zonly(3, 0.5); 
  oled.display(); 
  delay(20);
}

