#include <SSD1306Wire.h>

SSD1306Wire oled(0x3c, 14, 12); // SDA - IO5 (D1), SCL - IO4 (D2) 

#define WIDTH 128
#define HEIGHT 64

bool loadingFlag = true;


//3D vars
#define dots 144
float vectors[dots][3];

float perspective = 60.0;
int8_t deltaX, deltaY, deltaZ=2, iter = 20;
float scale3D = 3;
float scaleDirection = 0.2;
byte dotsCount;
#define stepDirection 0.2


void setup() {
  oled.init(); //  Инициализируем дисплей
}

int translateX(double x, double z) {
  float scaledX = x * scale3D;
  float scaledZ = z * scale3D;  
  int tt = (int)((scaledX + WIDTH/2) + (scaledZ * (scaledX / perspective)));
  return (tt>WIDTH-1) ? WIDTH-1:
         (tt<0)       ? 0:
                        tt;
}

int translateY(double y, double z) {
  float scaledY = y * scale3D;
  float scaledZ = z * scale3D;  
  int tt = (int8)((scaledY + HEIGHT/2) + (scaledZ * (scaledY / perspective)));
  return (tt>HEIGHT-1) ? HEIGHT-1:
         (tt<0)        ? 0:
                         tt;
}

void rotateX(int angle) {
  double rad, cosa, sina, Yn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++) {
    Yn = (vectors[i][1] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][1] * sina) + (vectors[i][2] * cosa);
    vectors[i][1] = Yn;
    vectors[i][2] = Zn;
  }
}

void rotateY(int angle) {
  double rad, cosa, sina, Xn, Zn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++)
  {
    Xn = (vectors[i][0] * cosa) - (vectors[i][2] * sina);
    Zn = (vectors[i][0] * sina) + (vectors[i][2] * cosa);
    vectors[i][0] = Xn;
    vectors[i][2] = Zn;
  }
}

void rotateZ(int angle) {
  double rad, cosa, sina, Xn, Yn;
  rad = angle * PI / 180;
  cosa = cos(rad);
  sina = sin(rad);
  for (int i = 0; i < dotsCount; i++) {
    Xn = (vectors[i][0] * cosa) - (vectors[i][1] * sina);
    Yn = (vectors[i][0] * sina) + (vectors[i][1] * cosa);
    vectors[i][0] = Xn;
    vectors[i][1] = Yn;
  }
}

void ScaleAndRotate(float maxSc, float minSc, bool rX, bool rY, bool rZ, int8_t deltaAngle, int8_t maxAngle) {

  if (iter == 0) {
    deltaX = random(maxAngle) + deltaAngle;    deltaY = random(maxAngle) + deltaAngle;    deltaZ = random(maxAngle) + deltaAngle; //было исходно random(7)-3; теперь r(5)+2
//    if (deltaX==0) deltaX=1; if (deltaY==0) deltaY=1; if (deltaZ==0) deltaZ=1;
    if (abs(deltaX)<5) deltaX=5; if (abs(deltaY)<2) deltaY=5; if (abs(deltaZ)<2) deltaZ=5;
    iter = random(250) + 5;
  }
  scale3D += scaleDirection;
  if (scale3D >= maxSc) {
    scale3D = maxSc;
    scaleDirection = -stepDirection;
  } else if (scale3D <= minSc) {
    scale3D = minSc;
    scaleDirection = stepDirection;
  }
  if (rX) rotateX(deltaX);  if (rY) rotateY(deltaY);  if (rZ) rotateZ(deltaZ);
  iter--;
}

// uniform distribution using the golden ratio with offset for poles
void initUniformSpherePoints2() {
  const float goldenAngle = PI * (3.0 - sqrt(5.0));
  const float offset = 2.0 / dotsCount;
  
  for (byte i = 0; i < dotsCount; i++) {
    float y = (i * offset) - 1.0 + (offset * 0.5);  // y от -1 до 1
    float radiusAtY = sqrt(1.0 - y * y);
    float theta = goldenAngle * i;
    
    vectors[i][0] = 5.0 * cos(theta) * radiusAtY;
    vectors[i][1] = 5.0 * y;
    vectors[i][2] = 5.0 * sin(theta) * radiusAtY;
  }
}

//uniform dots (kind of Fibonacci)
void initSphereSpiraleUniform(const byte turns) {
  const float radius = 5.0;
  const float offset = 2.0 / dotsCount;
  const float increment = turns * 2.0 * PI * offset;
  
  for (byte i = 0; i < dotsCount; i++) {
    float y = 1.0 - (i * offset);
    
    if (i == 0) y = 0.999;
    else if (i == dotsCount-1) y = -0.999;
    float r = sqrt(1.0 - y*y);
    float phi = i * increment;
    
    vectors[i][0] = radius * r * cos(phi);
    vectors[i][1] = radius * y;
    vectors[i][2] = radius * r * sin(phi);
  }
}

//spirale classic 
void initSphereSpirale() {
  const float radius = 5.0;
  const int turns = 6;
  
  for (byte i = 0; i < dotsCount; i++) {
    float t = i / ((float)dotsCount - 1.0);
    float z = 1.0 - 2.0 * t;
    float r = sqrt(1.0 - z * z);  //x² + y² + z² = 1
    float phi = turns * 2.0 * PI * t;
    
    //to dec coords
    vectors[i][0] = radius * r * cos(phi);
    vectors[i][1] = radius * z;
    vectors[i][2] = radius * r * sin(phi);
  }
}

//3d-Spirale
void initSpirale() {
  const float spiralSpeed = 5.0;
  const float height = 10.0;
  const float startRadius = 0.2;
  const float endRadius = 4.0;
  const float radiusGrowthPower =1.0;
  
  for (byte i = 0; i < dotsCount; i++) {
    float t = i / ((float)dotsCount - 1.0);
    float theta = spiralSpeed * 2.0 * PI * t;
    float r = startRadius + (endRadius - startRadius) * pow(t, radiusGrowthPower);
    float h = height * (t - 0.5);
    
    vectors[i][0] = r * cos(theta);
    vectors[i][1] = h;
    vectors[i][2] = r * sin(theta);
  }
}

//White to red 3step gradient
void drawDots(bool all) {
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);
    
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
      float z = vectors[i][2];
      if (z > 0 || all) oled.setPixel(x,y);
    }
  }
}

#define AUTOPLAY_PERIOD 20
const uint32_t autoplayTime = ((long)AUTOPLAY_PERIOD * 1000);
uint32_t autoplayTimer;
byte aaa=5;
bool allDots = false;

void loop() {

  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = dots; 
    initUniformSpherePoints2(); //golden ratio over sphere surface with moved upper and lower points for better dots distribution
    //initSphereSpiraleUniform(); //Fibonacci Spirale
  }  
  oled.clear();
  drawDots(allDots);
  ScaleAndRotate(7, 2, 1,1,1,-3,12);

   if ((millis() - autoplayTimer > autoplayTime)) { 

    autoplayTimer = millis();
    byte  aa = random(2);
    if (aa!=aaa) {
      switch (aa) {
        case 0:
          initSpirale() ;
          allDots=true;
          break;
        case 1: 
          initUniformSpherePoints2();
          allDots=false;
          break;
      }
      aaa=aa;
    }
  }

  oled.display(); 
  delay(25);
}

