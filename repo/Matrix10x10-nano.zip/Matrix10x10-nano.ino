
// ************************ МАТРИЦА *************************

#define BRIGHTNESS 150      // (0-255) 150 default
#define CURRENT_LIMIT 1500  // лимит по току в миллиамперах, 0 - выключить лимит

#define WIDTH 10 
#define HEIGHT 10
#define SEGMENTS 1  // диодов в одном "пикселе" (для создания матрицы из кусков ленты)

#define COLOR_ORDER RGB  // порядок цветов на ленте. 

#define MATRIX_TYPE 0       // тип матрицы: 0 - зигзаг, 1 - параллельная
#define CONNECTION_ANGLE 0  // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний //для 16*16 0 only, для 12*12 нужно 2, чтобы снаружи бегущая была видна
#define STRIP_DIRECTION 0   // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз

#define MCU_TYPE 0  // микроконтроллер:
//                            0 - AVR (Arduino NANO/MEGA/UNO)
//                            1 - ESP8266 (NodeMCU, Wemos D1)
//                            2 - STM32 (Blue Pill)


#define LED_PIN 6     // пин ленты
#define NUM_LEDS WIDTH* HEIGHT* SEGMENTS

#include "FastLED.h"
CRGB leds[NUM_LEDS+1]; //+1 - виртуальный LED, в него XY() кидает все, что out of bonds

//// Buttons ///////////
const byte dpin = 3;
bool buttonPressed=false; //признак нажатия кнопки
bool buttonReleased100=false; //кнопка нажата 100мс, переключаем режим
bool buttonReleased1000=false; //кнопка нажата 1000мс, режим фиксируется
////////////////////////

//static const byte maxDim = max(WIDTH, HEIGHT);
boolean loadingFlag = true;
boolean fullTextFlag = false;

uint8_t thisMode = 0; //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define AUTOPLAY_PERIOD 20  // время между авто сменой режимов (секунды)
const uint32_t autoplayTime = ((long)AUTOPLAY_PERIOD * 1000);
const uint32_t buttonPressedTime = 1000;
uint32_t autoplayTimer;
uint32_t buttonPressedTimer;


void setup() {
  FastLED.addLeds<WS2812B, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS+1).setCorrection(TypicalLEDStrip);
  FastLED.setBrightness(BRIGHTNESS);
  if (CURRENT_LIMIT > 0) FastLED.setMaxPowerInVoltsAndMilliamps(5, CURRENT_LIMIT);
  FastLED.clear();
  FastLED.show();
  randomSeed(analogRead(0) + analogRead(1));  // пинаем генератор случайных чисел
  pinMode(dpin, INPUT_PULLUP); //read pin

}

void loop() {
  customRoutine();
}