#define MODES_AMOUNT 39 

void customModes() {
  switch (thisMode) {
    case 0: fillString("НА ПАМЯТЬ ОТ COOR@MAIL.RU 2026", CRGB::White); //+7%flash
        delay(30);
      break;            
    case 1: VUSpectrum(); //+
      break;
    case 2: Fire234(); //+
      break;
    case 3: SinDots(); //+-
      break;
    case 4: sparklesRoutine(); //+
      delay(100);
      break;
    case 5: draw3Dtriangle(); //+-, 
      break;		  	  	 
    case 6: ColorFrizzlesRoutine(); //+-
      delay(40);
      break;		  	  	 	  
    case 7: SineWavesRoutine(1); //+ типа rainbow, есть еще 0
      break;		  	  	 	 
    case 8: SineEffectsRoutine(0); //+- hypno spiral
      break;		  	  		  
    case 9: SineEffectsRoutine(1); //+ лучи вправо
      break;		  	  		  
    case 10: SineEffectsRoutine(2); //+ вращающиеся полосы
      delay(5);
      break;		  	  		  	  
    case 11: SineEffectsRoutine(6); //+ matrix style colored
      break;		  	  		  		  
    case 12: SineEffectsRoutine(8); //+ КАЧАЮЩИЕСЯ ПОЛОВИНЫ
      break;		  	  		 
    case 13: SineEffectsRoutine(11); //+ разбегающиеся круги типа raindrops
      break;		  	  		  		  
    case 14: SineEffectsRoutine(13); //+ бумеранговые полосы влево
      break;	  
    case 15: plasmaNoise();      //++ cool
      delay(50);
      break;
    case 16: SineEffectsRoutine(19); //++cool блуждающие полосы
      break;	        
    case 17: SimpleSinRoutine(); //+- sinus
      delay(10);
      break;	  
    case 18: madnessNoise(); //+
      delay(60);
      break;
    case 19: TwinklesRoutine(); //+
      break;
    case 20: Ex7Sparkles(); //+ мерцание точек по синусу
      delay(30);
      break;
    case 21: GridRoutine(); //+
      break;
    case 22: Drift(); //+
      break;
    case 23: Pride(); //++cool
      break;      
    case 24: Lotus(); //++cool
      delay(10);
      break;
   case 25: WineSparkles(); //+
      delay(30);
      break;
    case 26: Prismata(); //+-
      break;
    case 27: DriftRose(); //+
        break;
    case 28: radarRoutine(); //+
        break;    
    case 29: cloudNoise(); //+-
      delay(80);
      break;      
    case 30: SineWavesRoutine(0); //+
      break;		  	  	 	       
    case 31: SinSparkles(); //+
      break;
    case 32: SinShort(); //+
      break;
    case 33: China2(); //+ треугольники из огня влево-вправо    
      break;
    case 34: FireFlow(); //полосы ползающие, разные палитры
      break;
    case 35: rainbowNoise(); //+
      delay(80);
      break;
    case 36: Something(); //+ +5%, выворачивающийся глаз
      break;
    case 37: lavaNoise(); //+
      delay(80);
      break;
    case 38: zebraNoise(); //+
      delay(50);
      break;
  }
}

void customRoutine() {
  
    if (!digitalRead(dpin) && !buttonPressed && !buttonReleased100) { //если кнопка нажата, запускаем таймер. 
        buttonPressed = true;
        buttonReleased1000 = false;
        buttonPressedTimer = millis();
      }
      
      if ((millis() - buttonPressedTimer > 100) && buttonPressed && !buttonReleased100) {    //отсчитываем 100мс с момента нажатия и проверяем кнопку.

        if(digitalRead(dpin)) { //если через 100мс кнопка отпущена, то устанавливаем триггер переключения режима
          buttonPressed = false; 
          buttonReleased100 = true;
        }
      }

      if ((millis() - buttonPressedTimer > buttonPressedTime) && buttonPressed && !buttonReleased100 && !buttonReleased1000) {    //если через 1000мс кнопка все еще нажата - фиксируем текущий режим.
        if(!digitalRead(dpin)) { //если через 1000мс кнопка все еще нажата,
          buttonReleased1000 = true; //то фиксируем текущий режим
          FastLED.clear(); //моргаем экраном, как признак что режим зафиксировался
        }
        else { //если кнопка была отпущена до 1000мс - режим не фиксируется.
          buttonPressed = false;
        }
      }

  customModes();
  FastLED.show();
  
  if ((millis() - autoplayTimer > autoplayTime) || buttonReleased100 || fullTextFlag) {    //переключение по таймеру, по отпущенной кнопке 100мс или по признаку окончания бегущей строки

    buttonReleased100 = false;
    autoplayTimer = millis();
    if(!buttonReleased1000 || fullTextFlag) { //изменение по таймеру или по 100мс кнопке, только если не зажат текущий режим. Также если закончилась бегущая строка
      //thisMode++;
      //if (thisMode >= MODES_AMOUNT) thisMode = 0;
      //thisMode = (thisMode + 1) % MODES_AMOUNT; //так больше памяти отожрет
      thisMode = (++thisMode >= MODES_AMOUNT) ? 0 : thisMode; //а вот так вроде самое то
      loadingFlag = true;
      fullTextFlag = false;
      FastLED.clear();
    }
  }
}