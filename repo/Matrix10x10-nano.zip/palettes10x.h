byte palette = 0; //используется много где

////////////////////////////////////// массив палитр/////////////////////////////////////
static const TProgmemRGBPalette16 SodiumFireColors_p FL_PROGMEM = {CRGB::Black, 0x332100, 0x664200, 0x996300, 0xcc8400, CRGB::Orange, 0xffaf00, 0xffb900, 0xffc300, 0xffcd00, CRGB::Gold, 0xf8cd06, 0xf0c30d, 0xe9b913, 0xe1af1a, CRGB::Goldenrod};

// A red and white striped palette
// "CRGB::Gray" is used as white to keep the brightness more uniform.
const TProgmemRGBPalette16 RedWhite_p FL_PROGMEM ={  CRGB::Red,  CRGB::Red,  CRGB::Gray, CRGB::Gray,   CRGB::Red,  CRGB::Red,  CRGB::Gray, CRGB::Gray,   CRGB::Red,  CRGB::Red,  CRGB::Gray, CRGB::Gray,   CRGB::Red,  CRGB::Red,  CRGB::Gray, CRGB::Gray };

// A palette reminiscent of large 'old-school' C9-size tree lights in the five classic colors: red, orange, green, blue, and white.
#define C9_Red    0xFF8058
#define C9_Orange 0xFFA842
#define C9_Green  0xFFED92
#define C9_Blue   0xFFFFFF
#define C9_White  0xFFE5BE
const TProgmemRGBPalette16 RetroC9_p FL_PROGMEM = {C9_Red, C9_Orange, C9_Red, C9_Orange, C9_Orange, C9_Red, C9_Orange, C9_Red, C9_Green, C9_Green, C9_Green, C9_Green, C9_Blue, C9_Blue, C9_Blue, C9_White};
//const TProgmemRGBPalette16 Fire234_p = {0,0,0,0,/*black*/ 32,255,0,0,/*red*/ 190,255,255,9,/*yellow*/ 255,255,255,255 /*white*/}; //for fire234()
const TProgmemRGBPalette16 Zebra_p FL_PROGMEM = {CRGB::White,0,0,0,CRGB::White,0,0,0,CRGB::White,0,0,0,CRGB::White,0,0,0};

const TProgmemRGBPalette16 *pal_arr[] = {
  &PartyColors_p, //0
  &RainbowColors_p, //1
  &RainbowStripeColors_p, //2
  &LavaColors_p, //3
  &HeatColors_p, //4
  &CloudColors_p, //5
  &SodiumFireColors_p, //6
  &RetroC9_p, //7
  &RedWhite_p, //8
  &Zebra_p //9
  };

uint8_t countpal = sizeof(pal_arr)/sizeof(TProgmemRGBPalette16 *);
/////////////////////////////////////////////////////////////////////////
