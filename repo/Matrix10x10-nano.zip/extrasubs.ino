// **************** НАСТРОЙКА МАТРИЦЫ ****************
#if (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 0)
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y y

#elif (CONNECTION_ANGLE == 0 && STRIP_DIRECTION == 1)
#define _WIDTH HEIGHT
#define THIS_X y
#define THIS_Y x

#elif (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 0)
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y (HEIGHT - y - 1)

#elif (CONNECTION_ANGLE == 1 && STRIP_DIRECTION == 3)
#define _WIDTH HEIGHT
#define THIS_X (HEIGHT - y - 1)
#define THIS_Y x

#elif (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 2)
#define _WIDTH WIDTH
#define THIS_X (WIDTH - x - 1)
#define THIS_Y (HEIGHT - y - 1)

#elif (CONNECTION_ANGLE == 2 && STRIP_DIRECTION == 3)
#define _WIDTH HEIGHT
#define THIS_X (HEIGHT - y - 1)
#define THIS_Y (WIDTH - x - 1)

#elif (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 2)
#define _WIDTH WIDTH
#define THIS_X (WIDTH - x - 1)
#define THIS_Y y

#elif (CONNECTION_ANGLE == 3 && STRIP_DIRECTION == 1)
#define _WIDTH HEIGHT
#define THIS_X y
#define THIS_Y (WIDTH - x - 1)

#else
#define _WIDTH WIDTH
#define THIS_X x
#define THIS_Y y
#pragma message "Wrong matrix parameters! Set to default"

#endif

uint16_t XY(uint8_t x, uint8_t y) {
    if ((x>WIDTH-1) || (y>HEIGHT-1)) {return NUM_LEDS;} //return virtual led counter
  if ((THIS_Y % 2 == 0) || MATRIX_TYPE) {               // если чётная строка
    return (THIS_Y * _WIDTH + THIS_X);
  } else {                                              // если нечётная строка
    return (THIS_Y * _WIDTH + _WIDTH - THIS_X - 1);
  }
}

/////////DRAWS LiNEs/////////////////////////
////////////////////////////////////////////

/*void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, const CRGB & color) {
  int8_t deltaX = abs(x2 - x1);
  int8_t deltaY = abs(y2 - y1);
  int8_t signX = x1 < x2 ? 1 : -1;
  int8_t signY = y1 < y2 ? 1 : -1;
  int8_t error = deltaX - deltaY;
  
  leds[XY(x2, y2)] = color;
  while (x1 != x2 || y1 != y2) {
    leds[XY(x1, y1)] = color;
    int8_t error2 = error * 2;
    if (error2 > -deltaY) {
      error -= deltaY;
      x1 += signX;
    }
    if (error2 < deltaX) {
      error += deltaX;
      y1 += signY;
    }
  }
}*/

void mydrawLine (byte x, byte y, byte x1, byte y1, const CRGB & color, bool dot, bool grad){   // for 3Dtriangle

  byte xsteps = abs8(x - x1) + 1;
  byte ysteps = abs8(y - y1) + 1;
  byte steps = xsteps >= ysteps ? xsteps : ysteps;
  
  for (byte i = 1; i <= steps; i++) {
    byte dx = lerp8by8(x, x1, i * 255 / steps);
    byte dy = lerp8by8(y, y1, i * 255 / steps);
    
    if (dx<=WIDTH-1 && dy<=HEIGHT-1) {
      int index = XY(dx, dy);
      leds[index] += color; // change to += for brightness look
      if (grad) leds[index] %= (i * 255 / steps); //for draw gradient line
    }
  }
  
  if (dot) { //add white point at the ends of line 
    if (x<WIDTH && y<HEIGHT) leds[XY(x, y)] += CRGB::White;
    if (x1<WIDTH && y1<HEIGHT) leds[XY(x1, y1)] += CRGB::White;
  }
}

/*
//для DNA spirale only
void mydrawLine_DNA(byte y, byte y1, byte x, const CRGB & color, bool dot, bool grad) { //for DNA_horiz
  
byte steps = abs8(y - y1) + 1;
  
  for (byte i = 1; i <= steps; i++) {
    byte dy = lerp8by8(y, y1, i * 255 / steps);
    if (x<=WIDTH-1 && dy<=HEIGHT-1) {
      int index = XY(x, dy);
      leds[index] += color; // change to += for brightness look
      if (grad) leds[index] %= (i * 255 / steps); //for draw gradient line  
    }
  }
  
  if (dot) { //add white point at the ends of line 
    if (x<WIDTH && y<HEIGHT) leds[XY(x, y)] += CRGB::DarkSlateGray;
    if (x<WIDTH && y1<HEIGHT) leds[XY(x, y1)] += CRGB::White;
  }
}*/
///////////////////////// drawlines

void drawPixelXYF(float x, float y, const CRGB & color) {
  if (x < 0 || y < 0 || x > ((float)WIDTH - 1) || y > ((float)HEIGHT - 1)) return;    
  // extract the fractional parts and derive their inverses
  uint8_t xx = (x - (int) x) * 255, yy = (y - (int) y) * 255, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    int16_t xn = x + (i & 1), yn = y + ((i >> 1) & 1);
    CRGB clr = leds[XY(xn, yn)];
    clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
    clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
    clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
    leds[XY(xn, yn)] = clr;
  }
  #undef WU_WEIGHT
}

void drawPixelXYF_X(float x, uint16_t y, const CRGB & color) {
  // extract the fractional parts and derive their inverses
  uint8_t xx = (x - (int) x) * 255, ix = 255 - xx;
  // calculate the intensities for each affected pixel
  uint8_t wu[2] = { ix, xx };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (int8_t i = 1; i >= 0; i--) {
    int16_t xn = x + (i & 1);
    CRGB clr = leds[XY(xn, y)];
      clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
      clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
      clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
    leds[XY(xn, y)] = clr;
  }
}

void drawPixelXYF_Y(uint16_t x, float y, const CRGB &color)
{
  if (x<0 || y<0 || x>((float)WIDTH) || y>((float)HEIGHT)) return;

  // extract the fractional parts and derive their inverses
  uint8_t yy = (y - (int)y) * 255, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  uint8_t wu[2] = {iy, yy};
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (int8_t i = 1; i >= 0; i--) {
      int16_t yn = y + (i & 1);
      CRGB clr = leds[XY(x, yn)];
      if(yn>0 && yn<(int)HEIGHT-1){
        clr.r = qadd8(clr.r, (color.r * wu[i]) >> 8);
        clr.g = qadd8(clr.g, (color.g * wu[i]) >> 8);
        clr.b = qadd8(clr.b, (color.b * wu[i]) >> 8);
      } else if(yn==0 || yn==(int)HEIGHT-1) {
        clr.r = qadd8(clr.r, (color.r * 85) >> 8);
        clr.g = qadd8(clr.g, (color.g * 85) >> 8);
        clr.b = qadd8(clr.b, (color.b * 85) >> 8);
      }
    leds[XY(x, yn)] = clr;
  }
}

//////////// wu_pixel ///////////////
void wu_pixel(uint32_t x, uint32_t y, CRGB * col) { //awesome wu_pixel procedure by reddit u/sutaburosu
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t xy = XY((x >> 8) + (i & 1), (y >> 8) + ((i >> 1) & 1));
    leds[xy].r = qadd8(leds[xy].r, col -> r * wu[i] >> 8);
    leds[xy].g = qadd8(leds[xy].g, col -> g * wu[i] >> 8);
    leds[xy].b = qadd8(leds[xy].b, col -> b * wu[i] >> 8);
  }
  #undef WU_WEIGHT  
}
//////////////////////////////////// wu_pixel

void IncPal() {
    palette++;
    if (palette>=countpal) palette=0;
}