// Spiral Tunnel, RAM optimized v4, coor@, 16.06.26. Called from custom.ino
// RAM: all state lives in the shared pool (see POOL_SIZE in main .ino), pool is zeroed on mode change

#define ST_TUNNEL_R     0.30f   // радиус тоннеля (доля от ширины матрицы)
#define ST_FLY_SPEED    0.0003f // скорость полёта (z-декремент на мс)
#define ST_CAM_SPEED    1.5f    // скорость движения центра (пикс/сек)
#define ST_SPIRAL       1.5f    // кривизна спирали (оборотов на пролёт)
#define ST_COLOR_MODE   1       // 0 = монохром, 1 = цветной
#define ST_MAX_P        80      // кол-во частиц

struct StState {
  uint16_t pz[ST_MAX_P];
  uint8_t  pang[ST_MAX_P];
  uint32_t lastMs;
  float    cx, cy, cvx, cvy;
};
#define st (*(StState*)pool)
static_assert(sizeof(StState) <= POOL_SIZE, "pool too small for SpiralTunnel");

#define ST_FSIN(a) ((sin8(a) - 128) * (1.0f / 128.f))
#define ST_FCOS(a) ((cos8(a) - 128) * (1.0f / 128.f))

void stResetDot(uint8_t i, bool zRand) {
  st.pz[i]   = zRand ? (uint16_t)(5 + random(996))
                     : (uint16_t)(850 + random(150));
  st.pang[i] = (uint8_t)random(256);
}

void SpiralTunnel() {
  if (loadingFlag) {
    loadingFlag = false;
    randomSeed(millis());

    st.cx  = WIDTH * 0.5f;
    st.cy  = HEIGHT * 0.5f;
    float angle = (float)random(1000) / 1000.f * TWO_PI;
    st.cvx = ST_CAM_SPEED * cosf(angle);
    st.cvy = ST_CAM_SPEED * sinf(angle);

    for (uint8_t i = 0; i < ST_MAX_P; i++) stResetDot(i, true);
    st.lastMs = millis();
  }

  uint32_t now = millis();
  float    dt  = (float)(now - st.lastMs) * 0.001f;
  st.lastMs = now;

  // центр движется внутри границ [W/2, H/2]+-20%
  const float xMin = WIDTH * 0.5f * 0.8f;
  const float xMax = WIDTH * 0.5f * 1.2f;
  const float yMin = HEIGHT * 0.5f * 0.8f;
  const float yMax = HEIGHT * 0.5f * 1.2f;

  st.cx += st.cvx * dt;
  st.cy += st.cvy * dt;

  if (st.cx <= xMin) { st.cx = xMin; st.cvx =  fabsf(st.cvx); }
  if (st.cx >= xMax) { st.cx = xMax; st.cvx = -fabsf(st.cvx); }
  if (st.cy <= yMin) { st.cy = yMin; st.cvy =  fabsf(st.cvy); }
  if (st.cy >= yMax) { st.cy = yMax; st.cvy = -fabsf(st.cvy); }

  float maxR = fminf(fminf(st.cx, WIDTH - st.cx), fminf(st.cy, HEIGHT - st.cy));

  fadeToBlackBy(leds, NUM_LEDS, 40);

  uint16_t dec = (uint16_t)(ST_FLY_SPEED * dt * 1000000.f + 0.5f);

  for (uint8_t i = 0; i < ST_MAX_P; i++) {
    if (st.pz[i] <= dec + 5) { stResetDot(i, false); continue; }
    st.pz[i] -= dec;

    float   z    = st.pz[i] * 0.001f;
    float   invZ = 1.0f / z;
    uint8_t angU = st.pang[i] + (uint8_t)(ST_SPIRAL * 256.f * (1.0f - z));

    float sx = st.cx + ST_FCOS(angU) * ST_TUNNEL_R * invZ * WIDTH * 0.5f;
    float sy = st.cy + ST_FSIN(angU) * ST_TUNNEL_R * invZ * HEIGHT * 0.5f;

    int16_t ix = (int16_t)(sx + 0.5f);
    int16_t iy = (int16_t)(sy + 0.5f);

    if (ix < 0 || ix >= WIDTH || iy < 0 || iy >= HEIGHT) {
      stResetDot(i, false);
      continue;
    }

    float dxS = sx - st.cx, dyS = sy - st.cy;
    float edgeFactor = (maxR > 0.5f)
      ? fminf(1.0f, sqrtf(dxS*dxS + dyS*dyS) / maxR)
      : 0.0f;
    uint8_t bright = 30 + (uint8_t)(225.0f * edgeFactor);

#if ST_COLOR_MODE
    uint8_t hue = st.pang[i] + (uint8_t)(st.pz[i] >> 2);
    leds[XY(ix, iy)] += CHSV(hue, 255, bright);
#else
    leds[XY(ix, iy)] += CHSV(0, 0, bright);
#endif
  }
}
