#include "palettes10x.h"

byte hue; //используется много где
byte speed=20; // в noise, prismata, source
byte scale=30; // в noise, prismata, source, sinewaves
byte brightness; //prismata, source
uint32_t t; //rmap, drift

/////////// SPARKLES //////////////////////////
#define DENSE 5           // плотность конфетти //default 3
#define BRIGHT_STEP 50    // шаг уменьшения яркости //default 70

void fader(byte step) {
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      fadePixel(i, j, step);
    }
  }
}
void fadePixel(byte i, byte j, byte step) {  
  int pixelNum = XY(i, j);
  if (leds[XY(i, j)] == 0) return;

  if (leds[pixelNum].r >= 10 || //30
      leds[pixelNum].g >= 10 || //30
      leds[pixelNum].b >= 10) { //30
    leds[pixelNum].fadeToBlackBy(step);
  } else {
    leds[pixelNum] = 0;
  }
}

void sparklesRoutine() {
  for (byte i = 0; i < DENSE; i++) {
    byte x = random(0, WIDTH);
    byte y = random(0, HEIGHT);
    if (leds[XY(x, y)] == 0)
      leds[XY(x, y)] = CHSV(random(0, 255), 255, 255);
  }
  fader(BRIGHT_STEP);
}
////////////////////////////////////////////////////// SPARKLES

////////////// 3D triangle /////////////////////
#define TR_SPEED -5                     //global speed of dots move  

void draw3Dtriangle () {

//  if (loadingFlag) { loadingFlag = false; hue=0; }

EVERY_N_MILLISECONDS(30) { hue++; }  //30 - speed of hue change

	byte x1 = beatsin8 (18+TR_SPEED, 0, (WIDTH-1));
	byte x2 = beatsin8 (23+TR_SPEED, 0, (WIDTH-1)); 
	byte x3 = beatsin8 (27+TR_SPEED, 0, (WIDTH-1)); 
	byte x4 = beatsin8 (31+TR_SPEED, 0, (WIDTH-1)); 
	byte x5 = beatsin8 (33+TR_SPEED, 0, (WIDTH-1)); 

	byte y1 = beatsin8 (20+TR_SPEED, 0, (HEIGHT-1)); 
	byte y2 = beatsin8 (26+TR_SPEED, 0, (HEIGHT-1));
	byte y3 = beatsin8 (15+TR_SPEED, 0, (HEIGHT-1));
	byte y4 = beatsin8 (27+TR_SPEED, 0, (HEIGHT-1));
	byte y5 = beatsin8 (30+TR_SPEED, 0, (HEIGHT-1));

	CRGB color = CHSV (hue,255,255);

	fadeToBlackBy (leds,NUM_LEDS, 200);

	mydrawLine(x1, y1,  x2, y2, color, 0, 0); // 1 is white dot 0 is no white dot
	mydrawLine(x2, y2,  x3, y3, color, 0, 0);
	mydrawLine(x3, y3,  x1, y1, color, 0, 0);
	mydrawLine(x4, y4,  x1, y1, color, 0, 0);
	mydrawLine(x4, y4,  x2, y2, color, 0, 0);
	mydrawLine(x4, y4,  x3, y3, color, 0, 0);

	blur2d (leds,WIDTH, HEIGHT, 8);
}
/////////////////////////////////////////////// 3D Triangle

/////////////// Color Frizzles ////////////////

void ColorFrizzlesRoutine() {
  fadeToBlackBy(leds, NUM_LEDS, 70);
  for(byte i=8; i > 0;i--){leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
  /*if(WIDTH >24 || HEIGHT >24){
    leds[XY(beatsin8(12+i,0,WIDTH-1)+1,beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1)-1,beatsin8(15-i,0,HEIGHT-1))]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1)+1)]+=CHSV(beatsin8(12,0,255),255,255);
    leds[XY(beatsin8(12+i,0,WIDTH-1),beatsin8(15-i,0,HEIGHT-1)-1)]+=CHSV(beatsin8(12,0,255),255,255);
  }*/
  }blur2d(leds,WIDTH,HEIGHT,16);
}
//////////////// Color Frizzles

//////////////// SineWavesRoutine //////////
#define SW_SPEED 30
#define SW_SCALE 1
#define SW_AMPLITUDE 200.0f
#define semiHeightMajor HEIGHT / 2 + (HEIGHT % 2)
#define semiWidthMajor WIDTH / 2 + (WIDTH % 2)

//uint8_t speed_s = 30;
//uint8_t scale_s = 1;
//uint8_t amplitude = 200;

static float fmap(const float x,
  const float in_min,
    const float in_max,
      const float out_min,
        const float out_max) {
  return (out_max - out_min) * (x - in_min) / (in_max - in_min) + out_min;
}

//const uint8_t semiHeightMajor = HEIGHT / 2 + (HEIGHT % 2);
//const uint8_t semiWidthMajor = WIDTH / 2 + (WIDTH % 2);
float e_s3_speed, e_s3_size; // amplitude of the curves

void SineWavesRoutine(bool swr) {
  if (loadingFlag) {
    loadingFlag = false;
    e_s3_speed = 0.004 * SW_SPEED + 0.015; // speed of the movement along the Lissajous curves
    e_s3_size = fmap(SW_AMPLITUDE, 1, 255, 3, 9); // amplitude of the curves
    scale = map8(SW_SCALE, 50, 150);
  }
  
  float time_shift = millis();
  uint8_t y; uint8_t x;
  float cx; float cy;
  int8_t v;

 struct {
    float shiftX;
    float shiftY;
  }sshft[2];

  sshft[0].shiftX = float(e_s3_size * (sin16(e_s3_speed * 98.301 * time_shift))) / 32767.0;
  sshft[0].shiftY = float(e_s3_size * (sin16(e_s3_speed * 72.0874 * time_shift))) / 32767.0;
  sshft[1].shiftX = float(e_s3_size * (sin16(e_s3_speed * 134.3447 * time_shift))) / 32767.0;
  sshft[1].shiftY = float(e_s3_size * (sin16(e_s3_speed * 170.3884 * time_shift))) / 32767.0;
  //sshft[2].shiftX = float(e_s3_size * (sin16(e_s3_speed * 68.8107 * time_shift))) / 32767.0;
  //sshft[2].shiftY = float(e_s3_size * (sin16(e_s3_speed * 65.534 * time_shift))) / 32767.0;

  //Sinusoid I
  if (!swr) {
    for (y = 0; y < HEIGHT; y++) {
      for (x = 0; x < WIDTH; x++) {
      
        cx = (y - semiHeightMajor) + float(e_s3_size * (sin16(e_s3_speed * 98.301 * time_shift))) / 32767.0; // the 8 centers the middle on a 16x16
        cy = (x - semiWidthMajor) + float(e_s3_size * (cos16(e_s3_speed * 72.0874 * time_shift))) / 32767.0;
        v = sin8((scale / 2) * sqrt((((float) cx * cx) + ((float) cy * cy))));
        leds[XY(x, y)].r = ~v;
      
        cx = (y - semiHeightMajor) + float(e_s3_size * (sin16(e_s3_speed * 134.3447 * time_shift))) / 32767.0;
        cy = (x - semiWidthMajor) + float(e_s3_size * (cos16(e_s3_speed * 170.3884 * time_shift))) / 32767.0;
        v = sin8((scale / 2) * sqrt((((float) cx * cx) + ((float) cy * cy))));
        leds[XY(x, y)].b = ~v;
      }
    }
  }
  //Sinusoid II
  else {
    for (y = 0; y < HEIGHT; y++) {
      for (x = 0; x < WIDTH; x++) {
        cx = (y - semiHeightMajor) + sshft[0].shiftX; // the 8 centers the middle on a 16x16
        cy = (x - semiWidthMajor) + sshft[0].shiftY;
        int8_t v = sin8(scale * sqrt(( cx * cx) + ( cy * cy)));
        leds[XY(x,y)].r = ~v;
      
        cx = (y - semiHeightMajor) + sshft[1].shiftX;
        cy = (x - semiWidthMajor) + sshft[1].shiftY;
        v = sin8(scale * sqrt(( cx * cx) + ( cy * cy)));
        leds[XY(x,y)].b = ~v;
      }
    }
  }
}
//////////////////////////////////////////// SineWaves

/////////////// Twinkles (random fade) //////////////
void TwinklesRoutine() {

 byte offset = 0;

//  if (loadingFlag) {loadingFlag = false;}
 
  EVERY_N_MILLISECONDS(200) {
    offset++;
  }
  
  random16_set_seed(23579);
  double a = millis()*1.2;  //w/o 
  for (byte i = 0; i < NUM_LEDS; i++) {
    hue = sin8((random16() / 256) + inoise8(random16() / 256 + a / 32) + i * 4);
    byte bright = sin8(random16() / 256 + inoise8(random16() / 256 + a / 32) + a / 16);
    nblend(leds[i], CHSV(hue + offset, 255, bright), 255);
    //nblend(leds[i], ColorFromPalette(LavaColors_p, hue + offset, bright), 128);	
  }
 }
/////////////////////////////////////////////////////TwinklesRoutine

/////////////////////// similar sine effects ////////
float code(double t, double i, double x, double y, byte effect) {

switch (effect){
	case 0:return sin(hypot(x-=8,y-=6)+4*t+atan2(y,x)); break; //hypnospiral+
	case 1:return abs(cos(atan2(y+4,x-6)*6+t*4)); break; //лучи из угла+
	case 2:return sin(y*sin(t/2)*4+t*4+i*6); break; //вращающиеся полосы (t/2)*speed+
  case 3:return abs(12- x) < 13 ? cos(t + (x + y) * PI / 12) : 0; break; //бегущие по диагонали полосы+
//	case 4:return sin(atan((y-6.5)/(x-8.5))+t*2); break; //вращающийся fader+
//	case 5:return sin(atan((y)/(x))+2*t); break; //шторка гаснущая по диагонали, лучше 2*t--
	case 6:return 1-fmod(( (0.3*t+x+sin(0.3*t+x)/2) -y/30),1.0); break; // matrix style, 0.3*t+
//  case 7:return 1-fmod((x*x-y+t*(fmod(1+x*x,5.0))*3.0),16.0)/16.0; break; //тоже матрица , но медленнее--
  case 8:return (y-6)/6-tan(x/10+1.87)*sin(2*t); break; //типа качсающиеся половинки, нужно поэкспирементировать. (y-6)/6 поинтересней
  case 9:return (y-6)/7-(sin(x/2+t*2)); break; //бегущий черный синус, (y-6)/10, x/2+t*2--
  //case 10:return sin(x) - sin(x/2-8*t) - y/1.2+6; break; //типа синус черный, но с тонкой гранью 5 - по центру--
  case 11:return -.4/(hypot(x-fmod(t,10),y-fmod(t,8))-fmod(t,2)*9); break; //разбегающиеся круги++
	case 12:return sin(x/3*sin(t/3)*2)+cos(y/4*sin(t/2)*2);   break; //растягивающиеся пятна, норм.++
	case 13:return sin(x*x*i/1e4-y/2+t*6); break; // бумеранговые полосы влево. t*4 скорость.++
//  case 14:return min(7-y+sin(x+sin(y+t*8))*6,0); break; //fire, но такой стремненький, оставить.--
//	case 15:return x*y/64*sin(t+x*8-y*8);  break;  //ничетак полукруги жирные движущиеся--
//  case 16:return sin(3*atan2(y-5.5,x-10.5)+2*t);  break; //вращающиеся лучи, норм 2*t--
//  case 17:return sin(3 * atan2(y - 5.5 + sin(t) * 5, x - 5.5 + sin(t / 2) * 5) + t * 5); break; // тоже лучи, но двигающиеся--
//	case 18:return sin(2*t-sqrt(x*x+y*y)); break; //бегущие полукруги, увеличить скорость до 2*t++
	case 19:return 1-hypot(sin(t)*9-x,cos(t)*9-y)/9; break; //блуждающие полосы, норм++
//	case 20:return sin(x+sin(y/2+t*5))+cos(y); break; //танцующие кляксы
	} 
}

void processFrame(float t, float x, float y, byte effect) {
   EVERY_N_MILLISECONDS( 30 ) { hue++; }
  float i = (y * 16) + x;
  float frame = constrain(code(t, i, x, y, effect), -1, 1) * 255;
  if (frame >= 0) { leds[XY(x, (HEIGHT - 1 - y))]= CHSV(hue,255,frame); } //change to XY(x, y) for non rotate display
  else { leds[XY(x, (HEIGHT - 1 - y))] = CHSV(hue+55, 255, -frame); } //change to XY(x, y) for non rotate display
}

void SineEffectsRoutine(byte effect) {
	
//  if (loadingFlag) { loadingFlag = false; hue=0; }
  
  float t = millis() / 1000.0; // some formulas is hardcoded and fps get down. this speedup it
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      processFrame(t, x, y, effect);
    }
  }
}
/////////////////////////////////////////////////////Similar Sine Effects

///////////////////Grid /////////////////
float offsetX = 0; //also used in SimpleSin и Radar
float offsetY = 0;
//uint8_t hue = 0;

void GridRoutine() 
{

//  if (loadingFlag) { hue = 0; loadingFlag = false; }	

  offsetX = beatsin16(6, -180, 180);
  offsetY = beatsin16(6, -180, 180, 12000);

  EVERY_N_MILLISECONDS(10) { hue++; }

  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      int16_t index = XY(x, y);

      if (index < 0) break;

      hue = x * beatsin16(10, 1, 10) + offsetY;
      leds[index] = CHSV(hue, 200, sin8(x * 30 + offsetX));
      hue = y * 3 + offsetX;
      leds[index] += CHSV(hue, 200, sin8(y * 30 + offsetY));
}}}
///////////////////////////////////////// Grid

////////////// SimpleSin ///////////////
//  float f_offset = 0;
  
void SimpleSinRoutine() {

//    if (loadingFlag) { loadingFlag = false; offsetX = 0; }	

 FastLED.clearData();

  for (byte i = 0; i < WIDTH; i++) {
    offsetX += 0.025;
    float sinus = sin(((float)i+offsetX) / 5.0f);
    sinus += 1;
    sinus *= 5;
    leds[XY(i,sinus)] = CRGB(255, 255, 255);
  }
  blur2d(leds, WIDTH, HEIGHT, 128);
}
//////////////////////////////////////// SimpleSin

////////////////// Drift ////////////
#define CenterX ((WIDTH / 2) - 0.5)
#define CenterY ((HEIGHT / 2) - 0.5)
#define maxDim max(WIDTH, HEIGHT)
//const byte maxDim = max(WIDTH, HEIGHT);

//byte effect= 0; заменяем на глобальную - speed

void Drift () {

  if (loadingFlag) { loadingFlag = false; speed = random(4); }	
  FastLED.clear(); //fadeToBlackBy(leds, NUM_LEDS, 16);
  //unsigned long t = millis()/40; //defined higher
  t = millis()/40;
  for(float i = 1; i <maxDim / 2; i+=0.5) {
    float angle = radians(t * (maxDim/2-i));
    drawPixelXYF(CenterX + sin(angle) * i, CenterY + cos(angle) * i, ColorFromPalette(PartyColors_p, (i * 20) + (t / 20))); //case for all
    switch(speed){
    case 1: case 3: drawPixelXYF(CenterX + cos(angle) * i, CenterY + sin(angle) * i, ColorFromPalette(PartyColors_p, (i * 20) + (t / 20)));break;
  }}
  switch(speed){
    case 2: case 3: blur2d(leds, WIDTH, HEIGHT, 16); break;
  }
//  fadeToBlackBy(leds, NUM_LEDS, 30);
}
///////////////////////////////////// Drift

///////////// Drift Rose ////////////
//#define CX WIDTH / 2. - 0.5  // defined higher
//#define CY HEIGHT / 2. - 0.5 // defined higher
#define L (min(WIDTH, HEIGHT)) // /2 - makes it squarer

void DriftRose () {

// if (loadingFlag) {loadingFlag = false; }	

for (byte i = 1; i < 37; i++) {
    drawPixelXYF(CenterX + (sin(radians(i * 10)) * (beatsin8(i, 0, L*2)-L)), CenterY + (cos(radians(i * 10)) * (beatsin8(i, 0, L*2)-L)), CHSV(i * 10, 255, 255));
  }
  fadeToBlackBy(leds, NUM_LEDS, 32);
  blur2d(leds, WIDTH, HEIGHT, 16);
}
///////////////////////////////////// Drift Rose

// стандартные функции библиотеки LEDraw от @Palpalych (для адаптаций его эффектов)
void blurScreen(fract8 blur_amount, CRGB *LEDarray = leds) { blur2d(LEDarray, WIDTH, HEIGHT, blur_amount); }

void dimAll(uint8_t value, CRGB *LEDarray = leds) { nscale8(LEDarray, NUM_LEDS, value); }

uint8_t myScale8(uint8_t x) { // даёт масштабировать каждые 8 градаций (от 0 до 7) бегунка Масштаб в значения от 0 до 255 по типа синусоиде
  uint8_t x8 = x % 8U;
  uint8_t x4 = x8 % 4U;
  if (x4 == 0U)
    if (x8 == 0U)       return 0U;
    else                return 255U;
  else if (x8 < 4U)     return (1U   + x4 * 72U); // всего 7шт по 36U + 3U лишних = 255U (чтобы восхождение по синусоиде не было зеркально спуску)
//else
                        return (253U - x4 * 72U); // 253U = 255U - 2U
}

void Prismata () {
   if (loadingFlag)  {
    loadingFlag = false;
    brightness = 255U; // not used here
    speed = 30U;       // 1-255
    scale = 8;         // 1-100 is palette
    //setCurrentPalette();
//    curPalette = palette_arr[(uint8_t)random(2)];
  } 
  hue++; // используем переменную сдвига оттенка из функций радуги, чтобы не занимать память
  blurScreen(20); // @Palpalych посоветовал делать размытие
  dimAll(255U - (scale - 1U) % 11U * 3U);

  for (uint8_t x = 0; x < WIDTH; x++)
  {
    uint8_t beat = (GET_MILLIS() * (accum88(x + 1)) * 28 * speed) >> 17;
    uint8_t y = scale8(sin8(beat), HEIGHT-1);
       
    leds[XY(x, y)] = ColorFromPalette(*pal_arr[0], x * 7 + hue);
  }
}
////////////////////////////////// Prismata

////////// SinShort /////////////
#define a (256 / WIDTH)

void SinShort() {
  double t = (float)millis()/10;  //unsigned t есть выше, но не ругается компиль
  for (byte i = 0; i < HEIGHT; i++) {
    uint16_t shift = (i * 16); float sin1 = (1+sin(radians(t + shift)))*128; 
    byte bright =  112*(1+sin(radians(t + shift + 90)))+30; 
    byte bright2 =  112*(1+sin(radians(t + shift + 270)))+30;
    drawPixelXYF_X(sin1 /a, i, CHSV(sin1, 255, bright));
    drawPixelXYF_X((WIDTH-1)-(sin1 / a), i, CHSV(~(byte)sin1, 255, bright2));
  }
  fadeToBlackBy(leds, NUM_LEDS, 64);
}
///////////////////////////////// SinShort

////////// Fire234 /////////////
//int f_BRIGHTNESS = 255;
#define F234_SCALEXY 60
#define F234_SPEED 20

//int scalexy = 60; // scale of fire
//int i_speed = 20; //speed of effect 

DEFINE_GRADIENT_PALETTE(ffirepal) { // define fire palette
  0,  0,  0,  0, //black
  32,  255,  0,  0, // red
  190,  255,  255,  0, //yellow
  255,  255,  255,  255 // white
};

void Fire234 () {

 CRGBPalette16 myPal = ffirepal;
  
 uint16_t atm = millis();
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      leds[XY((WIDTH - 1) - i, (HEIGHT - 1) - j)] = ColorFromPalette(myPal, qsub8(inoise8(i * F234_SCALEXY, j * F234_SCALEXY + atm, atm / F234_SPEED), abs8(j - (HEIGHT - 1)) * 255 / (HEIGHT - 1)), 255); //255 - BRIGHTNESS
    }
  }

}
//////////////////////////////// Fire234

//////// Ex7Sparkles /////////////////
void Ex7Sparkles() {

//   if (loadingFlag) {  loadingFlag = false;  hue = 0; }	
    
  // 6 beats per minute, between 1 and 10
  int numberOfSparkles = beatsin16(6, 3, 10);

  EVERY_N_MILLISECONDS(20) {
    for (int i = 0; i < numberOfSparkles; i++) {
      int pos = random16(NUM_LEDS);

      if (!leds[pos]) {
        leds[pos] = CHSV(hue + (pos / 10), 255, 255);
      }
    }
  }
  EVERY_N_MILLISECONDS(50) {
    hue -= 1;
  }
  fade_raw(leds, NUM_LEDS, 100);
 //   delay(40);
}
////////////////////////////////////// Ex7Sparkles

////////////// Pride ///////////////
void Pride() {

//     if (loadingFlag) {loadingFlag = false; }	
  
  static uint16_t sPseudotime = 0;
  static uint16_t sLastMillis = 0;
  static uint16_t sHue16 = 0;

  uint8_t sat8 = beatsin88( 87, 220, 250);
  uint8_t brightdepth = beatsin88( 341, 96, 224);
  uint16_t brightnessthetainc16 = beatsin88( 203, (25 * 256), (40 * 256));
  uint8_t msmultiplier = beatsin88(147, 23, 60);

  uint16_t hue16 = sHue16;//gHue * 256;
  uint16_t hueinc16 = beatsin88(113, 1, 3000);

  uint16_t ms = millis();
  uint16_t deltams = ms - sLastMillis;
  sLastMillis  = ms;
  sPseudotime += deltams * msmultiplier;
  sHue16 += deltams * beatsin88( 400, 5, 9);
  uint16_t brightnesstheta16 = sPseudotime;

  for ( byte i = 0 ; i < NUM_LEDS; i++) {
    hue16 += hueinc16;
    hue = hue16 / 256;

    brightnesstheta16  += brightnessthetainc16;
    uint16_t b16 = sin16(brightnesstheta16) + 32768;

    uint16_t bri16 = (uint32_t)((uint32_t)b16 * (uint32_t)b16) / 65536;
    uint8_t bri8 = (uint32_t)(((uint32_t)bri16) * brightdepth) / 65536; //выше есть общая - brightness
    bri8 += (255 - brightdepth);

    CRGB newcolor = CHSV( hue, sat8, bri8);

    uint16_t pixelnumber = i;
    pixelnumber = (NUM_LEDS - 1) - pixelnumber;
    nblend( leds[pixelnumber], newcolor, 64);
  }
}
//////////////////////////////////// Pride

////////////// Sin Dots ///////////
void SinDots () {
//  if (loadingFlag) {loadingFlag = false;}
  fadeToBlackBy(leds, NUM_LEDS, 15);
  byte t1 = millis() / 20;
  byte t2 = sin8(t1)/2;
  for (byte i = 0; i < 13; i++) {
    byte x = sin8(t1 + i * 20)*HEIGHT/255; 
    byte y = sin8(t2 + i * 20)*WIDTH/255;   
    x= x>=HEIGHT? (HEIGHT-1):x;
    y= y>=WIDTH? (WIDTH-1):y;
    leds[XY(y, x)] = CHSV(i * 255 / 13, 255, 255); //y,x!!! это потому что перепутаны HEIGHT и WIDTH
  }
  blur2d(leds, HEIGHT, WIDTH, 16);
}
/////////////////////////////////// Sin Dots

///////////// Radar //////////////////////
//float eff_theta; //замена на объявленный выше offsetX
//float eff_offset; 

#define R_WIDTH_ADJ (WIDTH < HEIGHT ? (HEIGHT - WIDTH) /2 : 0)
#define R_HEIGHT_ADJ (HEIGHT < WIDTH ? (WIDTH - HEIGHT) /2: 0)

uint8_t mapsincos8(bool map, uint8_t theta, uint8_t lowest, uint8_t highest) {
  uint8_t beat = map ? sin8(theta) : cos8(theta);
  return lowest + scale8(beat, highest - lowest);
}

/*
uint16_t mapsincos16(bool map, uint16_t theta, uint16_t lowest, uint16_t highest) {
  uint8_t beat = map ? sin16(theta) : cos16(theta);
  return lowest + scale16(beat, highest - lowest);
}*/

void radarRoutine() {
    
//    if (loadingFlag) {  loadingFlag = false;}	

    fadeToBlackBy(leds, NUM_LEDS, 5 + 20 * 85 / 255); //85-speed
    for (float offset = 0.0f; offset < (float)maxDim /2; offset +=0.25) {
      float x = (float)mapsincos8(false, offsetX, offset * 4, maxDim * 4 - offset * 4) / 4.  - R_WIDTH_ADJ;
      float y = (float)mapsincos8(true, offsetX, offset * 4, maxDim * 4 - offset * 4) / 4.  - R_HEIGHT_ADJ;
      CRGB color = ColorFromPalette(RainbowColors_p, hue, 255 / random8(1, 12));
      drawPixelXYF(x, y, color);
    }
  EVERY_N_MILLIS(16) {
    offsetX += 5.5 * (85 / 255.0) + 1; //85 - speed
//    eff_offset += 3.5 * ((255 - 85) / 255.0) + 1; //85 - speed
    hue = millis() / 16;// eff_offset;
  }
}
////////////////////////////////////////////// Radar

/*
///////////// WithoutSIN //////////////////////
void WithoutSin() {
//if (loadingFlag) {loadingFlag = false;}	  

  static byte ws_speed = 0;
  static byte ws_speed1 = 0;
  
  for (int index = 0; index < NUM_LEDS; index++) {
    if ((index + ws_speed) % (WIDTH + 1) == 0)
      leds[index] += CHSV((index / WIDTH) * 255 / HEIGHT + ws_speed * 2, 255, 255);
  }
  
  if (++ws_speed1 > 2) {
    ws_speed1 = 0;
    ws_speed++;
  }
  fadeToBlackBy(leds, NUM_LEDS, 15);
}
////////////////////////////////////////////// WithoutSIN почему то не работает нормально на 24*12, вместо двух встречных - один синус
*/

//////// SinSparkles /////////////////
void SinSparkles() {
    
 //if (loadingFlag) {loadingFlag = false; hue=random(50,200);}	    

  int numSparkles = beatsin8(8, 1, 4);
  
  EVERY_N_MILLISECONDS(30) { hue++; }
  
  EVERY_N_MILLISECONDS(10) {
    for (int i = 0; i < numSparkles; i++) {
      uint16_t index = random(0, NUM_LEDS);
      leds[index] = CHSV(hue + index / 20, 255, 255);
    }
    fadeToBlackBy(leds, NUM_LEDS, 1);
  }
}
////////////////////////////////////// SinSparkles. копия ex7sparkles, но с размытием


//////////////// Wine Sparkles ////
uint8_t hue2;                                 // постепенный сдвиг оттенка или какой-нибудь другой цикличный счЄтчик
uint8_t deltaHue; //deltaHue2;                       // ещЄ пара таких же, когда нужно много
uint8_t step;                                      // какой-нибудь счЄтчик кадров или последовательностей операций
uint8_t pcnt;                                      // какой-то счЄтчик какого-то прогресса
uint8_t deltaValue;                                // просто повторно используема¤ переменна

void WineSparkles() {

byte x,y;

 if (loadingFlag) {
    loadingFlag = false;
    step = deltaValue;                      // чтообы при старте эффекта сразу покрасить лампу
    deltaHue = 1;                          // direction | 0 hue-- | 1 hue++ |
    hue = 55;                              // Start Color
    hue2 = 160;                            // Brightness
    pcnt = 0;
  }

 if (step >= deltaValue) {
    step = 0;
    if (deltaHue == 1) {
      hue++;
      if (hue < 20 || hue > 245) hue2++;  // возвращаем яркость для перехода к розовому
    } else {
      hue--;
      if (hue < 20 || hue > 245) hue2--;     // уменьшаем яркость для красного вина
    }

  for (x = 0; x < WIDTH; x++) {
    for (y = 0; y < HEIGHT - 1; y++) {
      leds[XY(x, HEIGHT-1-y)] = leds[XY(x, HEIGHT-1-y-1)];
    }
  }

//   if ((hue > 40) && (hue <= 60)) {
      // добавляем перляж для шампанского
      pcnt = random(0, WIDTH);
//    } else {
//      pcnt = 0;
//    }  

    // заполняем нижнюю строку с учетом перляжа
//    deltaHue2 = 0;
    for (x = 0; x < WIDTH; x++) {
      if ((x == pcnt) && (pcnt > 0)) {
        // с перляжем ------
        leds[XY(x, 0)] = CHSV(hue, 150, (byte)(hue2 + 20 + random(0, 50)));
  //     leds[XY(x, WIDTH-1)] = CHSV(hue, 150, (byte)(hue2 + 20 + random(0, 50)));
      } else {
        leds[XY(x, 0)] = CHSV(hue, 255, hue2);
//        leds[XY(x, WIDTH-1)] = CHSV(hue, 255, hue2);
  
      }
    }
  }

  // меняем направление изменени¤ цвета вина от красного к шампанскому и обратно
  // в двух диапазонах шкалы HUE |0-60|.........|245-255|
  if  (deltaHue == 0) {
    if  (hue == 1)   hue = 255;
    if  (hue == 245) deltaHue = 1;
  }
  if (deltaHue == 1) {
    if (hue == 254) hue = 0;
    if (hue == 60)  deltaHue = 0;
  }
  step++;
}
/////////////////////////////////// Wine Spakles

/////////////// FireFlow //////////////////// - полосы ползающие
void FireFlow() {

//  if (loadingFlag) { loadingFlag=false; palette=random(countpal); //pal_arr has countpal palettes}

  const float hl = NUM_LEDS/15;   

  int t = millis()/15; //выше unsigned long t, но не ругается

  for (int i = 0; i <NUM_LEDS; i++) {
    int c = (abs(i - hl)/hl)*20;
    byte b = sin8(c+t/8); 
    //leds [i] = ColorFromPalette(LavaColors_p,(b+t)%255,255);
    leds [i] = ColorFromPalette(*pal_arr[palette],(b+t)%255,255);
  }

  EVERY_N_MILLISECONDS (5000) { IncPal(); }

}
/////////////////////////////////////////////FireFlow

/////////////// China2 //////////////////// - треугольники из огня влево-вправо
void China2() {

  //if (loadingFlag) { loadingFlag=false;  palette=random(countpal); //pal_arr has countpal palettes }

  float t = millis()/70.;
  for(byte x =0; x <WIDTH; x++){
    for(byte y =0; y <HEIGHT; y++){
      //leds[XY(x,y)]=ColorFromPalette(HeatColors_p,((sin8((x*10)+sin8(y*5+t*5.))+cos8(y*10))+1)+t);
      leds[XY(x,y)]=ColorFromPalette(*pal_arr[palette],((sin8((x*10)+sin8(y*5+t*5.))+cos8(y*10))+1)+t);
    }
  }

}
/////////////////////////////////////////////China2

/////////////// VUSpectrum //////03.12.25/////// - Эквалайзер
#define SAMPLES           256U          // Must be a power of 8
#define NUM_BANDS       WIDTH
#define TOP            (HEIGHT - 1)                // Don't allow the bars to go offscreen
#define BAR_WIDTH      (WIDTH  / (NUM_BANDS - 1))  // If width >= 8 light 1 LED width per bar, >= 16 light 2 LEDs width bar etc

const float speedFactorVertical = (float)HEIGHT / 16;

class EffectVU {
private:
    byte colorShift = 255;
    // Sampling and FFT stuff
    float peak[NUM_BANDS];              // The length of these arrays must be >= NUM_BANDS
    float oldBarHeights[NUM_BANDS];
    float bandValues[NUM_BANDS];

    uint8_t last_max_peak;
    float maxVal;
    float amplitude = 0.4; // 0.025 - 0.5
    void horizontalColoredBars(uint8_t band, float barHeight);
    void whitePeak(uint8_t band);

public:
    bool run();
    void load();
};

void EffectVU::load() {
  for(uint16_t i=0; i<sizeof(oldBarHeights)/(sizeof(*oldBarHeights));i++)
  for(uint16_t i=0; i<sizeof(bandValues)/(sizeof(*bandValues));i++)
    bandValues[i]=0.0f;
}

bool EffectVU::run() {
  EVERY_N_MILLIS(random(50,100)) {  //here the dynamics of VU is set. was (50,300)
    last_max_peak=random(0,HEIGHT);
    maxVal = random(0,last_max_peak);
    for (uint16_t i = 0; i < (sizeof(bandValues) / sizeof(float)); i++) {
      bandValues[i] = random(2)? random(0, HEIGHT) : bandValues[i];
    }
  }

  float _scale = (maxVal==0? 0 : last_max_peak/maxVal) * amplitude;

  FastLED.clear();

  // Process the FFT data into bar heights
  for (byte band = 0; band < NUM_BANDS; band++) {

    // Scale the bars for the display
    float barHeight = bandValues[band] * _scale > 0/*threshold*/ ? (bandValues[band] * _scale) : 0.;
    if (barHeight > TOP) barHeight = TOP;

    // Small amount of averaging between frames
    barHeight = ((oldBarHeights[band] * 1) + barHeight) / 2;

    // Move peak up
    if (barHeight > peak[band]) {
      peak[band] = min((float)TOP, barHeight);
    }
    
    horizontalColoredBars(band, barHeight);
    whitePeak(band);

    // Save oldBarHeights for averaging later
    oldBarHeights[band] = barHeight;
  }

  // Decay peak
    for (byte band = 0; band < NUM_BANDS; band++)
      if (peak[band] > 0) peak[band] -= 0.25 * speedFactorVertical;
  return true;
}

void EffectVU::horizontalColoredBars(uint8_t band, float barHeight) {
  uint8_t xStart = BAR_WIDTH * band;
  
  EVERY_N_MILLIS(10) colorShift--;
  
  for (uint8_t x = xStart; x < xStart + BAR_WIDTH; x++) {
    for (float y = TOP; y >= (float)TOP - barHeight; y-= 0.5) {
        // Just color by height
        drawPixelXYF(x, (float)TOP - y, CHSV(band * (232 / NUM_BANDS) + colorShift, 255, 255));
//        drawPixelXYF(x, (float)TOP - y, ColorFromPalette(LavaColors_p, band * (232 / NUM_BANDS) + colorShift));        
// можно задействовать countpal и pal_arr
    }
  }
}

void EffectVU::whitePeak(uint8_t band) {
  uint8_t xStart = BAR_WIDTH * band;
  float peakHeight = (float)TOP - peak[band] - 1;
  for (uint8_t x = xStart; x < xStart + BAR_WIDTH; x++) {
    drawPixelXYF(x, (float)TOP - peakHeight, CHSV(0,0,255));
  }
}

EffectVU eff;

void VUSpectrum() {
  
  if (loadingFlag) {
    eff.load();
    loadingFlag = false;
  }
  eff.run();
  delay(16);  // 16 - ~60fps
}
/////////////////////////////////////////////VUSpectrum  

/////////////// Something //////04.12.25/////// - этакий глаз выворачивается
CRGB ColorFromPaletteExtended_other(const CRGBPalette16& pal, uint16_t index, uint8_t brightness, TBlendType blendType) {
  // Extract the four most significant bits of the index as a palette index.
  uint8_t index_4bit = (index >> 12);
  // Calculate the 8-bit offset from the palette index.
  uint8_t offset = (uint8_t)(index >> 4);
  // Get the palette entry from the 4-bit index
  const CRGB* entry = &(pal[0]) + index_4bit;
  uint8_t red1      = entry->red;
  uint8_t green1    = entry->green;
  uint8_t blue1     = entry->blue;

  uint8_t blend = offset && (blendType != NOBLEND);
  if (blend) {
    if (index_4bit == 15) {
      entry = &(pal[0]);
    } else {
      entry++;
    }
    // Calculate the scaling factor and scaled values for the lower palette value.
    uint8_t f1 = 255 - offset;
    red1       = scale8_LEAVING_R1_DIRTY(red1, f1);
    green1     = scale8_LEAVING_R1_DIRTY(green1, f1);
    blue1      = scale8_LEAVING_R1_DIRTY(blue1, f1);

    // Calculate the scaled values for the neighbouring palette value.
    uint8_t red2   = entry->red;
    uint8_t green2 = entry->green;
    uint8_t blue2  = entry->blue;
    red2           = scale8_LEAVING_R1_DIRTY(red2, offset);
    green2         = scale8_LEAVING_R1_DIRTY(green2, offset);
    blue2          = scale8_LEAVING_R1_DIRTY(blue2, offset);
    cleanup_R1();

    // These sums can't overflow, so no qadd8 needed.
    red1 += red2;
    green1 += green2;
    blue1 += blue2;
  }
  if (brightness != 255) {
     //nscale8x3_video(red1, green1, blue1, brightness);
    nscale8x3(red1, green1, blue1, brightness);
  }
   return CRGB(red1, green1, blue1);
}

void Something() {

  FastLED.clear();
  float ms                = millis() / 200.f;
  const float kHalfWidth  = WIDTH / 2;
  const float kHalfHeight = HEIGHT / 2;

  const float density = 1.1175f + 0.0275f * sinf(ms * 1.09f);
  for (float y = 0; y <= kHalfHeight + 2; y += density)
    for (float x = 0; x <= kHalfWidth + 2; x += density) {
      float hyp = hypotf(x, y) * -3.f;
      float fx  = sinf(ms + hyp / 8.f) * 84.f;
      float fy  = cosf(ms * .78f + hyp / 8.f) * 224.f;
      //CRGB col = ColorFromPaletteExtended_other(HeatColors_p, (ms * 24.f + hyp * 4.f) * 256.f, 255, LINEARBLEND);
      CRGB col = ColorFromPaletteExtended_other(*pal_arr[palette], (ms * 24.f + hyp * 4.f) * 256.f, 255, LINEARBLEND);      
      wu_pixel(256 * (x + kHalfWidth) + fx, 256 * (y + kHalfHeight) + fy, &col);
      if (x) wu_pixel(256 * (-x + kHalfWidth) + fx, 256 * (y + kHalfHeight) + fy, &col);
      if (y) wu_pixel(256 * (x + kHalfWidth) + fx, 256 * (-y + kHalfHeight) + fy, &col);
      if (x && y) wu_pixel(256 * (-x + kHalfWidth) + fx, 256 * (-y + kHalfHeight) + fy, &col);
    }
  EVERY_N_MILLISECONDS (5000) {IncPal(); }
}
/////////////////////////////////////////////Something