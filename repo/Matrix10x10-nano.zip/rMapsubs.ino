//upd. оптимизировано по переменным

////////// base vars /////////////
#define C_X WIDTH / 2
#define C_Y HEIGHT / 2

//unsigned long t; //defined higher
struct {
  uint8_t angle;
  uint8_t radius;
}
rMap[WIDTH][HEIGHT];
////////////////////////////

////////////// RadialWave /////////////////////
#define RW_SPEED 1

void RadialWaveRoutine() {
  FastLED.clear();
  if (loadingFlag) {
    loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = (atan2(x, y) / PI) * 128 + 127; //thanks ldirko 
        rMap[x + C_X][y + C_Y].radius = hypot(x, y); //thanks Sutaburosu
  }}}

//static byte speed = 1; //скорость. проверить. оставить или убрать
//static uint32_t t;
  t += RW_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius;
      leds[XY(x, y)] = CHSV(t + radius * (255 / WIDTH), 255, sin8(t * 4 + sin8(t * 4 - radius * (255 / WIDTH)) + angle * 3));
}}}  
//////////////////////// RadialWave

/////////////// Fire Radial ///////
#define FR_SCALEX 16
#define FR_SCALEY 1
#define FR_SPEED 24

void FireRadial () {

 if (loadingFlag) {
  loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = 128 * (atan2(y, x) / PI);
        rMap[x + C_X][y + C_Y].radius = hypot(x, y); //thanks Sutaburosu
      }
    }
  }
  //static byte scaleX = 16;
  //static byte scaleY = 1;

 // static byte speed = 24;
//  static uint32_t t;
  t += FR_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius;
      int16_t Bri = inoise8(angle*FR_SCALEX, (radius * FR_SCALEY)-t) - radius * (255 / HEIGHT);
      byte Col = Bri;
      if (Bri < 0) Bri = 0;
      if (Bri != 0) Bri = 256 - (Bri * 0.2);
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, Col, Bri), FR_SPEED);
    }
  } //delay(20)

}
/////////////////////////////////// Fire Radial

/////////////// Octopus ///////////
#define OCTOPUS_LEGS 3
#define OCTOPUS_SPEED 3
#define OCTOPUS_MAP (255 / max(HEIGHT, WIDTH))
//const uint8_t mappp = 255 / max(HEIGHT, WIDTH);

void Octopus () {

 FastLED.clear();
 if (loadingFlag) {
  loadingFlag = false;
      for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = 128 * (atan2(y, x) / PI);
        rMap[x + C_X][y + C_Y].radius = hypot(x, y) * OCTOPUS_MAP; //thanks Sutaburosu
      }
    }
  }
  //static byte speed = 3;
  //static uint16_t t;
  t += OCTOPUS_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius;
      leds[XY(x, y)] = CHSV(t / 2 - radius, 255, sin8(sin8((angle * 4 - radius) / 4 + t) + radius - t * 2 + angle * OCTOPUS_LEGS));
    }
  } //  delay(16);

}
/////////////////////////////////// Octopus

////////// Rainbow Tunnel ////////

#define RT_SCALEX 4
#define RT_SCALEY 4
#define RT_SPEED 2
#define RT_MAP (255 / WIDTH)

//const uint8_t mapp = 255 / WIDTH;

void RainbowTunnel () {

 FastLED.clear();
 if (loadingFlag) {
    loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = 128 * (atan2(y, x) / PI);
        rMap[x + C_X][y + C_Y].radius = hypot(x, y) * RT_MAP; //thanks Sutaburosu
      }
    }
  }
  //static byte scaleX = 4;
  //static byte scaleY = 4;
  //static byte speed = 2;
  //static uint16_t t;

  t += RT_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius;
      leds[XY(x, y)] = CHSV((angle*RT_SCALEX)-t+(radius*RT_SCALEY), 255, constrain(radius*2,0,255));
    }
  }
}
////////////////////////////////// Rainbow Tunnel

///////// Lotus /////////////////
#define LOTUS_PETALS 5
#define LOTUS_MAP (255 / WIDTH)
#define LOTUS_SPEED 2

void Lotus() {
  FastLED.clear();
  if (loadingFlag) {
    loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = 128 * (atan2(y, x) / PI);
        rMap[x + C_X][y + C_Y].radius = hypot(x, y) * LOTUS_MAP;
      }
    }
  }
//  static byte speed = 2;
//  static uint32_t t;

  t += LOTUS_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius;
      leds[XY(x, y)] = CHSV(248,181,sin8(t-radius+sin8(t + angle*LOTUS_PETALS)/5));

    }
  }
// delay(10);
}
//////////////////////////////// Lotus

//////////////// Hypnosis //////////////////// 

#define H_SPEED 4
void Hypnosis() {

  FastLED.clear();
  if (loadingFlag) {
    loadingFlag = false;
    for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = 128 * (atan2(y, x) / PI);
        rMap[x + C_X][y + C_Y].radius = hypot(x, y); //thanks Sutaburosu
      }
    }
  }
//  static uint16_t t;
  t += H_SPEED;
  for (uint8_t x = 0; x < WIDTH; x++) {
    for (uint8_t y = 0; y < HEIGHT; y++) {
      byte angle = rMap[x][y].angle;
      byte radius = rMap[x][y].radius * (255 / WIDTH);
      leds[XY(x, y)] = ColorFromPalette(RainbowStripeColors_p, t / 2 + radius + angle, sin8(angle + (radius * 2) - t));
//      leds[XY(x, y)] = ColorFromPalette(palette_arr[2], t / 2 + radius + angle, sin8(angle + (radius * 2) - t));
    }
  }
//  delay(16);
}
////////////////////////////////////////////// Hypnosis

//////////// Spinning Thing ////////
#define ST_SPEED 1

byte number = 1; //variates from 1 to 10. best from 1 to 5. 0 - circle
byte othernumber=11; //variates from 5 to 12 - speed //5

void SpinningThing() {

  FastLED.clear();
  if (loadingFlag) {
    loadingFlag = false;
      number += 1; 
      if (number > 5){ number = 1;}    

   for (int8_t x = -C_X; x < C_X + (WIDTH % 2); x++) {
      for (int8_t y = -C_Y; y < C_Y + (HEIGHT % 2); y++) {
        rMap[x + C_X][y + C_Y].angle = (atan2(x, y) / PI) * 128 + 127; //thanks ldirko 
        rMap[x + C_X][y + C_Y].radius = hypot(x, y); //thanks Sutaburosu
      }
    }
  }

//  static byte st_speed = 1;
//  static uint32_t t;

  t += ST_SPEED;
    for (uint8_t x = 0; x < HEIGHT; x++) {
    for (uint8_t y = 0; y < WIDTH; y++) {
      byte angle = rMap[y][x].angle;
      byte radius = rMap[y][x].radius;
      //здесь какая то ебучая хуйня с перепутанными x и y для несимметричных xy. причем в soulmatelights работает корректно. upd. скорей всего ROW и COL перепутаны выше. да и хер с ним
      leds[XY(y, x)] = CHSV(t + radius * (255 / HEIGHT), 255, sin8(sin8(t+angle*number+( radius * (255 / HEIGHT)))+t * othernumber + cos8(t * othernumber - radius * (255 / HEIGHT)) + angle * number));
    }
  }
  delay(30);
}
///////////////////////////////// Spinning Thing