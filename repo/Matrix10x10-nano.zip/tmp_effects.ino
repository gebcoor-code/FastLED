/////////////// FlyBycicle /////////////////
/*
void FlyBycicleRoutine() {
	
  if (loadingFlag) {
    loadingFlag = false;
  }
  FastLED.clear();
  for(byte i=0;i< 16;i++){
    drawPixelXYF((float)beatsin16(20,10,(WIDTH-2)*10,0,-beatsin16(10,1,2048)*i)/10,(float)beatsin16(20,10,(HEIGHT-2)*10,0,16384-beatsin16(10,0,2048)*i)/10,CHSV(0,0,255));
  }
}
//////////////////////////////////////////// FlyBycicle
*/

// used in Drops()
/*
void fillall() {

  if (loadingFlag) {
    loadingFlag = false;
  }

  for (int index = 0; index < NUM_LEDS; index++) {
    leds[index].g = index;
    leds[index].r = index;
    leds[index].b = index;
  }
}
////////////////////////////////////////
*/

/*
//////////////////Spiro /////////////////
#define CenterX ((WIDTH / 2) - 0.5)
#define CenterY ((HEIGHT / 2) - 0.5)
byte AM = 3;
float Angle;
bool change = true;
bool incenter; 

void SpiroRoutine() {

  if (loadingFlag) {
    AM = 3;   //to start from the begin
    loadingFlag = false;
  }	
	
  fadeToBlackBy(leds, NUM_LEDS, 50);
  float t = (float)millis() / 500.0f;
  float CalcRad = (sin(t / 2) + 1);
  if (CalcRad <= 0.001) {
    if(!incenter){
    AM += ((change * 2) - 1);
    Angle = 6.28318531 / AM;
    if (AM <= 1) change = true;
    else if (AM >= (WIDTH + HEIGHT) / 2) change = false;}
    incenter = 1;
  } else incenter = 0;
  float radX = CalcRad * CenterX / 2;
  float radY = CalcRad * CenterY / 2;
  for (byte i = 0; i < AM; i++) {
    drawPixelXYF((CenterX + sin(t + (Angle * i)) * radX), (CenterY + cos(t + (Angle * i)) * radY), ColorFromPalette(HeatColors_p, t*10 + ((256 / AM) * i)));
  }
}
///////////////////////////////////////// Spiroroutine
*/

////////// Starship /////////////////////
//const float SPEED_ADJ = (float)NUM_LEDS /256;
//#define SPEED_ADJ (float)NUM_LEDS /256
//#define chance 2048
//byte s_speed = 100; // 1-255
//const byte s_scale = 8;
//const byte DIR_CHARGE = 2; // Chance to change direction 1-5 

//already defined higher
//static double fmap(const double x, const double in_min, const double in_max, const double out_min, const double out_max){
//    return (out_max - out_min) * (x - in_min) / (in_max - in_min) + out_min;
//}

//defined higher in  FlyBycicle, somehow different, in case of problems - add new one
//void drawPixelXYF(float x, float y, CRGB color) {

/*void drawPixel(float x, float y, CRGB color) {
  drawPixelXYF(x, y, color);
  if (WIDTH > 24 || HEIGHT > 24) {
    if (x < WIDTH - 2) drawPixelXYF(x + 1, y, color);
    if (x > 1) leds[XY(x - 1, y)] += color;
    if (y < HEIGHT - 2) drawPixelXYF(x, y + 1, color);
    if (y > 1) drawPixelXYF(x, y - 1, color);
  }
}*/

//byte dir = 3;

//byte count = 0;
//float x1, y1;
//float speedFactor = fmap(s_speed, 1, 255, 0.25, 1);
/*
CRGB& getPixel(uint8_t x, uint8_t y) {
  return leds[XY(x, y)];
}

void Starship () {

    if (loadingFlag) {
     // dir = 3;
     // palette = 0;
     // count = 0;
      float speedFactor = fmap(s_speed, 1, 255, 0.25, 1);

	    loadingFlag = false;
    }	


randomSeed(millis());
  fadeToBlackBy(leds, NUM_LEDS, map(s_speed, 1, 255, 5, 10));
  switch (dir) {
    case 0: // Up
      for (byte x = 0; x < WIDTH; x++) {
		    if (x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (float y = 0; y < HEIGHT; y+=speedFactor) {
          getPixel(x, y) = (((int)y == HEIGHT - 1) ? CRGB::Black : getPixel(x, y + 1));
        }
      }
      break;
    case 1: // Up - Right 
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = 0; y < HEIGHT; y++) {
          getPixel(x, y) = ((y == HEIGHT - 1 or (int)x == WIDTH - 1) ? CRGB::Black : getPixel(x + 1, y + 1));
        }
      }
      break;
    case 2: // Right
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          getPixel(x, y) = (((int)x == WIDTH - 1) ? CRGB::Black : getPixel(x + 1, y));
        }
      }
      break;
    case 3: // Down - Right 
      for (float x = 0; x < WIDTH; x+=speedFactor) {
        if ((uint8_t)x > WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          getPixel(x, y) = (((int)x == WIDTH - 1 or y == 0) ? CRGB::Black : getPixel(x + 1, y - 1));
        }
      }
      break;
    case 4: // Down
      for (byte x = 0; x < WIDTH; x++) {
		    if (x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (float y = HEIGHT - 1; y > 0; y-=speedFactor) {
          getPixel(x, y) = (((int)y == 0) ? CRGB::Black : getPixel(x, y - 1));
        }
      }
      break;
    case 5: // Down - Left
      for (float x = WIDTH - 1; x > 0; x-=speedFactor) {
        if (!(uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          getPixel(x, y) = ((y == 0 or (int)x == 0) ? CRGB::Black : getPixel(x - 1, y - 1));
        }
      }
      break;
    case 6: // Left
      for (float x = WIDTH - 1; x > 0; x-=speedFactor) {
        if ((uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          getPixel(x, y) = ((int)x == 0 ? CRGB::Black : getPixel(x - 1, y));
        }
      }
      break;
    case 7: // Up - Left 
      for (float x = WIDTH -1; x >0; x-=speedFactor) {
        if ((uint8_t)x < WIDTH/2 and random(chance) < DIR_CHARGE) {count++; break;}
        for (byte y = HEIGHT - 1; y > 0; y--) {
          getPixel(x, y) = ((y == HEIGHT - 1 or (int)x == 0) ? CRGB::Black : getPixel(x - 1, y + 1));
        }
      }
      break;
  }


  for (byte i = 0; i < s_scale; i++) {
    x1 = (float)beatsin88(3840*speedFactor + i*256, 0, (WIDTH-1) *4, 0, s_scale*i*256) /4;
    y1 = (float)beatsin88(3072*speedFactor + i*256, 0, (HEIGHT-1) *4, 0, 0) /4;
    if ((x1 >= 0 and x1 <= WIDTH-1) and (y1 >= 0 and y1 <= HEIGHT -1)) drawPixel(x1, y1, ColorFromPalette(*pal_arr[palette], beatsin88(256*12.*speedFactor + i*256, 0, 255), 255));
  }

  blur2d(leds, WIDTH, HEIGHT, 64);


    dir = count%8;  
    palette = count%countpal; //qty of palettes in array pal_arr

}
//////////////////////////////////////// Starship
*/

/*
////////// Curve /////////////////////

#define subPix 0

void drawCurve(uint8_t x, uint8_t y, uint8_t x2, uint8_t y2, uint8_t x3, uint8_t y3, CRGB col) {
  float xu = 0.0, yu = 0.0, u = 0.0;
  int i = 0;
  for (u = 0.0; u <= 1.0; u += 0.01) {
    xu = pow(1 - u, 3) * x + 3 * u * pow(1 - u, 2) * x2 + 3 * pow(u, 2) * (1 - u) * x3 +
      pow(u, 3) * x3;
    yu = pow(1 - u, 3) * y + 3 * u * pow(1 - u, 2) * y2 + 3 * pow(u, 2) * (1 - u) * y3 +
      pow(u, 3) * y3;
    leds[XY(xu, yu)] += col;
  }
}

void drawCurveF(float x, float y, float x2, float y2, float x3, float y3, CRGB col) {
  float xu = 0.0, yu = 0.0, u = 0.0;
  int i = 0;
  for (u = 0.0; u <= 1.0; u += 0.01) {
    xu = pow(1 - u, 3) * x + 3 * u * pow(1 - u, 2) * x2 + 3 * pow(u, 2) * (1 - u) * x3 +
      pow(u, 3) * x3;
    yu = pow(1 - u, 3) * y + 3 * u * pow(1 - u, 2) * y2 + 3 * pow(u, 2) * (1 - u) * y3 +
      pow(u, 3) * y3;
    drawPixelXYF(xu, yu, col);
  }
}

//byte huee; //already defined higher in bursts
//#define c_speed - 5 //already defined higher in bursts

void Curve () {

 if (loadingFlag) {
  loadingFlag = false;
  hue = 0;
    }	

  fadeToBlackBy(leds, NUM_LEDS, 150);
  byte x1 = beatsin8(18 + c_speed, 0, (WIDTH - 1));
  byte x2 = beatsin8(23 + c_speed, 0, (WIDTH - 1));
  byte x3 = beatsin8(27 + c_speed, 0, (WIDTH - 1));
  
  byte y1 = beatsin8(20 + c_speed, 0, (HEIGHT - 1));
  byte y2 = beatsin8(26 + c_speed, 0, (HEIGHT - 1));
  byte y3 = beatsin8(15 + c_speed, 0, (HEIGHT - 1));
  
  if (subPix)
    drawCurveF(x1, y1, x2, y2, x3, y3, CHSV(hue, 255, 255));
  else
    drawCurve(x1, y1, x2, y2, x3, y3, CHSV(hue, 255, 255));
  blur2d(leds, WIDTH, HEIGHT, 64);
  hue++;

}
////////////////////////////////////// Curve
*/

/*
///////////// FireBengal ///////////
#define SPARKS_AM WIDTH + HEIGHT
//#define GenPosVar 1  //0 - in center, 1 - moves by boards set it as subparameter
float FADE_KOEF = .5;
float SpeedK = .98;
float SpeedDecX = .01;
float SpeedDecY = 0;
#define Bounce 0
#define GravityX 0
#define GravityY 1

int sparksPos[2][SPARKS_AM];
float sparksSpeed[2][SPARKS_AM];
float sparksFade[SPARKS_AM];
float sparksSat[SPARKS_AM];
byte sparksColor[SPARKS_AM];

int fb_genPos[2];
int fb_gravityPos[2];
static byte period = 10;
bool run = true;

//bool loadingFlag = true;
void reg(byte id, byte fb_fade) {
  sparksPos[0][id] = fb_genPos[0];
  sparksPos[1][id] = fb_genPos[1];
  sparksSpeed[0][id] = random(-10, 10);
  sparksSpeed[1][id] = random(-5, 20);
  sparksSat[id] = 10;
  sparksFade[id] = fb_fade; //здесь раньше было просто 255, но для fire bengal и для particles установил разные.
  sparksColor[id] = random();
}

void phisics(byte id) {
  if (SpeedK) {
    if (GravityX) {
      if (fb_gravityPos[0] < sparksPos[0][id])
        sparksSpeed[0][id] -= SpeedK;
      else
        sparksSpeed[0][id] += SpeedK;
    }
    if (GravityY) {
      if (fb_gravityPos[1] < sparksPos[1][id])
        sparksSpeed[1][id] -= SpeedK;
      else
        sparksSpeed[1][id] += SpeedK;
    }
  }
  sparksFade[id] -= (255. / (float)((HEIGHT + WIDTH) * FADE_KOEF));
  sparksSat[id] += (255. / (float)((WIDTH + WIDTH) * (FADE_KOEF - 0.2)));
  if (SpeedDecX || sparksSpeed[0][id]) {
    if (sparksSpeed[0][id] > 0)
      sparksSpeed[0][id] -= SpeedDecX;
    else
      sparksSpeed[0][id] += SpeedDecX;
    if (abs(sparksSpeed[0][id]) <= SpeedDecX)
      sparksSpeed[0][id] = 0;
  }
  if (SpeedDecY || sparksSpeed[1][id]) {
    if (sparksSpeed[1][id] > 0)
      sparksSpeed[1][id] -= SpeedDecY;
    else
      sparksSpeed[1][id] += SpeedDecY;
    if (abs(sparksSpeed[1][id]) <= SpeedDecY)
      sparksSpeed[1][id] = 0;
  }
  if (Bounce) { if (sparksPos[0][id] < 0 || sparksPos[0][id] >= WIDTH * 10) sparksSpeed[0][id] = -sparksSpeed[0][id]; if (sparksPos[1][id] < 0) sparksSpeed[1][id] = -sparksSpeed[1][id]; }
    sparksPos[0][id] += sparksSpeed[0][id];
    sparksPos[1][id] += sparksSpeed[1][id];
}

void wu_pixel(uint32_t x, uint32_t y, CRGB * col) { //awesome wu_pixel procedure by reddit u/sutaburosu
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t xy = XY((x >> 8) + (i & 1), (y >> 8) + ((i >> 1) & 1));
    leds[xy].r = qadd8(leds[xy].r, col -> r * wu[i] >> 8);
    leds[xy].g = qadd8(leds[xy].g, col -> g * wu[i] >> 8);
    leds[xy].b = qadd8(leds[xy].b, col -> b * wu[i] >> 8);
  }
}

void render(byte id, CRGB Col) {
  if (loadingFlag) {
    for (byte i = 0; i < SPARKS_AM; i++) {
      reg(i,255);
      for (byte a = 0; a < i; a++) {
        phisics(a);
      }
    }
    loadingFlag = false;
  }
  phisics(id);
  if (sparksPos[1][id] < ((HEIGHT - 1) * 10) and sparksPos[1][id] >= 0)
    if (sparksPos[0][id] < ((WIDTH - 1) * 10) and sparksPos[0][id] >= 0) {
      CRGB color = Col;
      wu_pixel(sparksPos[0][id] * 25.6, sparksPos[1][id] * 25.6, & color);
    }
}

void setGenPos(int x, int y) {
  fb_genPos[0] = x;
  fb_genPos[1] = y;
}

void setGravityPos(int x, int y) {
  fb_gravityPos[0] = x;
  fb_gravityPos[1] = y;
}

void setRegenRule(byte id, bool b) {
  if (b) reg(id,255);
}

void FireBengal (bool GenPosVar) { //0 - from center, 1 - moves by boards

  fadeToBlackBy(leds, NUM_LEDS, beatsin8(5, 20, 100));
  if(GenPosVar){setGenPos(beatsin16(10, 0, WIDTH * 10), beatsin16(10, 0, HEIGHT * 10, 0, 16384));}
  else {setGenPos(WIDTH * 5, HEIGHT * 5); }
  setGravityPos(0, 0);
  for (byte i = 0; i < SPARKS_AM; i++) {
    setRegenRule(i,(sparksPos[0][i] <= 0 || sparksPos[0][i] >= (WIDTH - 1) * 10 || sparksPos[1][i] < 0) ? 1 : 0);
    render(i, CHSV(sparksColor[i], constrain(sparksSat[i], 5, 255), constrain(sparksFade[i], 32, 255)));
      EVERY_N_SECONDS(period) {
        for (byte i = 0; i < SPARKS_AM; i++) reg(i,255);
        period = random(10, 60);}
  }
}
//////////////////////////////////// FireBengal
*/

/*
/////////////// Crazy Bee///////////

byte b_coord[2][2];
uint16_t offest;

void CrazyBee() {

 fadeToBlackBy(leds, NUM_LEDS, 2);
  long t = millis();
  offest++;
  b_coord[0][1] = b_coord[0][0];
  b_coord[1][1] = b_coord[1][0];
  byte x = inoise8(t, offest);
  x = qadd8(qsub8(x,16),scale8(qsub8(x,16),39));
  byte y = inoise8(offest,t);
  y = qadd8(qsub8(y,16),scale8(qsub8(y,16),39));
  b_coord[0][0] = map(x, 0, 255, 0, WIDTH - 1);
  b_coord[1][0] = map(y, 0, 255, 0, HEIGHT - 1);
  drawLine(b_coord[0][0], b_coord[1][0], b_coord[0][1], b_coord[1][1], CHSV(qadd8(qsub8(inoise8(offest),16),scale8(qsub8(inoise8(offest),16),39)),255,255));
  blur2d(leds, WIDTH, HEIGHT, 16);
}
//////////////////////////////////// Crazy Bee
*/

/*
/////////// Fire Brent ////////////
byte f_scale = 64;
byte f_speed = 7;
static uint32_t tt;

void FireBrent () {

 if (loadingFlag) {
  loadingFlag = false;
  tt = 0;
 }
  tt += f_speed;
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
     
      int16_t Bri = inoise8(x * f_scale, (y * f_scale) - tt) - (y * (255 / HEIGHT));
      byte Col = Bri;
       if (Bri < 0) Bri = 0; if(Bri != 0) Bri = 256 - (Bri * 0.2);
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, Col, Bri), f_speed);}
  }

}
/////////////////////////////////// Fire Brent
*/

/*
//////////// Wandering Souls /////

//--Settings------
#define w_Speed 255
#define w_Scale 8
#define Run 3 // 0-AllIn1Direction/1-beatsin/2-linear/3-circular
#define lamp 0
#define trace 1 //0-None/1-DimAll/2-Blur2D/3-wings(for Lamp)
#define reseting 10 //reset time in seconds, 0-off
#define subPixel 1 //
#define broad 0 //
//---------------
#define LIGHTERS_AM WIDTH + HEIGHT

struct{
int16_t PosX;
int16_t PosY;
uint16_t SpeedX;
uint16_t SpeedY;
byte SpeedZ;
byte Color;
byte Mass;
} lighterr[LIGHTERS_AM];

void WanderingSouls () {

 if (loadingFlag) {
    loadingFlag = false;
    randomSeed(millis());
    for (byte i = 0; i < LIGHTERS_AM; i++) {
      if (Run == 2) {
        lighterr[i].SpeedX = random(-10, 10);
        lighterr[i].SpeedY = random(-10, 10);
      } else if (Run == 3) {
        lighterr[i].SpeedX = random(-10, 10); //angle speed
        lighterr[i].SpeedY = random(0, 360); //angle
        lighterr[i].Mass = random(5, 10); //vspeed
      } else {
        lighterr[i].SpeedX = random(3, 25);
        lighterr[i].SpeedY = random(3, 25);
        lighterr[i].Mass = random(15, 100);
      }
      lighterr[i].SpeedZ = random(3, 25);
      lighterr[i].PosX = random(0, WIDTH * 10);
      lighterr[i].PosY = random(0, HEIGHT * 10);
      lighterr[i].Color = random(0, 9) * 28;
    }
  }
  switch (trace) {
    case 0:
      FastLED.clear();
      break;
    case 1:
      fadeToBlackBy(leds, NUM_LEDS, 50);
      break;
    case 3:
      fadeToBlackBy(leds, NUM_LEDS, 200);
      break;
  }
  
  for (byte i = 0; i < map(w_Scale, 1, 16, 2, LIGHTERS_AM); i++) {
    lighterr[i].Color++;
    switch (Run) {
      case 0:
        lighterr[i].PosX += beatsin8(lighterr[0].SpeedX * w_Speed, 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        lighterr[i].PosY += beatsin8(lighterr[0].SpeedY * w_Speed, 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        break;
      case 1:
        if (broad) {
          lighterr[i].PosX = beatsin16(lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1), 0, (WIDTH - 1) * 10);
          lighterr[i].PosY = beatsin16(lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1), 0, (HEIGHT - 1) * 10);
        } else {
          lighterr[i].PosX += beatsin16(lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1), 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
          lighterr[i].PosY += beatsin16(lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1), 0, lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 8)) - lighterr[i].Mass / 10 * ((HEIGHT + WIDTH) / 16);
        }
        break;
      case 2:
        lighterr[i].PosX += lighterr[i].SpeedX / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].PosY += lighterr[i].SpeedY / map(w_Speed, 1, 255, 10, 1);
        break;
      case 3:
        lighterr[i].PosX += lighterr[i].Mass * cos(radians(lighterr[i].SpeedY)) / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].PosY += lighterr[i].Mass * sin(radians(lighterr[i].SpeedY)) / map(w_Speed, 1, 255, 10, 1);
        lighterr[i].SpeedY += lighterr[i].SpeedX / map(w_Speed, 1, 255, 20, 2);
        break;
    }
    if (broad) {
      if (Run == 3) {
        if (lighterr[i].PosY < 0) {
          lighterr[i].PosY = 1;
          lighterr[i].SpeedY = 360 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosX < 0) {
          lighterr[i].PosY = 1;
          lighterr[i].SpeedY = 180 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosY >= (HEIGHT - 1) * 10) {
          lighterr[i].PosY = ((HEIGHT - 1) * 10) - 1;
          lighterr[i].SpeedY = 360 - lighterr[i].SpeedY;
        }
        if (lighterr[i].PosX >= (WIDTH - 1) * 10) {
          lighterr[i].PosX = ((WIDTH - 1) * 10) - 1;
          lighterr[i].SpeedY = 180 - lighterr[i].SpeedY;
        }
      } else if (Run == 1) {} else {
        if ((lighterr[i].PosX <= 0) || (lighterr[i].PosX >= (WIDTH - 1) * 10)) lighterr[i].SpeedX = -lighterr[i].SpeedX;
        if ((lighterr[i].PosY <= 0) || (lighterr[i].PosY >= (HEIGHT - 1) * 10)) lighterr[i].SpeedY = -lighterr[i].SpeedY;
      }
    } else {
      if (lighterr[i].PosX < 0) lighterr[i].PosX = (WIDTH - 1) * 10;
      if (lighterr[i].PosX > (WIDTH - 1) * 10) lighterr[i].PosX = 0;
      if (lighterr[i].PosY < 0) lighterr[i].PosY = (HEIGHT - 1) * 10;
      if (lighterr[i].PosY > (HEIGHT - 1) * 10) lighterr[i].PosY = 0;
    }
    CRGB color = CHSV((lamp) ? 0 : lighterr[i].Color, 255, (trace == 3) ? 128 + random8(2) * 111 : beatsin8(lighterr[i].SpeedZ / map(w_Speed, 1, 255, 10, 1), 128, 255));
    if (subPixel)
      wu_pixel(lighterr[i].PosX * 25.6, lighterr[i].PosY * 25.6, &color);
    else
      leds[XY(lighterr[i].PosX / 10, lighterr[i].PosY / 10)] += color;
  }
  if(lamp){
  for(int i=0; i < NUM_LEDS; i++){
    leds[i]=CHSV(50,10,255-leds[i].r);
  }}
  if (reseting > 0) {
    EVERY_N_SECONDS(reseting) {
      randomSeed(millis());
      for (byte i = 0; i < map(w_Scale, 1, 16, 2, LIGHTERS_AM); i++) {
        if (Run == 2) {
          lighterr[i].SpeedX = random(-10, 10);
          lighterr[i].SpeedY = random(-10, 10);
        } else if (Run == 3) {
          lighterr[i].SpeedX = random(-10, 10);
          lighterr[i].SpeedY = random(0, 360);
          lighterr[i].Mass = random(5, 10);
        } else {
          lighterr[i].SpeedX = random(3, 25);
          lighterr[i].SpeedY = random(3, 25);
        }
        lighterr[i].SpeedZ = random(3, 25);
        lighterr[i].Mass + random(-25, 25);
      }
    }
  }
  if(trace == 2){
    blur2d(leds, WIDTH, HEIGHT, 64);
  } //  delay(16);
}
////////////////////////////////// Wandering Souls
*/

/*
/////// Lost Lands //////////////

void LostLands () {

uint16_t t = millis() / 10;
  for(uint8_t x = 0; x < WIDTH; x++){
    for(uint8_t y = 0; y < HEIGHT; y++){
      leds[XY(x, y)] = ColorFromPalette(CloudColors_p, inoise8((x * 100), (y * 10) - t, t / 2), 255 - (abs(x - WIDTH / 2) * (255 / WIDTH * 2))) - CHSV(0, 0, inoise8(x * 50, y * 50, t));
    }
  }
}
///////////////////////////////// Lost Lands
*/

/*
///////// Gyroscope ///////////
void drawLineF(float x1, float y1, float x2, float y2,
  const CRGB & col1,
    const CRGB & col2) {
  float deltaX = fabs(x2 - x1);
  float deltaY = fabs(y2 - y1);
  float steps = 255 / max(deltaX, deltaY);
  float error = deltaX - deltaY;
  CRGB col = col1;
  float signX = x1 < x2 ? 0.5 : -0.5;
  float signY = y1 < y2 ? 0.5 : -0.5;
  
  while (x1 != x2 || y1 != y2) {
    if ((signX > 0. && x1 > x2 + signX) || (signX < 0. && x1 < x2 + signX)) break;
    if ((signY > 0. && y1 > y2 + signY) || (signY < 0. && y1 < y2 + signY)) break;
    drawPixelXYF(x1, y1, nblend(col, col2, steps++));
    float error2 = error;
    if (error2 > -deltaY) {
      error -= deltaY;
      x1 += signX;
    }
    if (error2 < deltaX) {
      error += deltaX;
      y1 += signY;
    }
  }
}

#define g_am 6
float angle_a[g_am];
float angle_b[g_am];

void Gyroscope() {

  //static byte g_hue;
  if (loadingFlag) {
    for (byte i = 0; i < g_am; i++) {
      angle_a[i] = radians(random());
      angle_b[i] = radians(random());
    }
    loadingFlag = 0;
  }
  hue++;
  for (byte i = 1; i < g_am+1; i++) {
    angle_a[i-1] = fmod(angle_a[i-1] + (beatsin8(3, 0, 50, 0, 4 * i)-25)/100.f,6.28318531);
    angle_b[i-1] = fmod(angle_b[i-1] + (beatsin8(3, 0, 50, 0, (8 * i)+64)-25)/100.f,6.28318531);
    float radA1= angle_a[i-1]+3.14159265;
    //float radB1= angle_b[i-1]+3.14159265;

    float x = (1+sin(angle_a[i-1]) * cos(angle_b[i-1])) * WIDTH/2;
    float y = (1+sin(angle_a[i-1]) * sin(angle_b[i-1])) * HEIGHT/2;
    float z = cos(angle_a[i-1]);
    
    float x1 = WIDTH-1-x;//(1+sin(radA1) * cos(radB1)) * WIDTH/2;
    float y1 = HEIGHT-1-y;//(1+sin(radA1) * sin(radB1)) * HEIGHT/2;
    float z1 = cos(radA1);
    
    drawLineF(x,y,x1,y1, CHSV(127 + (i * 32) + hue, 255, constrain(112 * (1 + z) + 30, 96, 255)), CHSV(i * 32 + hue, 255, constrain(112 * (1 + z1) + 30, 96, 255)));
  }
  fadeToBlackBy(leds, NUM_LEDS, 64);
}
/////////////////////////////// Gyroscope
*/

/*
////// Drops///////////////////
#define d_Sat (255)
#define d_Hue (150)
#define MaxRad WIDTH+HEIGHT

CRGBPalette16 currentPalette(PartyColors_p);

//uint8_t d_hue;

int rad[(HEIGHT+WIDTH)/8];
byte posx[(HEIGHT+WIDTH)/8],posy[(HEIGHT+WIDTH)/8];

void drawPixelXY2(uint8_t x, uint8_t y, CRGB color) {
  if (x < 0 || x > (WIDTH - 1) || y < 0 || y > (HEIGHT - 1)) return;
    leds[XY(x,y)] += color;
}

void drawCircle(int x0, int y0, int radius, const CRGB &color){
  int aa = radius, bb = 0;
  int radiusError = 1 - aa;

  if (radius == 0) {
    drawPixelXY2(x0, y0, color);
    return;
  }
  while (aa >= bb)  {
    drawPixelXY2(aa + x0, bb + y0, color);
    drawPixelXY2(bb + x0, aa + y0, color);
    drawPixelXY2(-aa + x0, bb + y0, color);
    drawPixelXY2(-bb + x0, aa + y0, color);
    drawPixelXY2(-aa + x0, -bb + y0, color);
    drawPixelXY2(-bb + x0, -aa + y0, color);
    drawPixelXY2(aa + x0, -bb + y0, color);
    drawPixelXY2(bb + x0, -aa + y0, color);
    bb++;
    if (radiusError < 0)
      radiusError += 2 * bb + 1;
    else {
      aa--;
      radiusError += 2 * (bb - aa + 1);
    }
  }
}

void Drops() {

if (loadingFlag)
  {loadingFlag = false;
    currentPalette = CloudColors_p;
    hue = d_Hue;
      for (int i = 0; i < ((HEIGHT+WIDTH)/8)-1; i++)
  {
    posx[i]=random(WIDTH-1);
    posy[i]=random(HEIGHT-1);
    rad[i] = random(-1,MaxRad);
    }
  }
    fill_solid( currentPalette, 16, CHSV(hue,Sat,230));
    currentPalette[10] = CHSV(hue,Sat-60,255);
    currentPalette[9] = CHSV(hue,255-Sat,210);
    currentPalette[8] = CHSV(hue,255-Sat,210);
    currentPalette[7] = CHSV(hue,Sat-60,255);
    fillAll(ColorFromPalette(currentPalette,1));
     for (uint8_t i = ((HEIGHT+WIDTH)/8)-1; i > 0 ; i--){
    drawCircle(posx[i],posy[i], rad[i],ColorFromPalette(currentPalette,(256/16)*8.5-rad[i]));
    drawCircle(posx[i],posy[i], rad[i]-1,ColorFromPalette(currentPalette,(256/16)*7.5-rad[i]));
    if(rad[i] >= MaxRad){
    rad[i]=-1;
    posx[i]=random(WIDTH);
    posy[i]=random(HEIGHT);}
    else
    rad[i]++;
}
if(d_Hue == 0)
hue++;
blur2d(leds, WIDTH, HEIGHT, 64);
//delay(40);
}
/////////////////////////////// Drops*/

/*
/////// Fire with Sparks /////////
byte fs_scale = 50;
byte fs_speed = 35; // 20-100

bool withSparks = true; // true/false

const byte sparksCount = WIDTH/4;
const uint8_t spacer = HEIGHT/4;

static uint32_t ttt;

uint16_t RGBweight(uint16_t idx) {
  return (leds[idx].r + leds[idx].g + leds[idx].b);
}

class Spark {
  private:
    CRGB color;
    uint8_t Bri;
    //uint8_t fs_Hue;
    float x, y, speedy = (float)random(5, 30) / 10;
  
  public:
    void addXY(float nx, float ny) {
      //drawPixelXYF(x, y, 0);
      x += nx;
      y += ny * speedy;
    }

    float getY() {
      return y;
    }

    void reset() {
      uint32_t peak = 0;
      speedy = (float)random(5, 30) / 10;
      y = random(HEIGHT / 4, HEIGHT / 2);
      for (uint8_t i=0; i < WIDTH; i++) {
        uint32_t temp = RGBweight(XY(i, y));
        if (temp > peak) {
          x = i;
          peak = temp;
        }
      }
      
      color = leds[XY(x, y)];
      
    }

    void draw() {
      color.fadeLightBy(256 / (HEIGHT * 0.75));
      drawPixelXYF(x, y, color);
    }
}; 

Spark sparks[sparksCount];

bool firstStart = true;


void FireSparks() {

  if(firstStart) {
    for (byte i = 0; i < sparksCount; i++) sparks[i].reset();
    firstStart = false;
  }
  ttt += fs_speed;

  if (withSparks)
    for (byte i = 0; i < sparksCount; i++) {
      sparks[i].addXY((float)random(-1,2)/2, 0.75);
      if (sparks[i].getY() > HEIGHT and !random(0, 50)) sparks[i].reset();
      else sparks[i].draw();
    }

  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
     
      int16_t Bri = inoise8(x * fs_scale, (y * fs_scale) - ttt) - ((withSparks ? y + spacer : y) * (255 / HEIGHT));
      byte Col = Bri;
       if (Bri < 0) Bri = 0; if(Bri != 0) Bri = 256 - (Bri * 0.2);
      nblend(leds[XY(x, y)], ColorFromPalette(HeatColors_p, Col, Bri), fs_speed);}
  }
//  delay(16);
}
////////////////////////////////// Fire with Sparks
*/
/*
////////////////// Stars ///////
#define trackingOBJECT_MAX_COUNT WIDTH*2  // максимальное количество отслеживаемых объектов (очень вли¤ет на расход пам¤ти). Тестил - хватает и 24 вполне; (100U) ; используется еще в source

//константы размера матрицы вычисл¤етс¤ только здесь и не мен¤етс¤ в эффектах
const uint8_t CENTER_X_MINOR =  (WIDTH / 2) -  ((WIDTH - 1) & 0x01); // центр матрицы по » —”, сдвинутый в меньшую сторону, если ширина чЄтна¤
const uint8_t CENTER_Y_MINOR = (HEIGHT / 2) - ((HEIGHT - 1) & 0x01); // центр матрицы по »v–? ”, сдвинутый в меньшую сторону, если высота чЄтна¤

#define bballsMaxNUM trackingOBJECT_MAX_COUNT
#define spirocenterX CENTER_X_MINOR
#define spirocenterY CENTER_Y_MINOR
#define STAR_BLENDER 128U             // хз что это 
#define CENTER_DRIFT_SPEED 6U         // скорость перемещени¤ плавающего центра возникновени¤ звЄзд
unsigned int  s_counter;//, ringdelay;//, bringdelay, sumthum;
int16_t radius2;//, fpeed[WIDTH * 3], fcount[WIDTH * 3], fcountr[WIDTH * 3];//, xxx, yyy, dot = 3, rr, gg, bb, adjunct = 3;
float driftx, drifty;//, locusx, locusy, xcen, ycen, yangle, xangle;
float cangle, sangle;//xfire[WIDTH * 3], yfire[WIDTH * 3], radius, xslope[MATRIX_WIDTH * 3], yslope[MATRIX_WIDTH * 3]; 

void drawstar(int16_t xlocl, int16_t ylocl, int16_t biggy, int16_t little, int16_t points, int16_t dangle, uint8_t koler) {// random multipoint star
  radius2 = 255 / points;
  for (int i = 0; i < points; i++)  {
    mydrawLine(xlocl + ((little * (sin8(i * radius2 + radius2 / 2 - dangle) - 128.0)) / 128), ylocl + ((little * (cos8(i * radius2 + radius2 / 2 - dangle) - 128.0)) / 128), xlocl + ((biggy * (sin8(i * radius2 - dangle) - 128.0)) / 128), ylocl + ((biggy * (cos8(i * radius2 - dangle) - 128.0)) / 128), CHSV(koler , 255, 255),0,0);
    mydrawLine(xlocl + ((little * (sin8(i * radius2 - radius2 / 2 - dangle) - 128.0)) / 128), ylocl + ((little * (cos8(i * radius2 - radius2 / 2 - dangle) - 128.0)) / 128), xlocl + ((biggy * (sin8(i * radius2 - dangle) - 128.0)) / 128), ylocl + ((biggy * (cos8(i * radius2 - dangle) - 128.0)) / 128), CHSV(koler , 255, 255),0,0);
    }
}

uint8_t bballsCOLOR[bballsMaxNUM] ;                   // цвет звезды (используем повторно массив эффекта ћ¤чики)
uint8_t bballsX[bballsMaxNUM] ;                       // количество углов в звезде (используем повторно массив эффекта ћ¤чики)
int   bballsPos[bballsMaxNUM] ;                       // задержка пуска звезды относительно счЄтчика (используем повторно массив эффекта ћ¤чики)
uint8_t bballsNUM;                                    // количество звЄзд (используем повторно переменную эффекта ћ¤чики)

void Stars() {

  dimAll(89U);

  if (loadingFlag) {
    loadingFlag = false;
//    setCurrentPalette();
    driftx = random8(4, WIDTH - 4);//set an initial location for the animation center
    drifty = random8(4, HEIGHT - 4);// set an initial location for the animation center
    
    cangle = (sin8(random(25, 220)) - 128.0) / 128.0;//angle of movement for the center of animation gives a float value between -1 and 1
    sangle = (sin8(random(25, 220)) - 128.0) / 128.0;//angle of movement for the center of animation in the y direction gives a float value between -1 and 1
    //shifty = random (3, 12);//how often the drifter moves будет CENTER_DRIFT_SPEED = 6

    //pointy = 7; теперь количество углов у каждой звезды своЄ
    bballsNUM = (WIDTH + 6U) / 2U;//(modes[0].Scale - 1U) / 99.0 * (bballsMaxNUM - 1U) + 1U;
    if (bballsNUM > bballsMaxNUM) bballsNUM = bballsMaxNUM;
    for (uint8_t num = 0; num < bballsNUM; num++) {
      bballsX[num] = random8(3, 9);//pointy = random8(3, 9); // количество углов в звезде
      bballsPos[num] = s_counter + (num << 2) + 1U;//random8(50);//modes[0].Scale;//random8(50, 99); // задержка следующего пуска звезды
      bballsCOLOR[num] = random8();
    }
  }
  s_counter++;
  if (driftx > (WIDTH - spirocenterX / 2U))//change directin of drift if you get near the right 1/4 of the screen
    cangle = 0 - fabs(cangle);
  if (driftx < spirocenterX / 2U)//change directin of drift if you get near the right 1/4 of the screen
    cangle = fabs(cangle);
  if (s_counter % CENTER_DRIFT_SPEED == 0)
    driftx = driftx + cangle;//move the x center every so often

  if (drifty > ( HEIGHT - spirocenterY / 2U))// if y gets too big, reverse
    sangle = 0 - fabs(sangle);
  if (drifty < spirocenterY / 2U) // if y gets too small reverse
    sangle = fabs(sangle);
  if ((s_counter + CENTER_DRIFT_SPEED / 2U) % CENTER_DRIFT_SPEED == 0)
    drifty =  drifty + sangle;//move the y center every so often
  
  for (uint8_t num = 0; num < bballsNUM; num++) {
    if (s_counter >= bballsPos[num])//(s_counter >= ringdelay)
    {
      if (s_counter - bballsPos[num] <= WIDTH + 5U) {  //(s_counter - ringdelay <= WIDTH + 5){
        //drawstar(driftx  , drifty, 2 * (s_counter - ringdelay), (s_counter - ringdelay), pointy, blender + h, h * 2 + 85);
        drawstar(driftx  , drifty, 2 * (s_counter - bballsPos[num]), (s_counter - bballsPos[num]), bballsX[num], STAR_BLENDER + bballsCOLOR[num], bballsCOLOR[num] * 2);//, h * 2 + 85);// что, бл, за 85?!
        bballsCOLOR[num]++;
      }
      else
        //bballsX[num] = random8(3, 9);//pointy = random8(3, 9); // количество углов в звезде
        bballsPos[num] = s_counter + (bballsNUM << 1) + 1U;//random8(50, 99);//modes[0].Scale;//random8(50, 99); // задержка следующего пуска звезды
    }
  }
  //delay(30);
}
//////////////////////////////// Stars
*/

/*
///////////// PulseTest //////////////////////
void PulseTest() {

  if (loadingFlag) {  loadingFlag = false;}	  
//  fadeToBlackBy(leds, NUM_LEDS, 2);  
  static byte r = 9; //8  
  uint16_t apt=millis()/10;
  byte x = (apt/14)%WIDTH;
  byte y = (sin8(apt*5)+sin8(apt*4)+sin8(apt*2))/3*r/255;
  uint16_t index = XY (x,HEIGHT/2-r/2+y);
  leds[index].setHue(y*16-100); 
  blur2d(leds, WIDTH, HEIGHT, 3);
}
////////////////////////////////////////////// PulseTest
*/

/*
//////// Twister /////////////////
void mydrawLine_twister(byte x, byte x1, byte y, CHSV color, bool dot, bool grad, byte numline, byte side, byte sinOff, uint16_t atw) { // my ugly hori line draw function )))
  
  byte steps = abs8(x1 - x)+1 ;
  for (uint16_t i = 1; i <= steps; i++) {
    byte dx = lerp8by8(x1, x, i * 255 / steps);
    uint16_t index = XY(dx, y);
    leds[index] = color; 
    if (grad) leds[index] %= (sin8(numline*8+side*64+atw+sinOff)+i*255/steps)/2; //for draw gradient line  
  }
    if (dot) { //add white point at the ends of line 
    leds[XY(x, y)] = CRGB::Black;
    leds[XY(x1, y)] = CRGB::Black;
  }
}

void Twister() {
  
    uint16_t a_tw = millis() / 12;
    LEDS.clear();
  
    for (uint16_t i = 0; i < HEIGHT; i++) {
    byte sinOff = sin8(i*8/PI+cos8(a_tw/2+i)/4+a_tw/3);

    byte x1 = sin8(sinOff+a_tw)*(WIDTH)/255;
    byte x2 = sin8(sinOff+a_tw+64)*(WIDTH)/255;
    byte x3 = sin8(sinOff+a_tw+128)*(WIDTH)/255;
    byte x4 = sin8(sinOff+a_tw+192)*(WIDTH)/255;
    x1= x1>=WIDTH? (WIDTH-1):x1;
    x2= x2>=WIDTH? (WIDTH-1):x2;
    x3= x3>=WIDTH? (WIDTH-1):x3;
    x4= x4>=WIDTH? (WIDTH-1):x4;

    hue = sin8(a_tw/20);
    if (x1<x2) mydrawLine_twister(x1, x2, i, CHSV (hue,255,255), 1, 1,i,0,sinOff,a_tw);
    if (x2<x3) mydrawLine_twister(x2, x3, i, CHSV (hue+64,255,255), 1, 1,i,1,sinOff,a_tw);
    if (x3<x4) mydrawLine_twister(x3, x4, i, CHSV (hue+128,255,255), 1, 1,i,2,sinOff,a_tw);
    if (x4<x1) mydrawLine_twister(x4, x1, i, CHSV (hue+192,255,255), 1,1,i,3,sinOff,a_tw);
    } 
  //GammaCorrection(); //uncomment this when load on matrix
}
////////////////////////////////////////////// Twister
*/

/*
///////////// DNASin //////////////////////
#define BRIGHTNESS 255
#define mn 255 / (WIDTH * 2)
#define speeds 30 // speed of rotation 
byte freq = 9; //change this will made spiral big or small 
byte dir = 1; //also used in starships

void DNASin() {

  if (loadingFlag) {  loadingFlag = false;  dir=1;}	  

  EVERY_N_MILLISECONDS(500) {
     freq+=dir;
    if (freq > 15 || freq < 1)
      dir *=-1;
   }

  fadeToBlackBy(leds, NUM_LEDS, 30);
    
  for (int i = 0; i < HEIGHT; i++) {
    uint16_t ms = millis();
    leds[i * WIDTH + beatsin8(speeds, 0, WIDTH - 1, 0, i * freq)] += CHSV(ms / 30 + i * 255 / (HEIGHT - 1), 255, beatsin8(speeds, 30, BRIGHTNESS, 0, i * mn + 64));
    leds[i * WIDTH + beatsin8(speeds, 0, WIDTH - 1, 0, 128 + i * freq)] += CHSV(ms / 30 + ((i * 255 / (HEIGHT - 1)) + 128), 255, beatsin8(speeds, 30, BRIGHTNESS, 0, i * mn + 192));
  }
 blur2d(leds, WIDTH, HEIGHT, 30); //64
}
////////////////////////////////////////////// DNASin почти близнец withoutsin. апгрейдил изменяющейся частотой
*/

/*
/////////////// StarShips /////////////////// 
void MoveX(int8_t delta) {
  if (delta) {
    if (delta > 0) {
      for (uint8_t y = 0; y < HEIGHT; y++) {
        for (uint8_t x = 0; x < WIDTH; x++) {
          leds[XY(x, y)] = leds[XY(x + delta, y)];
        }
      }
    } else {
      for (uint8_t y = 0; y < HEIGHT; y++) {
        for (uint8_t x = WIDTH- 1; x > 0; x--) {
          leds[XY(x, y)] = leds[XY(x + delta, y)];
        }
      }
    }
  }
}

void MoveY(int8_t delta) {
  if (delta) {
    if (delta > 0) {
      for (uint8_t x = 0; x < WIDTH; x++) {
        for (uint8_t y = 0; y < HEIGHT; y++) {
          leds[XY(x, y)] = leds[XY(x, y + delta)];
        }
      }
    } else {
      for (uint8_t x = 0; x < WIDTH; x++) {
        for (uint8_t y = HEIGHT - 1; y > 0; y--) {
          leds[XY(x, y)] = leds[XY(x, y + delta)];
        }
      }
    }
  }
}

void drawPixel_ss(byte x, byte y, CRGB color) {
  leds[XY(x, y)] += color;

//почему 24?
  if (WIDTH > 24 || HEIGHT > 24) {
    leds[XY(x + 1, y)] += color;
    leds[XY(x - 1, y)] += color;
    leds[XY(x, y + 1)] += color;
    leds[XY(x, y - 1)] += color;
  }
}

void StarShips() {

 if (loadingFlag) {loadingFlag = false; dir=0;}

  fadeToBlackBy(leds, NUM_LEDS, 16);
  switch (dir) {
    case 0:      MoveX(1);                       break;
    case 1:      MoveX(1);       MoveY(-1);      break;
    case 2:      MoveY(-1);                      break;
    case 3:      MoveX(-1);      MoveY(-1);      break;
    case 4:      MoveX(-1);                      break;
    case 5:      MoveX(-1);      MoveY(1);       break;
    case 6:      MoveY(1);                       break;
    case 7:      MoveX(1);       MoveY(1);       break;
  }
    for (byte i = 0; i < 8; i++) {
    byte x = beatsin8(12 + i, 2, WIDTH - 3);
    byte y = beatsin8(15 + i, 2, HEIGHT - 3);
    drawPixel_ss(x, y, ColorFromPalette(RainbowColors_p, beatsin8(12 + i, 0, 255), 255));
  }
  blur2d(leds, WIDTH, HEIGHT, 32);
  EVERY_N_SECONDS(2) {
    if (dir == 7) dir = 0;
    else dir++;
  }
}
///////////////////////////////////////////// StarShips
*/

/*
////////////// DNA Spirale ///////////////////// глючит чето, белое только
#define DNA_speeds 40 // speed of rotation 
#define DNA_freq 6 //change this will made spiral big or small 

void DNAspiralHoriz() { //rotated for 90 degrees to work properly on 24*12

  if (loadingFlag) {
    loadingFlag = false;
    hue=0;
  }
  
//static byte hue = 0;
  int ms = millis() / 10;
  nscale8(leds, NUM_LEDS, 120);
  
	for (int i = 0; i < WIDTH; i++) {
		int y = beatsin8(DNA_speeds, 0, WIDTH - 11, 0, i * DNA_freq) + beatsin8(DNA_speeds - 7, 0, WIDTH - 11, 0, i * DNA_freq + 128);
		int y1 = beatsin8(DNA_speeds, 0, WIDTH - 11, 0, 128 + i * DNA_freq) + beatsin8(DNA_speeds - 7, 0, WIDTH - 11, 0, 128 + 64 + i * DNA_freq); 
    
		hue = i * 128 / (WIDTH - 1) + ms;
		CRGB color = CHSV(hue, 255, 255);
    
		if ((i + ms / 8) & 3) mydrawLine_DNA(y / 2, y1 / 2, i, color, 1, 1);
	}
} /////////// end DNA spirale Horiz
*/

/*
/////////////// снегопад 3.0 //////////////////
#define SNOW_DENSE 10     // плотность снегопада

void snowRoutine() {
  byte rr;    
   for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      if (leds[XY(x,y+1)] != CRGB (0x000000)) {
        rr=random(10);
        if ((rr !=  1) && (rr != 2)) leds[XY(x,y)] = leds[XY(x,y+1)];
        if ((rr == 1) && (x < WIDTH - 1)) leds[XY(x+1,y)] = leds[XY(x,y+1)];
        if ((rr == 2) && (x > 0)) leds[XY(x-1,y)] = leds[XY(x,y+1)];
        leds[XY(x,y+1)] = CRGB (0x000000);
      }
    }
  }

  for (byte x = 0; x < WIDTH; x++) {
      if ((leds[XY(x,HEIGHT-2)] == CRGB (0x000000)) && (random(0, SNOW_DENSE) == 0 ))
        leds[XY(x,HEIGHT-1)] = 0xE0FFFF - 0x101010 * random(0,5);
    else
      leds[XY(x,HEIGHT-1)] = CRGB(0x000000);
  }

  for (byte x = 0; x < WIDTH; x++) {
      leds[XY(x,0)] = 0;
  }

  //blur2d (leds,WIDTH, HEIGHT, 20);
   nscale8(leds, NUM_LEDS, 200);
}
/////////////////////////////////////// SNOW
*/
/*
////////////// MATRIX //////////////////////////// поправить drawpixel и getpixel через [X,Y]
void matrixRoutine() {
  if (loadingFlag) {
    loadingFlag = false;
    FastLED.clear();
  }
  for (byte x = 0; x < WIDTH; x++) {
    uint32_t thisColor = getPixColorXY(x, HEIGHT - 1);
    if (thisColor == 0)
      drawPixelXY(x, HEIGHT - 1, 0x00FF00 * (random(0, 10) == 0));
    else if (thisColor < 0x002000)
      drawPixelXY(x, HEIGHT - 1, 0);
    else
      drawPixelXY(x, HEIGHT - 1, thisColor - 0x002000);
  }

//  move all down
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT - 1; y++) {
      drawPixelXY(x, y, getPixColorXY(x, y + 1));
    }
  }
}
/////////////////////////////////////////////MATRIX
*/
/*
///// Ex9 - NiceOne ////////////////////
#define kBorderWidth 2

void Ex9NiceOne () {

    if (loadingFlag) {
	  loadingFlag = false;
    }	

uint8_t blurAmount = 20; // beatsin8(2, 10, 255);
  blur2d(leds, WIDTH, HEIGHT, blurAmount);

  // Use two out-of-sync sine waves
  uint8_t i = beatsin8(27, kBorderWidth, HEIGHT - kBorderWidth);
  uint8_t j = beatsin8(41, kBorderWidth, WIDTH - kBorderWidth);
  // Also calculate some reflections
  uint8_t ni = (WIDTH - 1) - i;
  uint8_t nj = (WIDTH - 1) - j;

  // The color of each point shifts over time, each at a different speed.
  uint16_t ms = millis();
  leds[XY(i, j)] += CHSV(ms / 11, 200, 255);
  leds[XY(j, i)] += CHSV(ms / 13, 200, 255);
  leds[XY(ni, nj)] += CHSV(ms / 17, 200, 255);
  leds[XY(nj, ni)] += CHSV(ms / 29, 200, 255);
  leds[XY(i, nj)] += CHSV(ms / 37, 200, 255);
  leds[XY(ni, j)] += CHSV(ms / 41, 200, 255);

}
//////////////////////////////////////// Ex9-NiceOne
*/

/*
///////////// Flower250 //////////
//float f_c = 0.3;   //diameter  0.3 - for square
float angle = 0.1;
#define f_c 0.4f
int  counter = 0;

void Flower250 () {

 if (loadingFlag) {
    loadingFlag = false;
//    c = 0.4;
//    angle = 0.1;
    counter = 0;
 }
 EVERY_N_MILLISECONDS(4000) {
    angle +=0.1;
  }

float n = triwave8( counter)*2.2; 
    float a = n * angle;
    float r = f_c * sqrt16(n);
    byte x = r * cos(a)+WIDTH/2;
    byte y = r * sin(a)+HEIGHT/2;
   leds [XY(x,y)] += CHSV (millis(),255,255);
        counter +=1; 
   fadeToBlackBy(leds, NUM_LEDS, 5); //20

}
////////////////////////////////// Flower250
*/

/*
//////////Colored Bursts /////////////
//byte huee = 0;
static byte numLines = 10;    

#define c_speed - 5 //global speed of dots move  

void ColoredBursts () {

 if (loadingFlag) {
  loadingFlag = false;
  hue = 0;
    }	

  EVERY_N_MILLISECONDS(30) { hue++; } //30 - speed of hue change
  EVERY_N_MILLISECONDS(1000) {   // for change number of lines. Can be commented in not need
    if (random8(2)) {
      numLines++;
      if (numLines > 15) numLines = 15;
    } else { numLines--; if (numLines < 5) numLines = 5; }
  }
  
    fadeToBlackBy(leds, NUM_LEDS, 40);
  
  for (byte i = 0; i < numLines; i++) {
    
    byte x1 = beatsin8(12 + c_speed, 0, (WIDTH - 1));
    byte x2 = beatsin8(10 + c_speed, 0, (WIDTH - 1));
    byte y1 = beatsin8(25 + c_speed, 0, (HEIGHT - 1), 0, i * 24);
    byte y2 = beatsin8(20 + c_speed, 0, (HEIGHT - 1), 0, i * 48 + 64);
    
    CRGB color = CHSV(i * 255 / 10 + hue, 255, 255);
    hue++;
    mydrawLine(x1, x2, y1, y2, color, 0, 1); // for move
    // mydrawLine(WIDTH/2, HEIGHT/2, y1, y2, color, 0, 1); // for center
  }
  
  blur2d(leds, WIDTH, HEIGHT, 8);
}
////////////////////////////////////// Colored Bursts
*/

/*
///////////// SinPlasma //////////////////////
void SinPlasma() {
   if (loadingFlag) {  loadingFlag = false;}	
   float t=millis()/250.0;
for (int i = 0; i < HEIGHT; i++) { 
    for (int j = 0; j < WIDTH; j++) {
        byte ind = sin8(i*8+sin8(i*2+6*t))/2+sin8(j*8+sin8(j*2+t*7)/2);
        leds [XY(j,i)] = CHSV (ind,255,255); //j,i!!! здесь хз, перепутано в оригинале было.
     }
}}
////////////////////////////////////////////// SinPlasma - ползущие пятна
*/

/*
/////////////// Recto1 //////////////////// радужный Sinus-гармошка
byte recto1 = 20;
byte step_recto1=1;

void Recto1() {

  if (loadingFlag) {
    loadingFlag=false;
  }

  for (int index = 0; index < NUM_LEDS; index++) {
    leds[index].nscale8(50);
  }

  for (int i = 0; i < WIDTH; i++)  {
    int tmp = cos8((i * recto1) + (millis() >> 1));
    tmp = map8(tmp, 1, HEIGHT - 2);
    leds[XY(i, tmp)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
    leds[XY(i, tmp - 1)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
    leds[XY(i, tmp + 1)] = CHSV(map(i, 0, WIDTH, 0, 250), 255, 255);
  }
  EVERY_N_MILLISECONDS(100) { 
      recto1+=step_recto1; 
    if (recto1>30 || recto1<10) //поправил, было 70 20
      step_recto1*=-1;
    }
}
///////////////////////////////////////////// Recto1
*/

/*
////////// Plasm Ball //////////////
//double t = 0;

void PlasmBall() {

  fadeToBlackBy(leds, NUM_LEDS, 60);
  double t = millis()/8; //16
  for (byte i = 0; i < WIDTH; i++) {
    byte thisVal = inoise8(i * 30, t, t);
    byte thisMax = map(thisVal, 0, 255, 0, WIDTH);
    for (byte j = 0; j < HEIGHT; j++) {
      byte thisVal_ = inoise8(t, j * 30, t);
      byte thisMax_ = map(thisVal_, 0, 255, 0, HEIGHT);
      byte x = (i+thisMax_);// -(WIDTH * 2 - WIDTH) / 2);
      byte y = (j+thisMax);// -(WIDTH * 2 - WIDTH) / 2);
      byte cx = x;//(i+thisMax_);
      byte cy = y;//(j+thisMax);
      leds[XY(i, j)] += ((x-y > -2) && (x-y < 2)) || ((WIDTH - 1 - x-y) > -2 && (WIDTH - 1 - x-y < 2)) || (WIDTH - cx == 0) || (WIDTH - 1 - cx == 0) || ((HEIGHT - cy == 0) || (HEIGHT - 1 - cy == 0)) ? CHSV(beat8(5), thisVal_, thisVal) : CHSV(0, 0, 0);
    }
  }
  blur2d(leds, WIDTH, HEIGHT, 16);
  //t+=1.3;
//  delay(16);
}
/////////////////////////////////// Plasm Ball
*/

/*
///////// FlyingWithoutSin ///////
#define descr 1024.0 
float
  f_x0,
  f_k = 1.996, //2.0 * cos(2.0 * PI * 10.0 / descr),  //koeff
  f_x1 = 0,                                           //start value is 0 
  f_x2 = -0.06, //-1.0 * sin(2.0 * PI * 10.0 /descr); //second value from formula
  f_x01,
  f_k1 = 1.997, //2.0 * cos(2.0 * PI * 9.0 / descr),
  f_x11 = 0,
  f_x21 = -0.05; //-1.0 * sin(2.0 * PI * 9.0 / descr);

void FlyingWithoutSin () {

// if (loadingFlag) {
//    loadingFlag = false;
//    f_k = 1.996;
//    f_x1 = 0;
//    f_x2 = -0.06;
//    f_k1 = 1.997;
//    f_x11 = 0;
//    f_x21 = -0.05;
// }

EVERY_N_MILLISECONDS(30) {
    f_x0 = f_k * f_x1 - f_x2;        //calculate next sin value from prev 2 value
    f_x2 = f_x1;
    f_x1 = f_x0;
    
    f_x01 = f_k1 * f_x11 - f_x21;   //calculate next sin value from prev 2 value
    f_x21 = f_x11;
    f_x11 = f_x01;
    
    byte x255 = f_x0 * WIDTH/2 + WIDTH/2;  //-1..1 => 0 to matrix size
    byte y255 = f_x01 * HEIGHT/2 + HEIGHT/2; //-1..1 => 0 to matrix size
      
    leds[XY(x255, y255)] += CHSV(millis() / 40, 255, 255);
    blur2d(leds, WIDTH,HEIGHT, 16);
 } 
}
////////////////////////////////// FlyingWithoutSin
*/

/////////////// Prismata ///////// same vars: Source
/*struct ModeType {
  uint8_t Brightness;// = 255U; // not used here
  uint8_t Speed;// = 30U;       // 1-255
  uint8_t Scale;// = 8;         // 1-100 is palette
};

ModeType modes[0];*/

// палитра для типа реалистичного водопада (если ползунок Масштаб выставить на 100)
//extern const TProgmemRGBPalette16 WaterfallColors_p FL_PROGMEM = {0x000000, 0x060707, 0x101110, 0x151717, 0x1C1D22, 0x242A28, 0x363B3A, 0x313634, 0x505552, 0x6B6C70, 0x98A4A1, 0xC1C2C1, 0xCACECF, 0xCDDEDD, 0xDEDFE0, 0xB2BAB9};

// добавлено изменение текущей палитры (используется во многих эффектах ниже для бегунка Масштаб)
//const TProgmemRGBPalette16 *palette_arr[] = { &PartyColors_p, &RainbowColors_p}; 
//TProgmemRGBPalette16 *curPalette;// = palette_arr[0];

//void setCurrentPalette(){
//      if (modes[0].Scale > 100U) modes[0].Scale = 100U; // чтобы не было проблем при прошивке без очистки памяти
//      curPalette = palette_arr[(uint8_t)(modes[0].Scale/100.0F*((sizeof(palette_arr)/sizeof(TProgmemRGBPalette16 *))-0.01F))];
//}