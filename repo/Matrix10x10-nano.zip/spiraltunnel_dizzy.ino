// Spiral Tunnel, idea from Dizzy5 ZX-Spectrum intro (https://www.zxby.org/unreal/?model=atm710&a=trd/Dizzy%205%20(CM)%20(1991).zip&autorun=1&press=0)
// coor@, 17.10.26; variables live in shared RAM pool (see main .ino)

#define SD_INNER_R      0.4f  // радиус круга (доля от половины меньшей стороны)
#define SD_DEPTH_SPEED  0.78f   // пролётов в секунду
#define SD_ROT_SPEED    0.78f   // оборотов в секунду
#define SD_DIR_MS       3000    // смена направления, мс
#define SD_CAM_SPEED    2.0f    // скорость движения центра (пикс/сек)
#define SD_COLOR_MODE   1       // 0 = монохром, 1 = цветной
#define SD_FADE         140     // затухание следа (255 = без следа; 40 = длинный след)
#define SD_MAX_P        64      // кол-во точек
#define SD_PERSP_B      70.8f   // кривизна перспективы

struct SpState {
  uint8_t  pdep[SD_MAX_P];       // глубина точки (старший байт 0..255 = 0..1)
  uint32_t lastMs, dirMs;
  uint16_t gD, gA;            // общий сдвиг: глубина и угол (8.8 и 0..65535 = оборот)
  float    accD, accA;        // дробные остатки сдвига
  int8_t   dirD, dirA;        // текущее направление
  float    cx, cy, cvx, cvy;  // центр и скорость его движения
};
#define sp (*(SpState*)pool)
static_assert(sizeof(SpState) <= POOL_SIZE, "pool too small for SpiralTunnelDizzy");

// 8 направлений (глубина, угол)
static const int8_t SP_DIRS[8][2] PROGMEM = { {1,0}, {1,1}, {1,-1}, {-1,0}, {-1,1}, {-1,-1}, {0,1}, {0,-1} };

void SpiralTunnelDizzy() {
  if (loadingFlag) {
    loadingFlag = false;
    randomSeed(millis());

    sp.cx  = WIDTH * 0.5f;
    sp.cy  = HEIGHT * 0.5f;
    float angle = (float)random(1000) / 1000.f * TWO_PI;
    sp.cvx = SD_CAM_SPEED * cosf(angle);
    sp.cvy = SD_CAM_SPEED * sinf(angle);

    for (uint8_t i = 0; i < SD_MAX_P; i++) sp.pdep[i] = random(256);
    sp.dirD = 1; sp.dirA = 0;                 // начало: просто вылет из круга
    sp.lastMs = sp.dirMs = millis();
  }

  uint32_t now = millis();
  float    dt  = (float)(now - sp.lastMs) * 0.001f;
  if (dt > 0.1f) dt = 0.1f;
  sp.lastMs = now;

  if (now - sp.dirMs >= SD_DIR_MS) {
    sp.dirMs = now;
    uint8_t k = random(8);
    sp.dirD = (int8_t)pgm_read_byte(&SP_DIRS[k][0]);
    sp.dirA = (int8_t)pgm_read_byte(&SP_DIRS[k][1]);
  }

  // центр движется внутри границ [W/2, H/2]+-20%
  const float xMin = WIDTH * 0.5f * 0.8f;
  const float xMax = WIDTH * 0.5f * 1.2f;
  const float yMin = HEIGHT * 0.5f * 0.8f;
  const float yMax = HEIGHT * 0.5f * 1.2f;

  sp.cx += sp.cvx * dt;
  sp.cy += sp.cvy * dt;

  if (sp.cx <= xMin) { sp.cx = xMin; sp.cvx =  fabsf(sp.cvx); }
  if (sp.cx >= xMax) { sp.cx = xMax; sp.cvx = -fabsf(sp.cvx); }
  if (sp.cy <= yMin) { sp.cy = yMin; sp.cvy =  fabsf(sp.cvy); }
  if (sp.cy >= yMax) { sp.cy = yMax; sp.cvy = -fabsf(sp.cvy); }

  // общий сдвиг всех точек
  sp.accD += sp.dirD * SD_DEPTH_SPEED * 65536.f * dt;
  sp.accA += sp.dirA * SD_ROT_SPEED   * 65536.f * dt;
  int32_t sD = (int32_t)sp.accD; sp.accD -= sD; sp.gD += (uint16_t)sD;
  int32_t sA = (int32_t)sp.accA; sp.accA -= sA; sp.gA += (uint16_t)sA;

  float maxR = fminf(fminf(sp.cx, WIDTH - sp.cx), fminf(sp.cy, HEIGHT - sp.cy));      // до ближнего края (яркость)
  float rMin = SD_INNER_R * fminf(WIDTH, HEIGHT) * 0.5f;                     // постоянный: радиусы не "дышат"

  fadeToBlackBy(leds, NUM_LEDS, SD_FADE);

  for (uint8_t i = 0; i < SD_MAX_P; i++) {
    uint16_t base = (uint16_t)(((uint32_t)i << 16) / SD_MAX_P);           // свой угол точки
    uint16_t a16  = base + sp.gA;
    uint16_t d16  = ((uint16_t)sp.pdep[i] << 8) + sp.gD;               // глубина по кругу
    float    t    = d16 * (1.0f / 65536.f);
    float    r    = rMin * SD_PERSP_B / (SD_PERSP_B - 64.0f * t);            // перспектива (таблица Dizzy)

    float sx = sp.cx + r * (cos16(a16) * (1.0f / 32768.f));
    float sy = sp.cy + r * (sin16(a16) * (1.0f / 32768.f));

    int16_t ix = (int16_t)(sx + 0.5f);
    int16_t iy = (int16_t)(sy + 0.5f);
    if (ix < 0 || ix >= WIDTH || iy < 0 || iy >= HEIGHT) continue;      // за краем: просто не видна

    float edgeFactor = (maxR > 0.5f) ? fminf(1.0f, r / maxR) : 1.0f;
    uint8_t bright = 30 + (uint8_t)(225.0f * edgeFactor);

#if SD_COLOR_MODE
    uint8_t hue = (uint8_t)(base >> 8) + (uint8_t)(d16 >> 10);
    leds[XY(ix, iy)] += CHSV(hue, 255, bright);
#else
    leds[XY(ix, iy)] += CHSV(0, 0, bright);
#endif
  }
}
