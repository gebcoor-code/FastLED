// DNA-spirale 3D, Neon with sparkles. Better in 32*32. coor@, 15.02.26. Called from custom.ino
// RAM: uses shared vectors[] (pool), hue offset is stored in the pool behind the points

#define DNA3_DOTS 36 // qty of dots (2 chains)
#define dna3Hue (pool[sizeof(float) * DNA3_DOTS * 3])
static_assert(sizeof(float) * DNA3_DOTS * 3 + 1 <= POOL_SIZE, "pool too small for DNASpiral3D");

void dna3Init() {
  const float radius = 5.0;
  const float height = 20.0;
  const int turns = 1;

  float circumference = 2.0 * PI * radius;
  float spiralLength = sqrt(pow(circumference * turns, 2) + pow(height, 2));
  int pointsPerChain = dotsCount / 2;

  for (byte chain = 0; chain < 2; chain++) {
    float phaseShift = (chain == 0) ? 0.0 : PI;

    for (int i = 0; i < pointsPerChain; i++) {
      float arcLength = (float)i / (pointsPerChain - 1) * spiralLength;
      float t = arcLength / spiralLength;
      float z = height * (t - 0.5); // от -height/2 до height/2
      float angle = (t * turns * 2.0 * PI) + phaseShift;

      int index = chain * pointsPerChain + i;
      vectors[index][0] = radius * cos(angle);
      vectors[index][1] = radius * sin(angle);
      vectors[index][2] = z;
    }
  }
}

void dna3Draw() {
  dna3Hue += 5;

  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);

    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
      int idx = XY(x, y);
      uint8_t hue = (x*5 + y*5 + dna3Hue) % 255;
      CRGB base_color = CHSV(hue, 255, 255);

      if (random8(100) < 20) leds[idx] = CRGB::White;
      else                   leds[idx] = base_color;

      if (x > 0)        leds[XY(x-1, y)] = blend(leds[XY(x-1, y)], CHSV(hue, 230, 200), 200);
      if (x < WIDTH-1)  leds[XY(x+1, y)] = blend(leds[XY(x+1, y)], CHSV(hue, 230, 200), 200);
      if (y > 0)        leds[XY(x, y-1)] = blend(leds[XY(x, y-1)], CHSV(hue, 230, 200), 200);
      if (y < HEIGHT-1) leds[XY(x, y+1)] = blend(leds[XY(x, y+1)], CHSV(hue, 230, 200), 200);
    }
  }
}

void DNASpiral3D() {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = DNA3_DOTS;
    dna3Init();
    iter = 0; scale3D = 1.0f; scaleDirection = 0.01f;
  }
  FastLED.clear();
  dna3Draw();
  ScaleAndRotate(1.8, 1.1, 1, 1, 1, -5, 7);
}
