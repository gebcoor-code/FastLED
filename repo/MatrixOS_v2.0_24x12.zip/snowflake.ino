// Snowflakes, coor@, 03.01.26. Called from custom.ino: Snowflake3D(0) - flat (z0), Snowflake3D(1) - wrapped onto the sphere surface
// RAM: uses shared vectors[] (pool) and shared rotate/translate/ScaleAndRotate

// 3D snowflake with 6 branches and fractal-like structure
void snInitFlat() {
  const float radius = 5.0;
  const int branches = 6;
  const int dotsPerBranch = dotsCount / branches;
  byte dotIndex = 0;

  for (byte branch = 0; branch < branches; branch++) {
    float branchAngle = (2.0 * PI * branch) / branches;

    for (byte i = 0; i < dotsPerBranch && dotIndex < dotsCount; i++) {
      float t = i / (float)(dotsPerBranch - 1);
      float r = radius * t * 0.9;
      float sideOffset = 0;
      float yOffset = 0;

      if (i > 2 && i < dotsPerBranch - 2) {
        sideOffset = (i % 2 == 0 ? 0.3 : -0.3) * (1.0 - t);
        yOffset = sin(t * PI * 3.0) * 0.8 * (1.0 - t);
      }

      float x = r * cos(branchAngle);
      float z = r * sin(branchAngle);

      float perpAngle = branchAngle + PI / 2.0;
      x += sideOffset * cos(perpAngle);
      z += sideOffset * sin(perpAngle);

      vectors[dotIndex][0] = x;
      vectors[dotIndex][1] = yOffset;
      vectors[dotIndex][2] = z;
      dotIndex++;
    }
  }
}

// snowflake wrapped onto sphere surface
void snInitSphere() {
  const float radius = 5.0;
  const int branches = 6;
  const int dotsPerBranch = dotsCount / branches;
  byte dotIndex = 0;

  for (byte branch = 0; branch < branches; branch++) {
    float branchAngle = (2.0 * PI * branch) / branches;

    for (byte i = 0; i < dotsPerBranch && dotIndex < dotsCount; i++) {
      float t = i / (float)(dotsPerBranch - 1);
      float r = radius * t * 0.9;
      float sideOffset = 0;

      if (i > 2 && i < dotsPerBranch - 2) {
        sideOffset = (i % 2 == 0 ? 0.3 : -0.3) * (1.0 - t);
      }

      float perpAngle = branchAngle + PI / 2.0;
      float x = r * cos(branchAngle) + sideOffset * cos(perpAngle);
      float z = r * sin(branchAngle) + sideOffset * sin(perpAngle);

      float distXZ = sqrt(x*x + z*z);
      float y = 0;
      if (distXZ < radius) y = sqrt(radius*radius - distXZ*distXZ);

      vectors[dotIndex][0] = x;
      vectors[dotIndex][1] = y;
      vectors[dotIndex][2] = z;
      dotIndex++;
    }
  }
}

// white to red gradient by z (4 levels)
void snDrawGradient() {
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);

    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
      float z = vectors[i][2];
      int idx = XY(x, y);
      CRGB new_color =
        (z > 0)     ? CRGB(255, 255, 255) :    //Close: White
        (z > -1)    ? CRGB(128, 0, 0) :        //Red1
        (z > -3.0)  ? CRGB(96, 0, 0) :         //Red2
                      CRGB(80, 0, 0);          //Red3
      if (new_color > leds[idx]) leds[idx] = new_color;
    }
  }
}

void snDrawWhite() {
  for (byte i = 0; i < dotsCount; i++) {
    int8_t x = translateX(vectors[i][0], vectors[i][2]);
    int8_t y = translateY(vectors[i][1], vectors[i][2]);
    if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) leds[XY(x, y)] = CRGB(255, 255, 255);
  }
}

void Snowflake3D(bool onSphere) {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = dots;
    if (onSphere) snInitSphere(); else snInitFlat();
    iter = 0; scale3D = 1.0f; scaleDirection = 0.01f;
  }
  FastLED.clear();
  if (onSphere) snDrawGradient(); else snDrawWhite();
  ScaleAndRotate(2.7, 1.1, 1, 1, 1, -3, 7);
}
