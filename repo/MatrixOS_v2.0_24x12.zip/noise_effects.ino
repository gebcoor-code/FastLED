//Noise Effects

bool colorLoop = 1; //changes hue

// "масштаб". Чем меньше, тем крупнее!
#define MADNESS_SCALE 100
#define CLOUD_SCALE 30
#define LAVA_SCALE 50
#define PLASMA_SCALE 30
#define RAINBOW_SCALE 30
#define RAINBOW_S_SCALE 20
#define ZEBRA_SCALE 30
#define FOREST_SCALE 120
#define OCEAN_SCALE 90

#define Sat (255)
#define Hue (150)

// The 16 bit version of our coordinates
static uint16_t x;
static uint16_t y;
static uint16_t z;

// This is the array that we keep our computed noise values in
#define MAX_DIMENSION (max(WIDTH, HEIGHT))
#if (WIDTH > HEIGHT)
#define noise (*(uint8_t(*)[WIDTH][WIDTH])pool) // shared RAM (pool)
#else
#define noise (*(uint8_t(*)[HEIGHT][HEIGHT])pool)
#endif
static_assert(sizeof(noise) <= POOL_SIZE, "pool too small for noise");

void madnessNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    scale = MADNESS_SCALE;
    speed=20;
  }
  fillnoise8();
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      //CRGB thisColor = CHSV(noise[j][i], 255, noise[i][j]);
    //  CRGB thisColor = CHSV(hue + (noise[j][i]>>2),255,noise[i][j]);
      leds[XY(i, j)]=CHSV(noise[j][i], 255, noise[i][j]);   //leds[getPixelNumber(i, j)] = CHSV(noise[j][i], 255, noise[i][j]);

      // You can also explore other ways to constrain the hue used, like below
      // leds[XY(i,j)] = CHSV(hue + (noise[j][i]>>2),255,noise[i][j]);
    }
  }
  //hue += 1;
}


void rainbowNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=1; //RainbowColors_p;
    scale = RAINBOW_SCALE; colorLoop = 1;
    speed=20;
  }
  fillNoiseLED();
}
void rainbowStripeNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=2; //RainbowStripeColors_p;
    scale = RAINBOW_S_SCALE; colorLoop = 1;
    speed=20;
  }
  fillNoiseLED();
}
void zebraNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=21; //
//    // 'black out' all 16 palette entries...
//    fill_solid( currentPalette, 16, CRGB::Black); //8
    // and set every fourth one to white.
//    currentPalette[0] = CRGB::Red;
//    currentPalette[4] = CRGB::Red;
//    currentPalette[8] = CRGB::Red;
//    currentPalette[12] = CRGB::Red;
    scale = ZEBRA_SCALE; colorLoop = 0;
    speed=20;
  }
  fillNoiseLED();
}

/*void forestNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    currentPalette = ForestColors_p;
    scale = FOREST_SCALE; colorLoop = 0;
    speed=20;
  }
  fillNoiseLED(0);
}
*/

/*void oceanNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    currentPalette = OceanColors_p;
    scale = OCEAN_SCALE; colorLoop = 0;
    speed=20;
  }
  fillNoiseLED(0);
}*/

void plasmaNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=0; //PartyColors_p; //0
    //currentPalette = PartyColors_p; //0
    scale = PLASMA_SCALE; colorLoop = 1;
    speed=20;
  }
  fillNoiseLED();
}
void cloudNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=3; //CloudColors_p;
//    currentPalette = CloudColors_p;
    scale = CLOUD_SCALE; colorLoop = 0;
    speed=20;
  }
  fillNoiseLED();
}
void lavaNoise() {
  if (loadingFlag) {
    loadingFlag = false;
    palette=6; //LavaColors_p;
//    currentPalette = LavaColors_p;
    scale = LAVA_SCALE; colorLoop = 0;
    speed=20;
  }
  fillNoiseLED();
}


void fillNoiseLED () { 
  uint8_t dataSmoothing = 0;
  if ( speed < 50) {
    dataSmoothing = 200 - (speed * 4);
  }
  for (int i = 0; i < MAX_DIMENSION; i++) {
    int ioffset = scale * i;
    for (int j = 0; j < MAX_DIMENSION; j++) {
      int joffset = scale * j;

      uint8_t data = inoise8(x + ioffset, y + joffset, z);

      data = qsub8(data, 16);
      data = qadd8(data, scale8(data, 39));

      if ( dataSmoothing ) {
        uint8_t olddata = noise[i][j];
        uint8_t newdata = scale8( olddata, dataSmoothing) + scale8( data, 256 - dataSmoothing);
        data = newdata;
      }

      noise[i][j] = data;
    }
  }
  z += speed;

  // apply slow drift to X and Y, just for visual variation.
  x += speed / 8;
  y -= speed / 16;

  for (int i = 0; i < WIDTH; i++) {
    for (int j = 0; j < HEIGHT; j++) {
      uint8_t index = noise[j][i];
      uint8_t bri =   noise[i][j];
      // if this palette is a 'loop', add a slowly-changing base value
      if (colorLoop) {
        index += hue;
      }
      // brighten up, as the color palette itself often contains the
      // light/dark dynamic range desired
      if ( bri > 127 ) bri = 255;
      else bri = dim8_raw( bri * 2);
      leds[XY(i, j)]=ColorFromPalette( *pal_arr[palette], index, bri);
    }
  }
  hue += 1;
}

void fillnoise8() {
  for (byte i = 0; i < MAX_DIMENSION; i++) {
    int ioffset = scale * i;
    for (byte j = 0; j < MAX_DIMENSION; j++) {
      int joffset = scale * j;
      noise[i][j] = inoise8(x + ioffset, y + joffset, z);
    }
  }
  z += speed;
}
