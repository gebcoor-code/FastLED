// Dodecahedron, coor@, 20.04.26. Called from custom.ino
// RAM: uses shared vectors[] (pool) and shared rotateX/Y/Z, translateX/Y; vertices and faces are in flash

#define DODE_NZ_MAX 100.0f
#define DODE_MIN_SCALE 0.8f
#define DODE_MAX_SCALE 1.7f

const float dodeVerts[20][3] PROGMEM = {
  {-4.62f, -4.62f, -4.62f},  //  0
  {-4.62f, -4.62f,  4.62f},  //  1
  {-4.62f,  4.62f, -4.62f},  //  2
  {-4.62f,  4.62f,  4.62f},  //  3
  { 4.62f, -4.62f, -4.62f},  //  4
  { 4.62f, -4.62f,  4.62f},  //  5
  { 4.62f,  4.62f, -4.62f},  //  6
  { 4.62f,  4.62f,  4.62f},  //  7
  { 0.00f, -7.47f, -2.85f},  //  8
  {-2.85f,  0.00f, -7.47f},  //  9
  {-7.47f, -2.85f,  0.00f},  // 10
  { 0.00f, -7.47f,  2.85f},  // 11
  {-2.85f,  0.00f,  7.47f},  // 12
  {-7.47f,  2.85f,  0.00f},  // 13
  { 0.00f,  7.47f, -2.85f},  // 14
  { 2.85f,  0.00f, -7.47f},  // 15
  { 7.47f, -2.85f,  0.00f},  // 16
  { 0.00f,  7.47f,  2.85f},  // 17
  { 2.85f,  0.00f,  7.47f},  // 18
  { 7.47f,  2.85f,  0.00f},  // 19
};

const int8_t dodeFaces[12][5] PROGMEM = {
  { 0,  9, 15,  4,  8},  //  0
  { 0,  8, 11,  1, 10},  //  1
  { 0, 10, 13,  2,  9},  //  2
  { 1, 12,  3, 13, 10},  //  3
  { 1, 11,  5, 18, 12},  //  4
  { 2, 14,  6, 15,  9},  //  5
  { 2, 13,  3, 17, 14},  //  6
  { 3, 12, 18,  7, 17},  //  7
  { 4, 16,  5, 11,  8},  //  8
  { 4, 15,  6, 19, 16},  //  9
  { 5, 16, 19,  7, 18},  // 10
  { 6, 14, 17,  7, 19},  // 11
};

void dodeDrawFace(uint8_t fi) {
  uint8_t idx[5];
  for (byte k = 0; k < 5; k++) idx[k] = pgm_read_byte(&dodeFaces[fi][k]);

  float nz = 0;
  for (byte k = 0; k < 5; k++) {
    byte a = idx[k], b = idx[(k + 1) % 5];
    nz += (vectors[a][0] - vectors[b][0]) * (vectors[a][1] + vectors[b][1]);
  }
  if (nz >= 0) return; // обратная грань не видна
  float br = (-nz / DODE_NZ_MAX) * 255.0f;
  uint8_t bright = (uint8_t)(br > 255.0f ? 255 : br);

  int8_t px[5], py[5];
  for (byte k = 0; k < 5; k++) {
    px[k] = translateX(vectors[idx[k]][0], vectors[idx[k]][2]);
    py[k] = translateY(vectors[idx[k]][1], vectors[idx[k]][2]);
  }
  CRGB col = CRGB(bright, bright, bright);
  for (byte k = 0; k < 5; k++) Line_color(px[k], py[k], px[(k + 1) % 5], py[(k + 1) % 5], col);
}

void Dodecahedron() {
  if (loadingFlag) {
    loadingFlag = false;
    dotsCount = 20;
    memcpy_P(vectors, dodeVerts, sizeof(dodeVerts));
    iter = 0; scale3D = 1.0f; scaleDirection = 0.01f;
  }
  FastLED.clear();
  for (byte f = 0; f < 12; f++) dodeDrawFace(f);

  // свой ScaleAndRotate: углы -3..3 без ограничения |delta|>=2, как в исходнике
  if (iter == 0) {
    deltaX = random(7) - 3;
    deltaY = random(7) - 3;
    deltaZ = random(7) - 3;
    iter   = random(250) + 5;
  }
  scale3D += scaleDirection;
  if      (scale3D >= DODE_MAX_SCALE) { scale3D = DODE_MAX_SCALE; scaleDirection = -stepDirection; }
  else if (scale3D <= DODE_MIN_SCALE) { scale3D = DODE_MIN_SCALE; scaleDirection =  stepDirection; }
  rotateX(deltaX);
  rotateY(deltaY);
  rotateZ(deltaZ);
  iter--;
}
