#define MODES_AMOUNT 75   // количество кастомных режимов (которые переключаются сами или кнопкой)

void customModes() {
  switch (thisMode) {
    case 0: Scroll3D(F("С НАСТУПАЮЩИМ 2027 ГОДОМ!")); //3D бегущая строка по сфере (scroll3d.ino): текст во flash, по окончании ставит fullTextFlag
      delay(30);
      break;
    case 1: SpiralTunnelDizzy(); //spiral tunnel из заставки Dizzy 5 (spiraltunnel_dizzy.ino)
      break;
    case 2: ChristmasTree3D(); //3D елка со звездой и огоньками
      break;
//    case 3: Starship(); //
//      delay(16); //~60fps
    case 3: Ex9NiceOne();  //----------new
      break;
    case 4: zebraNoise();
      delay(30);
      break;
      case 5: Sphere3D(0,1); // сфера из точек. два типа (1) - 0 - золотое сечение, 1 - спираль Фибоначчи, (2) - 0 - красный градиент, 1 - неон с искрами
      break;
    case 6: DNAspiralHoriz();
      break;      
    case 7: draw3Dtriangle();
      break;		  	  	 
    case 8: ColorFrizzlesRoutine(); //один из первых. немного модернизировал рандомом
      delay(30);
      break;		
    case 9: Fire234(); //самый оптимальный огонь
      break;            	  	 	  
    case 10: SineWavesRoutine(0); //типа rainbow, теперь два в одном. может убрать один нафиг
      break;		  	  	 	 
    case 11: RainbowTunnel();  //аналог hypnospiral, но радужный
      break;		  	  		  
    case 12: CrazyBee(); //немного растянул fader, и теперь всегда белый
      break;		
    case 13: Sphere3D(1,1); // сфера из точек. два типа (1) - 0 - золотое сечение, 1 - спираль Фибоначчи, (2) - 0 - красный градиент, 1 - неон с искрами
      break;		  	  		  		  
    case 14: cloudNoise(); 
      delay(30);
      break;		  	  		  		  
    case 15: SineEffectsRoutine(6); //matrix style colored
      delay(10);
      break;		  	  		  		  
    case 16: WanderingSouls();
      delay(30); //можно помедленней в принципе
      break;		  	  		  		  
    case 17: HappyYear3D(); // Happy Year ! по поверхности шара
      break;
    case 18: matrixRoutine(); //классическая matrix
      delay(100);
      break;		  	  		  		  
    case 19: Icosahedron(); //икосаэдр
      break;		  	  		  		  
    case 20: PlasmaWaves(); //типа parus
      break;	  
    case 21: Cube3DHid(); //новый 3d куб, со скрытыми гранями
      break;		  	  		  		  
    case 22: lavaNoise();
      delay(16);
      break;	        
    case 23: FlyBycicleRoutine(); //круг белый
      break;	  
    case 24: Happy3D(); //Happy 2027 in 3D
      break;	  
    case 25: Drift(); //спиральки по кругу
      delay(16);
      break;	  
    case 26: SpiroRoutine(); //сходящиеся и расходящиеся точки в центр по кругу
      break;		  	  		  		  
    case 27: Sphere3D(0,0); // сфера из точек. два типа (1) - 0 - золотое сечение, 1 - спираль Фибоначчи, (2) - 0 - красный градиент, 1 - неон с искрами
      break;		  	  		  		  
    case 28: SimpleSinRoutine(); //sinus. просто синус
      delay(10);
      break;
    case 29: Octahedron(); //две пирамидки, склеенные основаниями
      break;
    case 30: Octopus();
      delay(16);
      break;
    case 31: SineEffectsRoutine(2); //вращающиеся полосы, остались только два эффекта - 2 и 6
      delay(5);
      break;
    case 32: VUSpectrum();
      break;
    case 33: Flower250(); //расходящиеся точки, радиус увеличен для 24*12
      break;
    case 34: Prismata(); //colored sin with changing step
      break;
    case 35: Ex7Sparkles(); //мерцание редкое
      delay(30);
      break;               
    case 36: Gyroscope();  //линии из центра по кругу
      break;                     
    case 37: Stars();
      delay(30);
      break;   
    case 38: Pride(); //nice slow
      break;
    case 39: Lotus();
      delay(5);
      break;
    case 40: Source(); //из центра точки летят.
      break;
    case 41: Parus(); //
      break;
    case 42: Hypnosis(); //rainbow spirale, octopus based
      delay(10);
      break;
    case 43: RadialWaveRoutine(); //типа octopus
      delay(16);
      break;
    case 44: SpinningThing(); //типа octopus и radialwave, но меняется
      break;
    case 45: DriftRose();
      delay(10); //было быстровато с нулевой, посмотрим как с задержкой
      break;
    case 46: SinDots(); //типа color frizzles, но по кругу
      break;
    case 47: Contrast(); //типа parus
      break;
    case 48: Hipnotic(); //типа parus
      break;
    case 49: SinShort(); //ускоренное неплохо.
      break;
    case 50: Fountain(); //кандидат на удаление, если памяти не будет хватать. также можно кол-во particles уменьшить. пока хватает, firebengal больше жрал
      delay(10);
      break;
    case 51: sparklesRoutine(); //увеличил плотность и сделал более долгое угасание
      delay(50);      
      break;
    case 52: WithoutSin(); //синус быстрый. хз
      break;          
    case 53: SineWavesRoutine(1); //типа rainbow, теперь два в одном
      break;		  	  	 	       
    case 54: Twister(); //цветная косичка
      break;
    case 55: radarRoutine(); //плавный радар по кругу
      delay(16);
      break;
    case 56: StarShips(); //похоже на starship, но попроще, без переключения палитр
      break;
    case 57: NexusRoutine(); //попендикулярные шлындрики. синий фон отключил
      break;
    case 58: PlasmBall(); //медуза типа, в 24*12 только верхняя часть
      break;
    case 59: Flame(); //движущися. почти fountain. там инит свой есть, но пока берется из фонтана
      delay(5);
      break;
    case 60: GifAnim2424(earth2424, earth2425, 1);//0/1 - off/on moving up-down. в режиме 1 в крайних точках задержка GIF_HOLD шагов
      delay(50);
      break;
    case 61: FireRing();
      delay(30);
      break;
    case 62: China2();  //треугольники из огня влево-вправо      
      break;
    case 63: Recto1(); //радужный Sinus-гармошка
      break;
    case 64: Something(); //этакий глаз выворачивающийся      
      break;
    case 65: Circle3D(); // два круга попендикулярных      
      break;
    case 66: Cube3Ddots(); // 3d куб из 3*3*3 точек
      break;
    case 67: SphericalText3D(); // 2027 с изгибом по сфере      
      break;
    case 68: Sphere3D(1,0); // сфера из точек. два типа (1) - 0 - золотое сечение, 1 - спираль Фибоначчи, (2) - 0 - красный градиент, 1 - неон с искрами
      break;
    case 69: Dodecahedron(); //додекаэдр (dodecahedron.ino)
      break;
    case 70: SpiralTunnel(); //spiral tunnel v4 (spiraltunnel.ino)
      break;
    case 71: Snowflake3D(0); //снежинка плоская (snowflake.ino)
      break;
    case 72: Snowflake3D(1); //снежинка на сфере
      break;
    case 73: DNASpiral3D(); //3D ДНК-спираль, neon с искрами (dnaspiral3d.ino)
      break;
    case 74: UglyCaustic(); //каустика (caustic.ino)
      break;
  }
}

void customRoutine() {

    customModes();
    FastLED.show();

    if (!digitalRead(dpin) && !buttonPressed && !buttonReleased100) { //если кнопка нажата, запускаем таймер. 
      buttonPressed = true;
      buttonReleased1000 = false;
      buttonPressedTimer = millis();
    }
    
    if ((millis() - buttonPressedTimer > 100) && buttonPressed && !buttonReleased100) {    //отсчитываем 100мс с момента нажатия и проверяем кнопку.
      if(digitalRead(dpin)) { //если через 100мс кнопка отпущена, то устанавливаем триггер переключения режима
        buttonPressed = false; 
        buttonReleased100 = true;
      }
    }

    if ((millis() - buttonPressedTimer > buttonPressedTime) && buttonPressed && !buttonReleased100 && !buttonReleased1000) {    //если через 1000мс кнопка все еще нажата - фиксируем текущий режим.
      if(!digitalRead(dpin)) { //если через 1000мс кнопка все еще нажата,
        buttonReleased1000 = true; //то фиксируем текущий режим
        FastLED.clear(); //моргаем экраном, как признак что режим зафиксировался
      }
      else { //если кнопка была отпущена до 1000мс - режим не фиксируется.
        buttonPressed = false;
      }
    }
 
  if ((millis() - autoplayTimer > autoplayTime) || buttonReleased100 || fullTextFlag) {    //переключение по таймеру, по отпущенной кнопке 100мс или по признаку окончания бегущей строки

    buttonReleased100 = false;
    autoplayTimer = millis();
    if(!buttonReleased1000 || fullTextFlag) { //изменение по таймеру или по 100мс кнопке, только если не зажат текущий режим. Также если закончилась бегущая строка
//      thisMode++;
//      if (thisMode >= MODES_AMOUNT) thisMode = 0;
      //thisMode = (thisMode + 1) % MODES_AMOUNT; //так больше памяти отожрет
      thisMode = (++thisMode >= MODES_AMOUNT) ? 0 : thisMode; //а вот так вроде самое то
      loadingFlag = true;
      fullTextFlag = false;
      memset(pool, 0, POOL_SIZE); //shared RAM starts from zeros for every effect
      FastLED.clear();
    }
  }
}
