

#include "earth2424.h"
#include "earth2425.h"

// Shared RAM (pool): big arrays of effects live here one over another.
// Effects never run together; pool is zeroed on every mode change (customRoutine), so each effect starts from zeros, as after power on.
// Size = biggest user: tracking objects of Source() (4 float + 3 byte arrays of 48) = 912 bytes. static_assert after each user checks it.
// Just for Real CPU=1; If it =0 (just for simulation for high sizes like 48*48, especially for 3D) then set POOL_SIZE for higher sizes up to 8192
#define POOL_SIZE 912
uint8_t pool[POOL_SIZE];

///global vars
byte hue; //используется ниже много где
byte palette = 0; //номер используемой палитры из pal_arr
byte speed=20; // noise, prismata, source
byte scale=30; // noise, prismata, source, sinewaves
byte brightness; //prismata, source
uint32_t t; //rmap, drift

#define LineColor 1 //0 - желтый, 1 - белый
#define FixScaleX 1 // North needs to fix Scale X

// MatrixOS v.2.0 16 Nov 2026 by @ae485
// based on GyverMatrix OS 1.12

// ************************ МАТРИЦА *************************

#define LED_BRIGHTNESS 100        // стандартная маскимальная яркость (0-255) 150 default
#define CURRENT_LIMIT 1000    // лимит по току в миллиамперах, автоматически управляет яркостью (пожалей свой блок питания!) 0 - выключить лимит

#define WIDTH 24              // ширина матрицы
#define HEIGHT 12             // высота матрицы
#define SEGMENTS 1            // диодов в одном "пикселе" (для создания матрицы из кусков ленты)

#define COLOR_ORDER GRB       // порядок цветов на ленте. Если цвет отображается некорректно - меняйте. Начать можно с RGB

////////////////////////// MY OWN INTERNAL LEDS (one project for all)  //////////////////////////
//NORTH 24x12 CONNECTION_ANGLE 2, STRIP_DIRECTION 3, GRB, brightness=100, curr_lim=1000
//SOUTH 24x12 CONNECTION_ANGLE 0, STRIP_DIRECTION 1, BGR, brightness=255, curr_lim=1500
//BOX 16*16 CONNECTION_ANGLE 0, STRIP_DIRECTION 0, GRB, brightness=100, curr_lim=1000
//HOME 20*10 CONNECTION_ANGLE 0, STRIP_DIRECTION 1, GRB, brightness=250, curr_lim=1500
//////////////////////////////////////////////////////////////////////////////

#define MATRIX_TYPE 0         // тип матрицы: 0 - зигзаг, 1 - параллельная
#define CONNECTION_ANGLE 2    // угол подключения: 0 - левый нижний, 1 - левый верхний, 2 - правый верхний, 3 - правый нижний //для 16*16 0 only, для 12*12 нужно 2, чтобы снаружи бегущая была видна
#define STRIP_DIRECTION 3     // направление ленты из угла: 0 - вправо, 1 - вверх, 2 - влево, 3 - вниз

#define MCU_TYPE 0            // микроконтроллер: 
//                            0 - AVR (Arduino NANO/MEGA/UNO)
//                            1 - ESP8266 (NodeMCU, Wemos D1)
//                            2 - STM32 (Blue Pill)


// ****************** ПИНЫ ПОДКЛЮЧЕНИЯ *******************
// Arduino (Nano, Mega)
#if (MCU_TYPE == 0)
#define LED_PIN 6           // пин ленты

// пины подписаны согласно pinout платы, а не надписям на пинах!
// esp8266 - плату выбирал Wemos D1 R1
#elif (MCU_TYPE == 1)
#define LED_PIN 2           // пин ленты

// STM32 (BluePill) - плату выбирал STM32F103C
#elif (MCU_TYPE == 2)
#define LED_PIN PB12         // пин ленты
#endif

#define NUM_LEDS WIDTH * HEIGHT * SEGMENTS

#if (MCU_TYPE == 1)
#define FASTLED_INTERRUPT_RETRY_COUNT 0
#define FASTLED_ALLOW_INTERRUPTS 0
#include <ESP8266WiFi.h>
#endif

#include "FastLED.h"
CRGB leds[NUM_LEDS+1];

static const byte maxDim = max(WIDTH, HEIGHT);
boolean loadingFlag = true;
int8_t thisMode = 0; /////////////////////////////////////////////////////////////////////////// start mode
boolean fullTextFlag = false; // признак окончания бегущей строки: ставит Scroll3D(), сбрасывает customRoutine()

//// Buttons ///////////
const byte dpin = 3;
bool buttonPressed=false; //признак нажатия кнопки
bool buttonReleased100=false; //кнопка нажата 100мс, переключаем режим
bool buttonReleased1000=false; //кнопка нажата 1000мс, режим фиксируется

#define AUTOPLAY_PERIOD 20  // время между авто сменой режимов (секунды)
const uint32_t autoplayTime = ((long)AUTOPLAY_PERIOD * 1000);
const uint32_t buttonPressedTime = 1000;
uint32_t autoplayTimer;
uint32_t buttonPressedTimer;

void setup() {
  // настройки ленты
  FastLED.addLeds<WS2812B, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS+1).setCorrection( TypicalLEDStrip );
  FastLED.setBrightness(LED_BRIGHTNESS);
  if (CURRENT_LIMIT > 0) FastLED.setMaxPowerInVoltsAndMilliamps(5, CURRENT_LIMIT);
  FastLED.clear();
  FastLED.show();
  randomSeed(analogRead(0) + analogRead(1));    // пинаем генератор случайных чисел
  pinMode(dpin, INPUT_PULLUP); //read pin
}

void loop() {
  customRoutine();
}
