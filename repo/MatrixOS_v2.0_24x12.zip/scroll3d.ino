// 3D scrolling text on sphere: new3dscroll.c by coor@, 17.01.26 (based on Gyver's getFont and font array), called from custom.ino
//upd: fixed bitmap font vectorization artifacts
//upd: fixed for dW>9
//upd: fixed some hex-symbols like '2,3,4,M,V'. They have some difficulties to vectorize pixel combinations,forming angles. It was easier to fix bitmaps to avoid these angles.
//upd: JavaScript fork: https://kodomo.fbb.msu.ru/~dudka2007/term2/files/scr.html
//upd: Й fix
//upd: text in flash (PROGMEM); vectors[] and own variables live in shared RAM pool (see pool in main .ino), rotateZ is common with other 3D effects
#include "font.h"

#define LET_WIDTH 5       // ширина буквы шрифта
#define dW 9              // ширина окна, pt
#define dH 8              // высота окна, pt (dW * dH = dots)
#define S3_ROT 15         // rotAngle
#define S3_STEP 0.03      // step of scale

// own variables: pool, behind vectors[dots][3]
struct S3State {
  uint16_t bitSub[dH];    // битовая подложка. можно использовать uint32_t, на больших экранах
  uint8_t chari, columni; // текущий символ, столбец
  bool needSpace;         // так реализовал просветы между символами
  uint8_t tail;           // сколько пустых столбцов прошло после конца текста
  int8_t deltaZ, iter;
  float scale, scaleDir;
};
#define s3 (*(S3State*)(pool + sizeof(float) * dots * 3))
static_assert(sizeof(float) * dots * 3 + sizeof(S3State) <= POOL_SIZE, "pool too small for Scroll3D");

int8_t s3TranslateX(float x, float z) {
  float scaledX = x * s3.scale;
  float scaledZ = z * s3.scale;
  return (int8_t)((scaledX + WIDTH/2) + (scaledZ * (scaledX / perspective)));
}

int8_t s3TranslateY(float y, float z) {
  float scaledY = y * s3.scale;
  float scaledZ = z * s3.scale;
  return (int8_t)((scaledY + HEIGHT/2) + (scaledZ * (scaledY / perspective)));
}

void s3ScaleAndRotate(float maxSc, float minSc) {
  if (s3.iter == 0) {
    s3.deltaZ *= -1;
    s3.iter = S3_ROT * 2; //+-rotAngle
  }
  s3.scale += s3.scaleDir;
  if (s3.scale >= maxSc) {
    s3.scale = maxSc;
    s3.scaleDir = -S3_STEP;
  } else if (s3.scale <= minSc) {
    s3.scale = minSc;
    s3.scaleDir = S3_STEP;
  }
  rotateZ(s3.deltaZ);
  s3.iter--;
}

uint8_t s3Font(uint8_t font, uint8_t row) { //@респект to Gyver. Реально взрыв мозгов тут.
  if ((font>=0x41 && font<=0x5A) || (font>=0xC0 && font<=0xDF)) font &= 0xDF; //set just letters as a capital.
  font = font - '0' + 0x10;   // перевод код символа из таблицы ASCII в номер согласно нумерации массива
  if (font <= 0x5A) return pgm_read_byte(&(fontHEX[font][row]));     // для английских букв и символов
  else if (font >= 0x70 && font <= 0x9F) {
    return pgm_read_byte(&(fontHEX[font - 0x2F][row]));
  } else if (font >= 0x60 && font <= 0x6F) {
    return pgm_read_byte(&(fontHEX[font - 0x0F][row]));
  }
  return 0;
}

bool s3GetPixel(uint8_t x, uint8_t y) {
  if (x >= dW || y >= dH) return false;
  return (s3.bitSub[y] >> x) & 0x01;
}

void s3ShiftLeft() {
  for (uint8_t y = 0; y < dH; y++) s3.bitSub[y] >>= 1;
}

void s3UpdateText(const char* text, uint8_t len) { // text во flash (PROGMEM)
  s3ShiftLeft();

  if (s3.needSpace) {
    for (uint8_t y = 0; y < dH; y++) s3.bitSub[y] &= ~(1 << (dW - 1));
    s3.needSpace = false;
    return;
  }

  while (s3.chari < len && pgm_read_byte(text + s3.chari) > 0xBF) s3.chari++; // первый байт русской буквы (UTF-8) пропускаем

  if (s3.chari >= len) { // текст закончился: даем ему уехать из окна целиком, потом ставим признак окончания
    if (++s3.tail > dW) {
      s3.tail = 0;
      s3.chari = 0;
      s3.columni = 0;
      fullTextFlag = true; // customRoutine переключит на следующий режим
    }
    return;
  }

  uint8_t charCode = pgm_read_byte(text + s3.chari);
  uint8_t columnData = s3Font(charCode, s3.columni);

  for (uint8_t y = 0; y < dH; y++) {
    s3.bitSub[y] &= ~(1 << (dW - 1));
    bool pixel = (columnData >> (dH - 1 - y)) & 0x01;
    if (pixel) s3.bitSub[y] |= (1 << (dW - 1));
  }

  if (++s3.columni >= LET_WIDTH) {
    s3.columni = 0;
    s3.chari++;
    s3.needSpace = true;
  }
}

void s3InitSphere(float radius) {
  uint8_t i = 0;

  for (uint8_t row = 0; row < dH; row++) {
    for (uint8_t col = 0; col < dW; col++) {
      //инвертируем здесь
      float u = (float)(dW - 1 - col) / (dW - 1);  // 1..0
      float v = (float)(dH - 1 - row) / (dH - 1); // 1..0

      //задаем умеренную кривизну, для лучшей читаемости
      float phi = u * PI * 0.9;           // 90% половины сферы (0.6 - меньше искажений)
      float theta = v * PI * 0.4;         // 40% от полюса к полюсу

      // Центрируем
      phi += PI * 0.1;  //0.2
      theta += PI * 0.3;

      vectors[i][0] = radius * sin(theta) * cos(phi);  // x
      vectors[i][1] = radius * cos(theta);             // y
      vectors[i][2] = radius * sin(theta) * sin(phi);  // z

      // Минимальное масштабирование
      vectors[i][0] *= 1.25;  // X (оптимально для x=24)
      vectors[i][1] *= 0.8;  // Y (оптимально для y=12)

      i++;
    }
  }
}

void s3Line(int8_t x1, int8_t y1, int8_t x2, int8_t y2) {
  int8_t dx = abs(x2 - x1);
  int8_t dy = abs(y2 - y1);
  int8_t sx = (x1 < x2) ? 1 : -1;
  int8_t sy = (y1 < y2) ? 1 : -1;
  int8_t err = dx - dy;

  while (true) {
    if (x1 >= 0 && x1 < WIDTH && y1 >= 0 && y1 < HEIGHT) leds[XY(x1, y1)] = CRGB::White;

    if (x1 == x2 && y1 == y2) break;

    int8_t e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x1 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y1 += sy;
    }
  }
}

void s3Connect(uint8_t i1, uint8_t i2) {
  s3Line(s3TranslateX(vectors[i1][0], vectors[i1][2]), s3TranslateY(vectors[i1][1], vectors[i1][2]),
         s3TranslateX(vectors[i2][0], vectors[i2][2]), s3TranslateY(vectors[i2][1], vectors[i2][2]));
}

void s3DrawText() {
  // Соединяем точки, которые были соседями в исходной текстуре. 0 - право-низ, направление инкремента - вверх и влево
  for (byte i = 0; i < dotsCount; i++) {
    uint8_t dRow = i / dW;
    uint8_t dCol = i % dW;

    if (!s3GetPixel(dCol, dRow)) continue;

    // слева
    if ((dCol < dW - 1) && s3GetPixel(dCol + 1, dRow))
      s3Connect(i, i + 1);

    // сверху
    if ((dRow < dH - 1) && s3GetPixel(dCol, dRow + 1))
      s3Connect(i, i + dW);

    // слева-сверху, если (x+1,y+1), но !(x,y+1) и !(x+1,y)
    if (dCol < dW - 1 && dRow < dH - 1 && s3GetPixel(dCol + 1, dRow + 1) && !s3GetPixel(dCol, dRow + 1) && !s3GetPixel(dCol + 1, dRow))
      s3Connect(i, i + dW + 1);

    // справа-сверху, если (x-1,y+1), но !(x-1,y) и !(x,y+1)
    if (dCol > 0 && dRow < dH - 1 && s3GetPixel(dCol - 1, dRow + 1) && !s3GetPixel(dCol - 1, dRow) && !s3GetPixel(dCol, dRow + 1))
      s3Connect(i, i + dW - 1);
  }
}

// text - строка во flash: Scroll3D(F("ТЕКСТ")). По окончании вывода ставит fullTextFlag (переключение на следующий режим)
void Scroll3D(const __FlashStringHelper* str) {
  const char* text = (const char*)str;
  if (loadingFlag) { // pool is zeroed on mode change
    loadingFlag = false;
    fullTextFlag = false;
    dotsCount = dots;
    s3.deltaZ = 2; s3.iter = S3_ROT; s3.scale = 1.0; s3.scaleDir = S3_STEP;
    s3InitSphere(5);
  }
  FastLED.clear();
  s3UpdateText(text, strlen_P(text));
  s3DrawText();
  s3ScaleAndRotate(1.8, 1.1);
}
