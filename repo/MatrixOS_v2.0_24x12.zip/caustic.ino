// Ugly Caustic, https://editor.soulmatelights.com/gallery/1481-ugly-caustic. Called from custom.ino
// RAM: noise buffers and x/y/z live in the shared pool (see POOL_SIZE in main .ino), pool is zeroed on mode change

#define CAUS_SCALE 24
#define CAUS_BRI   128
#define CAUS_SPEED 8
#define CAUS_SMOOTH (CAUS_SPEED < 50 ? 200 - CAUS_SPEED * 4 : 0) // сглаживание шума, константа

struct CausState {
  uint8_t  n[2][WIDTH + 1][HEIGHT + 1]; // n[0] - шум, n[1] - яркость каустики
  uint16_t x, y, z;                     // смещение по шуму
};
#define caus (*(CausState*)pool)
static_assert(sizeof(CausState) <= POOL_SIZE, "pool too small for UglyCaustic");

void causWuPixel(int16_t x, int16_t y) {
  // extract the fractional parts and derive their inverses
  uint8_t xx = x & 0xff, yy = y & 0xff, ix = 255 - xx, iy = 255 - yy;
  // calculate the intensities for each affected pixel
  #define WU_WEIGHT(a, b)((uint8_t)(((a) * (b) + (a) + (b)) >> 8))
  uint8_t wu[4] = {
    WU_WEIGHT(ix, iy),
    WU_WEIGHT(xx, iy),
    WU_WEIGHT(ix, yy),
    WU_WEIGHT(xx, yy)
  };
  #undef WU_WEIGHT
  // multiply the intensities by the colour, and saturating-add them to the pixels
  for (uint8_t i = 0; i < 4; i++) {
    uint8_t lx = (x >> 8) + (i & 1);
    uint8_t ly = (y >> 8) + ((i >> 1) & 1);
    if (lx <= WIDTH && ly <= HEIGHT) // отрицательные координаты превращаются в большие uint8 и отсекаются
      caus.n[1][lx][ly] = constrain(qsub8(caus.n[1][lx][ly], (CAUS_BRI * wu[i]) >> 8), 15, 255);
  }
}

void causFillNoise() {
  for (uint8_t i = 0; i < WIDTH + 1; i++) {
    int32_t ioffset = CAUS_SCALE * i;
    for (uint8_t j = 0; j < HEIGHT + 1; j++) {
      int32_t joffset = CAUS_SCALE * j;

      uint8_t data = inoise8(caus.x + ioffset, caus.y + joffset, caus.z);

      data = qsub8(data, 16);
      data = qadd8(data, scale8(data, 39));

#if CAUS_SMOOTH
      uint8_t olddata = caus.n[0][i][j];
      data = scale8(olddata, CAUS_SMOOTH) + scale8(data, 256 - CAUS_SMOOTH);
#endif

      caus.n[0][i][j] = data;
    }
  }
  caus.z += CAUS_SPEED;

  // apply slow drift to X and Y, just for visual variation.
  caus.x += CAUS_SPEED >> 3;
  caus.y -= CAUS_SPEED >> 4;
}

void UglyCaustic() {
  if (loadingFlag) {
    loadingFlag = false;
    FastLED.clear();
  }

  causFillNoise();
  memset(&caus.n[1][0][0], 255, (WIDTH + 1) * (HEIGHT + 1));
  for (byte x = 0; x < WIDTH; x++) {
    for (byte y = 0; y < HEIGHT; y++) {
      uint8_t n0 = caus.n[0][x][y];
      uint8_t n1 = caus.n[0][x + 1][y];
      uint8_t n2 = caus.n[0][x][y + 1];
      int8_t xl = n0 - n1;
      int8_t yl = n0 - n2;
      int16_t xa = (x << 8) + ((xl * avg8(n0, n1)) >> 1);
      int16_t ya = (y << 8) + ((yl * avg8(n0, n2)) >> 1);
      causWuPixel(xa, ya);
    }
  }
  for (byte i = 0; i < WIDTH; i++) {
    for (byte j = 0; j < HEIGHT; j++) {
      nblend(leds[XY(i, j)], CHSV(150, caus.n[1][i][j], 255), 64);
    }
  }
}
