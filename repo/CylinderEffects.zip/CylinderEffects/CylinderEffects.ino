//https://forum.arduino.ru/t/web-arduino-ide-soulmatelights/19999/3
// 20 cylinder-friendly effects for 16x16 matrix (FastLED, pin 6)
#include <FastLED.h>

#define LED_PIN     6
#define WIDTH       16
#define HEIGHT      16
#define NUM_LEDS    (WIDTH * HEIGHT)
#define BRIGHTNESS  180
#define COLOR_ORDER GRB
#define MATRIX_TYPE 0

CRGB leds[NUM_LEDS];

// ---------- координаты ----------
uint16_t XY(uint8_t x, uint8_t y) {
  if ((y & 1) == 0 || MATRIX_TYPE) return y * WIDTH + x;
  return y * WIDTH + WIDTH - 1 - x;
}

// ---------- прототипы ----------
void drawPixelXYF(float x, float y, CRGB color);
float wrapX(float x);
float distX(float a, float b);
void clearLeds();

// ---------- базовые утилиты ----------
void clearLeds() { FastLED.clear(); }

float wrapX(float x) {
  while (x < 0) x += WIDTH;
  while (x >= WIDTH) x -= WIDTH;
  return x;
}

// кратчайшее расстояние по кругу
float distX(float a, float b) {
  float d = fabsf(a - b);
  return fminf(d, WIDTH - d);
}

// антиалиасинг + замыкание по x
void drawPixelXYF(float x, float y, CRGB color) {
  int x0 = (int)floorf(x);
  int x1 = x0 + 1;
  int y0 = (int)floorf(y);
  float fx = x - x0;
  float fy = y - y0;
  x0 = ((x0 % WIDTH) + WIDTH) % WIDTH;
  x1 = ((x1 % WIDTH) + WIDTH) % WIDTH;
  if (y0 < 0 || y0 >= HEIGHT) return;
  CRGB c;
  c = color; c.nscale8_video((uint8_t)((1.0f - fx) * (1.0f - fy) * 255)); leds[XY(x0, y0)] |= c;
  c = color; c.nscale8_video((uint8_t)(fx * (1.0f - fy) * 255));          leds[XY(x1, y0)] |= c;
  if (y0 + 1 < HEIGHT) {
    c = color; c.nscale8_video((uint8_t)((1.0f - fx) * fy * 255));        leds[XY(x0, y0 + 1)] |= c;
    c = color; c.nscale8_video((uint8_t)(fx * fy * 255));                 leds[XY(x1, y0 + 1)] |= c;
  }
}

// ============================================================
// 1. RINGS — кольца, бегущие вверх
// ============================================================
void fxRings(float t) {
  for (int y = 0; y < HEIGHT; y++) {
    float phase = y * 0.8f - t * 2.0f;
    float v = powf((sinf(phase) + 1.0f) * 0.5f, 3.0f);
    uint8_t hue = (uint8_t)(y * 12 + t * 20);
    CRGB c = CHSV(hue, 220, (uint8_t)(v * 255));
    for (int x = 0; x < WIDTH; x++) leds[XY(x, y)] = c;
  }
}

// ============================================================
// 2. SPIRAL — две спирали, обвивающие цилиндр
// ============================================================
void fxSpiral(float t) {
  for (int arm = 0; arm < 2; arm++) {
    float offset = arm * (WIDTH * 0.5f);
    for (float y = 0; y < HEIGHT; y += 0.3f) {
      float x = y * 1.5f + offset + t * 3.0f;
      drawPixelXYF(x, y, CHSV((uint8_t)(y * 16 + t * 30), 200, 255));
    }
  }
  fadeToBlackBy(leds, NUM_LEDS, 30);
}

// ============================================================
// 3. PULSE — пульсация от центра + вертикальные разряды
// ============================================================
void fxPulse(float t) {
  float cx = WIDTH * 0.5f, cy = HEIGHT * 0.5f;
  float pulse = 0.5f + 0.5f * sinf(t * 2.0f);
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float dx = distX(x, cx);
      float dy = fabsf(y - cy);
      float d = sqrtf(dx * dx + dy * dy);
      float v = pulse * (1.0f - d / (WIDTH * 0.7f));
      if (v < 0) v = 0;
      leds[XY(x, y)] = CHSV((uint8_t)(t * 40 + d * 15), 200, (uint8_t)(v * 255));
    }
  static float boltX = -1, boltTimer = 0;
  boltTimer -= 0.016f;
  if (boltTimer <= 0) { boltX = random(0, WIDTH); boltTimer = random(100, 300) / 100.0f; }
  if (boltX >= 0) {
    float flick = 0.5f + 0.5f * sinf(t * 30.0f);
    for (int y = 0; y < HEIGHT; y++)
      drawPixelXYF(boltX, y, CHSV(160, 80, (uint8_t)(200 * flick)));
  }
}

// ============================================================
// 4. HELIX DNA — две переплетённые нити
// ============================================================
void fxHelix(float t) {
  for (float y = 0; y < HEIGHT; y += 0.25f) {
    float phase = y * 1.2f + t * 3.0f;
    float x1 = WIDTH * 0.5f + sinf(phase) * (WIDTH * 0.35f);
    float x2 = WIDTH * 0.5f + sinf(phase + PI) * (WIDTH * 0.35f);
    drawPixelXYF(x1, y, CHSV(0, 255, 255));
    drawPixelXYF(x2, y, CHSV(96, 255, 255));
  }
  fadeToBlackBy(leds, NUM_LEDS, 40);
}

// ============================================================
// 5. WATERFALL — падающая вода по всему цилиндру
// ============================================================
void fxWaterfall(float t) {
  for (int y = 0; y < HEIGHT; y++) {
    for (int x = 0; x < WIDTH; x++) {
      float v = sinf(y * 0.9f + x * 0.4f - t * 6.0f);
      v = (v + 1.0f) * 0.5f;
      v = powf(v, 2.0f);
      uint8_t hue = 160 + (uint8_t)(v * 40);
      leds[XY(x, y)] = CHSV(hue, 200, (uint8_t)(v * 255));
    }
  }
}

// ============================================================
// 6. RADAR — луч, вращающийся вокруг цилиндра
// ============================================================
void fxRadar(float t) {
  float beam = t * 90.0f;
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float angle = x * (360.0f / WIDTH);
      float d = fabsf(angle - fmodf(beam, 360.0f));
      if (d > 180) d = 360 - d;
      float v = 1.0f - d / 90.0f;
      if (v < 0) v = 0;
      v = powf(v, 2.0f);
      float vy = 1.0f - fabsf(y - HEIGHT * 0.5f) / (HEIGHT * 0.5f);
      leds[XY(x, y)] = CHSV(96, 255, (uint8_t)(v * vy * 255));
    }
}

// ============================================================
// 7. FIRE — огонь, поднимающийся по цилиндру
// ============================================================
void fxFire(float t) {
  static uint8_t heat[HEIGHT][WIDTH] = {0};
  for (int x = 0; x < WIDTH; x++) heat[0][x] = random(160, 255);
  for (int y = 1; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      int xl = (x - 1 + WIDTH) % WIDTH, xr = (x + 1) % WIDTH;
      int v = (heat[y - 1][xl] + heat[y - 1][x] + heat[y - 1][xr]) / 3;
      v -= random(0, 30);
      heat[y][x] = v > 0 ? v : 0;
    }
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      uint8_t h = heat[y][x];
      uint8_t hue = h < 128 ? h / 2 : 40 + (h - 128) / 4;
      leds[XY(x, y)] = CHSV(hue, 255, h);
    }
}

// ============================================================
// 8. MATRIX RAIN — цифровой дождь по кругу
// ============================================================
void fxMatrixRain(float t) {
  static float drops[WIDTH];
  static bool init = false;
  if (!init) { for (int i = 0; i < WIDTH; i++) drops[i] = random(0, HEIGHT * 3) / 3.0f; init = true; }
  fadeToBlackBy(leds, NUM_LEDS, 60);
  for (int x = 0; x < WIDTH; x++) {
    int y = (int)drops[x];
    if (y >= 0 && y < HEIGHT) {
      leds[XY(x, y)] = CHSV(96, 255, 255);
      if (y + 1 < HEIGHT) leds[XY(x, y + 1)] = CHSV(96, 255, 120);
    }
    drops[x] -= 0.15f + x * 0.01f;
    if (drops[x] < -1) drops[x] = HEIGHT + random(0, 5);
  }
}

// ============================================================
// 9. BOUNCING BALLS — шарики, летающие по кругу
// ============================================================
struct Ball { float x, y, vx, vy; uint8_t hue; };
Ball balls[4];
void initBalls() {
  for (int i = 0; i < 4; i++) {
    balls[i] = { random(0, WIDTH), random(0, HEIGHT),
                 (random(2) ? 1 : -1) * (0.15f + random(0, 20) / 100.0f),
                 (random(2) ? 1 : -1) * (0.10f + random(0, 15) / 100.0f),
                 (uint8_t)random(0, 256) };
  }
}
void fxBalls(float t) {
  static bool init = false;
  if (!init) { initBalls(); init = true; }
  fadeToBlackBy(leds, NUM_LEDS, 50);
  for (int i = 0; i < 4; i++) {
    balls[i].x += balls[i].vx;
    balls[i].y += balls[i].vy;
    if (balls[i].y < 0 || balls[i].y >= HEIGHT - 1) balls[i].vy = -balls[i].vy;
    balls[i].x = wrapX(balls[i].x);
    drawPixelXYF(balls[i].x, balls[i].y, CHSV(balls[i].hue, 255, 255));
    drawPixelXYF(balls[i].x + 0.3f, balls[i].y, CHSV(balls[i].hue, 255, 120));
  }
}

// ============================================================
// 10. ZEBRA — вертикальные полосы, бегущие вокруг
// ============================================================
void fxZebra(float t) {
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float phase = x * 1.2f - t * 6.0f + y * 0.3f;
      float v = (sinf(phase) + 1.0f) * 0.5f;
      v = powf(v, 3.0f);
      leds[XY(x, y)] = CHSV((uint8_t)(t * 30 + y * 10), 255, (uint8_t)(v * 255));
    }
}

// ============================================================
// 11. TORNADO — вихрь, вращающийся вокруг оси
// ============================================================
void fxTornado(float t) {
  fadeToBlackBy(leds, NUM_LEDS, 80);
  for (float y = 0; y < HEIGHT; y += 0.4f) {
    float radius = 0.3f + y / HEIGHT * 0.7f;
    float ang = y * 0.8f - t * 8.0f;
    float cx = WIDTH * 0.5f + cosf(ang) * WIDTH * 0.5f * radius;
    drawPixelXYF(cx, y, CHSV((uint8_t)(160 + y * 8), 255, 255));
  }
}

// ============================================================
// 12. STARFIELD — звёзды, летящие навстречу
// ============================================================
struct Star { float x, y, z; };
Star stars[20];
void initStars() { for (int i = 0; i < 20; i++) stars[i] = { (float)random(0, WIDTH), (float)random(0, HEIGHT), (float)random(1, 100) / 100.0f }; }
void fxStars(float t) {
  static bool init = false;
  if (!init) { initStars(); init = true; }
  fadeToBlackBy(leds, NUM_LEDS, 80);
  for (int i = 0; i < 20; i++) {
    stars[i].z -= 0.03f;
    if (stars[i].z <= 0) { stars[i].x = random(0, WIDTH); stars[i].y = random(0, HEIGHT); stars[i].z = 1.0f; }
    uint8_t b = (uint8_t)((1.0f - stars[i].z) * 255);
    drawPixelXYF(stars[i].x, stars[i].y, CHSV(160, 100, b));
  }
}

// ============================================================
// 13. COLOR WAVE — синусоидальная волна цветов
// ============================================================
void fxWave(float t) {
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float v = sinf(x * 0.5f + y * 0.3f - t * 3.0f);
      uint8_t hue = (uint8_t)(x * 16 + y * 8 + t * 20);
      leds[XY(x, y)] = CHSV(hue, 255, (uint8_t)((v + 1.0f) * 127));
    }
}

// ============================================================
// 14. HEARTBEAT — пульс от основания
// ============================================================
void fxHeartbeat(float t) {
  float pulse = powf(fmaxf(0, sinf(t * 3.0f)), 6.0f);
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float d = y / (float)HEIGHT;
      float v = pulse * (1.0f - d * 0.5f);
      leds[XY(x, y)] = CHSV(0, 255, (uint8_t)(v * 255));
    }
}

// ============================================================
// 15. PLASMA — классическая плазма
// ============================================================
void fxPlasma(float t) {
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float v = sinf(x * 0.4f + t) + sinf(y * 0.3f + t * 0.7f) + sinf((x + y) * 0.2f + t * 0.3f);
      uint8_t hue = (uint8_t)((v * 40) + 128);
      leds[XY(x, y)] = CHSV(hue, 255, 200);
    }
}

// ============================================================
// 16. DIAGONAL STRIPES — диагональные полосы, бегущие вокруг
// ============================================================
void fxDiagonal(float t) {
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      float phase = (x + y) * 0.7f - t * 5.0f;
      float v = (sinf(phase) + 1.0f) * 0.5f;
      leds[XY(x, y)] = CHSV((uint8_t)((x + y) * 8 + t * 20), 255, (uint8_t)(v * 255));
    }
}

// ============================================================
// 17. LIGHTNING RING — молния, обегающая цилиндр
// ============================================================
void fxLightningRing(float t) {
  static float angle = 0, life = 0;
  static uint8_t hue = 160;
  fadeToBlackBy(leds, NUM_LEDS, 80);
  life -= 0.016f;
  if (life <= 0) { angle = random(0, WIDTH); life = 0.3f + random(0, 20) / 100.0f; hue = random(140, 200); }
  for (int y = 0; y < HEIGHT; y++) {
    float jitter = sinf(y * 2.0f + t * 20.0f) * 1.5f;
    drawPixelXYF(angle + jitter, y, CHSV(hue, 80, 255));
  }
}

// ============================================================
// 18. SPARKLE — случайные вспышки по всей поверхности
// ============================================================
void fxSparkle(float t) {
  fadeToBlackBy(leds, NUM_LEDS, 30);
  for (int i = 0; i < 3; i++) {
    int x = random(0, WIDTH), y = random(0, HEIGHT);
    leds[XY(x, y)] = CHSV(random(0, 256), 100, 255);
  }
}

// ============================================================
// 19. SNAKE — змейка, ползущая вокруг цилиндра
// ============================================================
void fxSnake(float t) {
  fadeToBlackBy(leds, NUM_LEDS, 60);
  static float pos = 0, dir = 0, y = 0;
  static int8_t state = 0;
  pos += 0.3f;
  if (pos >= WIDTH) { pos -= WIDTH; state = (state + 1) % 4; }
  if (state == 0) y = HEIGHT * 0.5f;
  else if (state == 1) y = HEIGHT - 1;
  else if (state == 2) y = HEIGHT * 0.5f;
  else y = 0;
  for (int i = 0; i < 4; i++) {
    drawPixelXYF(pos - i * 0.5f, y, CHSV(96 - i * 20, 255, 255 - i * 50));
  }
}

// ============================================================
// 20. RAINBOW SPIN — радуга, вращающаяся вокруг оси
// ============================================================
void fxRainbowSpin(float t) {
  for (int y = 0; y < HEIGHT; y++)
    for (int x = 0; x < WIDTH; x++) {
      uint8_t hue = (uint8_t)(x * 16 + t * 40 + y * 4);
      float v = 0.7f + 0.3f * sinf(y * 0.5f + t * 2.0f);
      leds[XY(x, y)] = CHSV(hue, 255, (uint8_t)(v * 255));
    }
}

// ============================================================
// ДИСПЕТЧЕР
// ============================================================
typedef void (*EffectFn)(float);
EffectFn effects[] = {
  fxRings, fxSpiral, fxPulse, fxHelix, fxWaterfall,
  fxRadar, fxFire, fxMatrixRain, fxBalls, fxZebra,
  fxTornado, fxStars, fxWave, fxHeartbeat, fxPlasma,
  fxDiagonal, fxLightningRing, fxSparkle, fxSnake, fxRainbowSpin
};
const int EFFECT_COUNT = 20;

unsigned long lastSwitch = 0;
int mode = 0;
const unsigned long MODE_DURATION = 8000;   // 8 сек на эффект

void setup() {
  FastLED.addLeds<WS2812B, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS);
  FastLED.setBrightness(BRIGHTNESS);
  randomSeed(analogRead(A0));
}

void loop() {
  unsigned long now = millis();
  if (now - lastSwitch > MODE_DURATION) {
    mode = (mode + 1) % EFFECT_COUNT;
    lastSwitch = now;
    FastLED.clear();
  }
  float t = now * 0.001f;
  effects[mode](t);
  FastLED.show();
  delay(16);
}